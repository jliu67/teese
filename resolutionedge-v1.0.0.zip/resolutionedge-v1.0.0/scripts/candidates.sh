#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
LIMIT="${1:-30}"
exec .venv/bin/resolutionedge candidates --limit "$LIMIT" --config config/default.yaml
