#!/usr/bin/env bash
set -Eeuo pipefail
SESSION="${RESOLUTIONEDGE_TMUX_SESSION:-resolutionedge-v1}"
exec tmux attach-session -t "$SESSION"
