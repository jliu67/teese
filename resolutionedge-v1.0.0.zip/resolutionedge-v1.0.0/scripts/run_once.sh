#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
MODE="${1:-paper}"
exec .venv/bin/resolutionedge scan --mode "$MODE" --config config/default.yaml
