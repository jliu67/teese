#!/usr/bin/env bash
set -Eeuo pipefail
SESSION="${RESOLUTIONEDGE_TMUX_SESSION:-resolutionedge-v1}"
if ! tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "No tmux session '$SESSION' is running."
  exit 0
fi
# Give both long-running commands a chance to close files cleanly.
tmux send-keys -t "$SESSION:engine" C-c || true
tmux send-keys -t "$SESSION:stream" C-c || true
sleep 2
tmux kill-session -t "$SESSION" 2>/dev/null || true
echo "Stopped $SESSION."
