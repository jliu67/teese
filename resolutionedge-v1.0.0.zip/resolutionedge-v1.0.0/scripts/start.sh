#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
SESSION="${RESOLUTIONEDGE_TMUX_SESSION:-resolutionedge-v1}"
MODE="${1:-paper}"

if [[ "$MODE" != "paper" && "$MODE" != "capture" ]]; then
  echo "Mode must be paper or capture. V1 has no live mode." >&2
  exit 2
fi
if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux is required: sudo apt-get update && sudo apt-get install -y tmux" >&2
  exit 1
fi
if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "tmux session '$SESSION' already exists. Use ./scripts/attach.sh or ./scripts/stop.sh." >&2
  exit 1
fi

mkdir -p logs
tmux new-session -d -s "$SESSION" -n engine \
  "cd '$ROOT' && exec .venv/bin/resolutionedge run --mode '$MODE' --config config/default.yaml 2>&1 | tee -a logs/engine-console.log"
tmux new-window -t "$SESSION" -n stream \
  "cd '$ROOT' && exec .venv/bin/resolutionedge stream --config config/default.yaml 2>&1 | tee -a logs/stream-console.log"
tmux new-window -t "$SESSION" -n monitor \
  "cd '$ROOT' && while true; do clear; .venv/bin/resolutionedge progress --config config/default.yaml; echo; .venv/bin/resolutionedge candidates --limit 12 --config config/default.yaml; sleep 15; done"
tmux select-window -t "$SESSION:engine"

echo "Started $SESSION in $MODE mode."
echo "Attach:   ./scripts/attach.sh"
echo "Progress: ./scripts/progress.sh"
echo "Report:   ./scripts/report.sh"
echo "Stop:     ./scripts/stop.sh"
