#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
.venv/bin/python -m compileall -q resolutionedge
.venv/bin/python -m pytest -q
.venv/bin/python -m ruff check .
echo "Verification passed."
