from __future__ import annotations

from resolutionedge.models import MarketData, RuleAssessment
from resolutionedge.utils import canonical_json, normalize_label, sha256_text


AMBIGUOUS_PHRASES = (
    "consensus of credible reporting",
    "preponderance of credible reporting",
    "in the judgment of",
    "substantive",
    "significant",
    "widely recognized",
    "primarily resolved based on",
    "media consensus",
    "credible sources",
    "if the outcome is unclear",
    "spirit of the market",
)


def market_semantic_hash(market: MarketData) -> str:
    """Fingerprint every field used to interpret or map a contract in V1."""
    return sha256_text(canonical_json(market.semantic_snapshot()))


def assess_rules(market: MarketData) -> RuleAssessment:
    combined = " ".join(
        [
            market.rules,
            market.resolution_source,
            market.question,
            market.event_title,
        ]
    )
    normalized = normalize_label(combined)
    reasons: list[str] = []
    ambiguity = 0

    if not market.rules:
        reasons.append("missing resolution rules")
        ambiguity += 5

    for phrase in AMBIGUOUS_PHRASES:
        if normalize_label(phrase) in normalized:
            reasons.append(f"ambiguous phrase: {phrase}")
            ambiguity += 2

    bls_host = "bls gov" in normalized or "bureau of labor statistics" in normalized
    u3 = "u 3" in normalized or "official unemployment rate" in normalized
    table_a15 = "table a 15" in normalized
    employment_situation = "employment situation" in normalized
    unemployment = "unemployment rate" in normalized

    strict_bls_u3 = all((bls_host, u3, table_a15, employment_situation, unemployment))
    if strict_bls_u3:
        reasons.append("strict BLS U-3/Table A-15 rule family")
        return RuleAssessment(
            deterministic=ambiguity == 0,
            supported=ambiguity == 0,
            adapter_id="bls_u3" if ambiguity == 0 else None,
            ambiguity_score=ambiguity,
            reasons=reasons,
            rules_hash=market_semantic_hash(market),
        )

    reasons.append("no V1 deterministic source adapter matched")
    return RuleAssessment(
        deterministic=False,
        supported=False,
        adapter_id=None,
        ambiguity_score=ambiguity,
        reasons=reasons,
        rules_hash=market_semantic_hash(market),
    )
