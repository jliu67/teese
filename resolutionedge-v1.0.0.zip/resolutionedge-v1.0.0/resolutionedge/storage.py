from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterator

from resolutionedge.models import (
    Evaluation,
    MarketData,
    OrderBook,
    RuleAssessment,
    SourceEvidence,
    UniverseDecision,
)
from resolutionedge.utils import canonical_json, iso_utc, utc_now


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
PRAGMA synchronous=NORMAL;
PRAGMA busy_timeout=5000;

CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mode TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    stats_json TEXT NOT NULL DEFAULT '{}',
    error TEXT
);

CREATE TABLE IF NOT EXISTS markets (
    market_id TEXT PRIMARY KEY,
    condition_id TEXT,
    event_id TEXT NOT NULL,
    event_title TEXT NOT NULL,
    slug TEXT NOT NULL,
    question TEXT NOT NULL,
    group_item_title TEXT NOT NULL,
    rules TEXT NOT NULL,
    rules_hash TEXT NOT NULL,
    resolution_source TEXT NOT NULL,
    category TEXT NOT NULL,
    tags_json TEXT NOT NULL,
    outcomes_json TEXT NOT NULL,
    start_date TEXT,
    end_date TEXT,
    closed_time TEXT,
    active INTEGER NOT NULL,
    closed INTEGER NOT NULL,
    archived INTEGER NOT NULL,
    accepting_orders INTEGER NOT NULL,
    enable_order_book INTEGER NOT NULL,
    restricted INTEGER NOT NULL,
    neg_risk INTEGER NOT NULL,
    game_start_time TEXT,
    game_id TEXT NOT NULL,
    sports_market_type TEXT NOT NULL,
    lifetime_volume TEXT NOT NULL,
    liquidity TEXT NOT NULL,
    min_tick_size TEXT,
    min_order_size TEXT,
    fees_enabled INTEGER,
    fee_rate TEXT,
    fee_exponent TEXT,
    hard_banned INTEGER NOT NULL,
    universe_eligible INTEGER NOT NULL,
    universe_reason TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    last_seen_run_id INTEGER,
    raw_json TEXT NOT NULL,
    FOREIGN KEY(last_seen_run_id) REFERENCES runs(id)
);

CREATE INDEX IF NOT EXISTS idx_markets_event ON markets(event_id);
CREATE INDEX IF NOT EXISTS idx_markets_status ON markets(hard_banned, universe_eligible, accepting_orders, closed);
CREATE INDEX IF NOT EXISTS idx_markets_end_date ON markets(end_date);

CREATE TABLE IF NOT EXISTS market_rule_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id TEXT NOT NULL,
    rules_hash TEXT NOT NULL,
    question TEXT NOT NULL,
    rules TEXT NOT NULL,
    resolution_source TEXT NOT NULL,
    semantic_json TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    UNIQUE(market_id, rules_hash)
);

CREATE INDEX IF NOT EXISTS idx_rule_versions_market ON market_rule_versions(market_id);

CREATE TABLE IF NOT EXISTS book_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    observed_at TEXT NOT NULL,
    book_timestamp TEXT,
    capture_phase TEXT NOT NULL,
    market_id TEXT NOT NULL,
    token_id TEXT NOT NULL,
    outcome_label TEXT,
    best_bid TEXT,
    best_ask TEXT,
    midpoint TEXT,
    spread TEXT,
    tick_size TEXT NOT NULL,
    min_order_size TEXT,
    last_trade_price TEXT,
    book_hash TEXT NOT NULL,
    bids_json TEXT NOT NULL,
    asks_json TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES runs(id),
    FOREIGN KEY(market_id) REFERENCES markets(market_id)
);

CREATE INDEX IF NOT EXISTS idx_books_market_time ON book_snapshots(market_id, observed_at);
CREATE INDEX IF NOT EXISTS idx_books_token_time ON book_snapshots(token_id, observed_at);

CREATE TABLE IF NOT EXISTS rule_assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    market_id TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    deterministic INTEGER NOT NULL,
    supported INTEGER NOT NULL,
    adapter_id TEXT,
    ambiguity_score INTEGER NOT NULL,
    reasons_json TEXT NOT NULL,
    rules_hash TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES runs(id),
    FOREIGN KEY(market_id) REFERENCES markets(market_id)
);

CREATE TABLE IF NOT EXISTS source_releases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    adapter_id TEXT NOT NULL,
    period TEXT NOT NULL,
    value TEXT NOT NULL,
    release_at TEXT,
    first_seen_at TEXT NOT NULL,
    source_checksum TEXT NOT NULL,
    archive_path TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    UNIQUE(adapter_id, period)
);

CREATE TABLE IF NOT EXISTS source_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    market_id TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    adapter_id TEXT NOT NULL,
    status TEXT NOT NULL,
    period TEXT,
    value TEXT,
    winning_side TEXT,
    winning_token_id TEXT,
    release_at TEXT,
    first_seen_at TEXT,
    source_url TEXT NOT NULL,
    source_checksum TEXT NOT NULL,
    archive_path TEXT NOT NULL,
    reason TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES runs(id),
    FOREIGN KEY(market_id) REFERENCES markets(market_id)
);

CREATE INDEX IF NOT EXISTS idx_evidence_market_time ON source_evidence(market_id, observed_at);

CREATE TABLE IF NOT EXISTS evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    observed_at TEXT NOT NULL,
    strategy TEXT NOT NULL,
    market_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    token_id TEXT,
    outcome_label TEXT,
    decision TEXT NOT NULL,
    reason TEXT NOT NULL,
    reference_price TEXT,
    best_bid TEXT,
    best_ask TEXT,
    midpoint TEXT,
    spread TEXT,
    hours_to_end TEXT,
    expected_payout TEXT,
    net_edge_per_share TEXT,
    requested_notional TEXT,
    filled_shares TEXT,
    raw_notional TEXT,
    fee TEXT,
    all_in_cost TEXT,
    effective_vwap TEXT,
    all_in_cost_per_share TEXT,
    evidence_key TEXT NOT NULL,
    source_status TEXT,
    fill_json TEXT,
    metadata_json TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES runs(id),
    FOREIGN KEY(market_id) REFERENCES markets(market_id)
);

CREATE INDEX IF NOT EXISTS idx_evaluations_strategy_time ON evaluations(strategy, observed_at);
CREATE INDEX IF NOT EXISTS idx_evaluations_decision ON evaluations(decision, strategy);

CREATE TABLE IF NOT EXISTS paper_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    strategy TEXT NOT NULL,
    market_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    token_id TEXT NOT NULL,
    outcome_label TEXT NOT NULL,
    created_at TEXT NOT NULL,
    evidence_key TEXT NOT NULL,
    source_status TEXT,
    requested_notional TEXT NOT NULL,
    shares TEXT NOT NULL,
    raw_notional TEXT NOT NULL,
    fee TEXT NOT NULL,
    all_in_cost TEXT NOT NULL,
    effective_vwap TEXT NOT NULL,
    all_in_cost_per_share TEXT NOT NULL,
    expected_payout TEXT,
    expected_edge_per_share TEXT,
    status TEXT NOT NULL DEFAULT 'OPEN',
    payout_per_share TEXT,
    gross_payout TEXT,
    net_pnl TEXT,
    settled_at TEXT,
    settlement_raw_json TEXT,
    fill_json TEXT NOT NULL,
    UNIQUE(strategy, market_id, token_id, evidence_key),
    FOREIGN KEY(run_id) REFERENCES runs(id),
    FOREIGN KEY(market_id) REFERENCES markets(market_id)
);

CREATE INDEX IF NOT EXISTS idx_paper_orders_open ON paper_orders(status, market_id);
CREATE INDEX IF NOT EXISTS idx_paper_orders_strategy ON paper_orders(strategy, created_at);

CREATE TABLE IF NOT EXISTS runtime_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


def _string(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=5000")
        return connection

    @contextmanager
    def session(self) -> Iterator[sqlite3.Connection]:
        """Yield a connection and always commit/rollback and close it."""
        connection = self.connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self.session() as connection:
            yield connection

    def initialize(self) -> None:
        with self.session() as connection:
            connection.executescript(SCHEMA)

    def start_run(self, mode: str) -> int:
        with self.transaction() as connection:
            cursor = connection.execute(
                "INSERT INTO runs(mode, started_at, status) VALUES (?, ?, 'RUNNING')",
                (mode, iso_utc()),
            )
            return int(cursor.lastrowid)

    def finish_run(
        self,
        run_id: int,
        *,
        status: str,
        stats: dict[str, Any],
        error: str | None = None,
    ) -> None:
        with self.transaction() as connection:
            connection.execute(
                """
                UPDATE runs
                SET finished_at=?, status=?, stats_json=?, error=?
                WHERE id=?
                """,
                (iso_utc(), status, canonical_json(stats), error, run_id),
            )

    def set_meta(self, key: str, value: Any) -> None:
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO runtime_meta(key, value, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
                """,
                (key, canonical_json(value), iso_utc()),
            )

    def get_meta(self, key: str) -> Any | None:
        with self.session() as connection:
            row = connection.execute(
                "SELECT value FROM runtime_meta WHERE key=?", (key,)
            ).fetchone()
        if row is None:
            return None
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return row["value"]

    def record_rule_version(
        self,
        market: MarketData,
        *,
        rules_hash: str,
    ) -> bool:
        """Persist the exact rule fingerprint and return True after any change."""
        now = iso_utc()
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO market_rule_versions(
                    market_id, rules_hash, question, rules, resolution_source, semantic_json,
                    first_seen_at, last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(market_id, rules_hash) DO UPDATE SET
                    last_seen_at=excluded.last_seen_at
                """,
                (
                    market.market_id,
                    rules_hash,
                    market.question,
                    market.rules,
                    market.resolution_source,
                    canonical_json(market.semantic_snapshot()),
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT COUNT(*) FROM market_rule_versions WHERE market_id=?",
                (market.market_id,),
            ).fetchone()
        return bool(row and int(row[0]) > 1)

    def market_has_rule_changes(self, market_id: str) -> bool:
        with self.session() as connection:
            row = connection.execute(
                "SELECT COUNT(*) FROM market_rule_versions WHERE market_id=?",
                (market_id,),
            ).fetchone()
        return bool(row and int(row[0]) > 1)

    def hard_banned_event_ids(self) -> set[str]:
        """Return events that were ever stored as sports/esports hard-banned."""
        with self.session() as connection:
            rows = connection.execute(
                "SELECT DISTINCT event_id FROM markets WHERE hard_banned=1"
            ).fetchall()
        return {str(row["event_id"]) for row in rows if row["event_id"]}

    def upsert_market(
        self,
        run_id: int,
        market: MarketData,
        universe: UniverseDecision,
        *,
        rules_hash: str,
    ) -> None:
        now = iso_utc()
        outcomes_json = canonical_json([outcome.model_dump(mode="json") for outcome in market.outcomes])
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO markets(
                    market_id, condition_id, event_id, event_title, slug, question,
                    group_item_title, rules, rules_hash, resolution_source, category,
                    tags_json, outcomes_json, start_date, end_date, closed_time,
                    active, closed, archived, accepting_orders, enable_order_book,
                    restricted, neg_risk, game_start_time, game_id, sports_market_type,
                    lifetime_volume, liquidity, min_tick_size,
                    min_order_size, fees_enabled, fee_rate, fee_exponent,
                    hard_banned, universe_eligible, universe_reason,
                    first_seen_at, last_seen_at, last_seen_run_id, raw_json
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
                ON CONFLICT(market_id) DO UPDATE SET
                    condition_id=excluded.condition_id,
                    event_id=excluded.event_id,
                    event_title=excluded.event_title,
                    slug=excluded.slug,
                    question=excluded.question,
                    group_item_title=excluded.group_item_title,
                    rules=excluded.rules,
                    rules_hash=excluded.rules_hash,
                    resolution_source=excluded.resolution_source,
                    category=excluded.category,
                    tags_json=excluded.tags_json,
                    outcomes_json=excluded.outcomes_json,
                    start_date=excluded.start_date,
                    end_date=excluded.end_date,
                    closed_time=excluded.closed_time,
                    active=excluded.active,
                    closed=excluded.closed,
                    archived=excluded.archived,
                    accepting_orders=excluded.accepting_orders,
                    enable_order_book=excluded.enable_order_book,
                    restricted=excluded.restricted,
                    neg_risk=excluded.neg_risk,
                    game_start_time=excluded.game_start_time,
                    game_id=excluded.game_id,
                    sports_market_type=excluded.sports_market_type,
                    lifetime_volume=excluded.lifetime_volume,
                    liquidity=excluded.liquidity,
                    min_tick_size=excluded.min_tick_size,
                    min_order_size=excluded.min_order_size,
                    fees_enabled=excluded.fees_enabled,
                    fee_rate=excluded.fee_rate,
                    fee_exponent=excluded.fee_exponent,
                    hard_banned=excluded.hard_banned,
                    universe_eligible=excluded.universe_eligible,
                    universe_reason=excluded.universe_reason,
                    last_seen_at=excluded.last_seen_at,
                    last_seen_run_id=excluded.last_seen_run_id,
                    raw_json=excluded.raw_json
                """,
                (
                    market.market_id,
                    market.condition_id,
                    market.event_id,
                    market.event_title,
                    market.slug,
                    market.question,
                    market.group_item_title,
                    market.rules,
                    rules_hash,
                    market.resolution_source,
                    market.category,
                    canonical_json(market.tags),
                    outcomes_json,
                    _string(market.start_date),
                    _string(market.end_date),
                    _string(market.closed_time),
                    int(market.active),
                    int(market.closed),
                    int(market.archived),
                    int(market.accepting_orders),
                    int(market.enable_order_book),
                    int(market.restricted),
                    int(market.neg_risk),
                    _string(market.game_start_time),
                    market.game_id,
                    market.sports_market_type,
                    str(market.lifetime_volume),
                    str(market.liquidity),
                    _string(market.min_tick_size),
                    _string(market.min_order_size),
                    None if market.fees_enabled is None else int(market.fees_enabled),
                    _string(market.fee_rate),
                    _string(market.fee_exponent),
                    int(universe.hard_banned),
                    int(universe.eligible),
                    universe.reason,
                    now,
                    now,
                    run_id,
                    canonical_json(market.raw),
                ),
            )

    def insert_book_snapshot(
        self,
        run_id: int,
        market: MarketData,
        book: OrderBook,
        *,
        phase: str,
        top_levels: int,
    ) -> None:
        outcome = market.outcome_by_token(book.token_id)
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO book_snapshots(
                    run_id, observed_at, book_timestamp, capture_phase, market_id, token_id,
                    outcome_label, best_bid, best_ask, midpoint, spread, tick_size,
                    min_order_size, last_trade_price, book_hash, bids_json, asks_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    iso_utc(),
                    _string(book.timestamp),
                    phase,
                    market.market_id,
                    book.token_id,
                    outcome.label if outcome else None,
                    _string(book.best_bid),
                    _string(book.best_ask),
                    _string(book.midpoint),
                    _string(book.spread),
                    str(book.tick_size),
                    _string(book.min_order_size),
                    _string(book.last_trade_price),
                    book.book_hash,
                    canonical_json(
                        [level.model_dump(mode="json") for level in book.bids[:top_levels]]
                    ),
                    canonical_json(
                        [level.model_dump(mode="json") for level in book.asks[:top_levels]]
                    ),
                ),
            )

    def insert_rule_assessment(
        self,
        run_id: int,
        market_id: str,
        assessment: RuleAssessment,
    ) -> None:
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO rule_assessments(
                    run_id, market_id, observed_at, deterministic, supported,
                    adapter_id, ambiguity_score, reasons_json, rules_hash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    market_id,
                    iso_utc(),
                    int(assessment.deterministic),
                    int(assessment.supported),
                    assessment.adapter_id,
                    assessment.ambiguity_score,
                    canonical_json(assessment.reasons),
                    assessment.rules_hash,
                ),
            )

    def get_source_release(self, adapter_id: str, period: str) -> dict[str, Any] | None:
        with self.session() as connection:
            row = connection.execute(
                "SELECT * FROM source_releases WHERE adapter_id=? AND period=?",
                (adapter_id, period),
            ).fetchone()
        return dict(row) if row else None

    def save_source_release(
        self,
        *,
        adapter_id: str,
        period: str,
        value: Decimal,
        release_at: str | None,
        source_checksum: str,
        archive_path: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        now = iso_utc()
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO source_releases(
                    adapter_id, period, value, release_at, first_seen_at,
                    source_checksum, archive_path, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(adapter_id, period) DO NOTHING
                """,
                (
                    adapter_id,
                    period,
                    str(value),
                    release_at,
                    now,
                    source_checksum,
                    archive_path,
                    canonical_json(metadata),
                ),
            )
        saved = self.get_source_release(adapter_id, period)
        if saved is None:
            raise RuntimeError("Failed to save source release")
        return saved

    def insert_source_evidence(
        self,
        run_id: int,
        market_id: str,
        evidence: SourceEvidence,
    ) -> None:
        with self.transaction() as connection:
            connection.execute(
                """
                INSERT INTO source_evidence(
                    run_id, market_id, observed_at, adapter_id, status, period,
                    value, winning_side, winning_token_id, release_at, first_seen_at,
                    source_url, source_checksum, archive_path, reason, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    market_id,
                    iso_utc(),
                    evidence.adapter_id,
                    evidence.status,
                    evidence.period,
                    _string(evidence.value),
                    evidence.winning_side,
                    evidence.winning_token_id,
                    _string(evidence.release_at),
                    _string(evidence.first_seen_at),
                    evidence.source_url,
                    evidence.source_checksum,
                    evidence.archive_path,
                    evidence.reason,
                    canonical_json(evidence.metadata),
                ),
            )

    def insert_evaluation(self, run_id: int, evaluation: Evaluation) -> int:
        fill = evaluation.fill
        with self.transaction() as connection:
            cursor = connection.execute(
                """
                INSERT INTO evaluations(
                    run_id, observed_at, strategy, market_id, event_id, token_id,
                    outcome_label, decision, reason, reference_price, best_bid,
                    best_ask, midpoint, spread, hours_to_end, expected_payout,
                    net_edge_per_share, requested_notional, filled_shares,
                    raw_notional, fee, all_in_cost, effective_vwap,
                    all_in_cost_per_share, evidence_key, source_status,
                    fill_json, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    iso_utc(),
                    evaluation.strategy,
                    evaluation.market_id,
                    evaluation.event_id,
                    evaluation.token_id,
                    evaluation.outcome_label,
                    evaluation.decision,
                    evaluation.reason,
                    _string(evaluation.reference_price),
                    _string(evaluation.best_bid),
                    _string(evaluation.best_ask),
                    _string(evaluation.midpoint),
                    _string(evaluation.spread),
                    _string(evaluation.hours_to_end),
                    _string(evaluation.expected_payout),
                    _string(evaluation.net_edge_per_share),
                    _string(fill.requested_notional if fill else None),
                    _string(fill.shares if fill else None),
                    _string(fill.raw_notional if fill else None),
                    _string(fill.fee if fill else None),
                    _string(fill.all_in_cost if fill else None),
                    _string(fill.effective_vwap if fill else None),
                    _string(fill.all_in_cost_per_share if fill else None),
                    evaluation.evidence_key,
                    evaluation.source_status,
                    canonical_json(fill.model_dump(mode="json")) if fill else None,
                    canonical_json(evaluation.metadata),
                ),
            )
            return int(cursor.lastrowid)

    def paper_order_exists(
        self,
        *,
        strategy: str,
        market_id: str,
        token_id: str,
        evidence_key: str,
    ) -> bool:
        with self.session() as connection:
            row = connection.execute(
                """
                SELECT 1 FROM paper_orders
                WHERE strategy=? AND market_id=? AND token_id=? AND evidence_key=?
                LIMIT 1
                """,
                (strategy, market_id, token_id, evidence_key),
            ).fetchone()
        return row is not None

    def has_strategy_market_order(self, *, strategy: str, market_id: str) -> bool:
        with self.session() as connection:
            row = connection.execute(
                "SELECT 1 FROM paper_orders WHERE strategy=? AND market_id=? LIMIT 1",
                (strategy, market_id),
            ).fetchone()
        return row is not None

    def has_open_or_settled_event_order(self, *, strategy: str, event_id: str) -> bool:
        with self.session() as connection:
            row = connection.execute(
                "SELECT 1 FROM paper_orders WHERE strategy=? AND event_id=? LIMIT 1",
                (strategy, event_id),
            ).fetchone()
        return row is not None

    def strategy_available_equity(self, strategy: str, starting_equity: Decimal) -> Decimal:
        # Keep accounting in Decimal. SQLite REAL aggregation would introduce
        # binary floating-point drift into a tiny-edge strategy.
        with self.session() as connection:
            rows = connection.execute(
                "SELECT status, net_pnl, all_in_cost FROM paper_orders WHERE strategy=?",
                (strategy,),
            ).fetchall()
        realized = sum(
            (Decimal(str(row["net_pnl"])) for row in rows if row["status"] == "SETTLED" and row["net_pnl"] is not None),
            Decimal("0"),
        )
        locked = sum(
            (Decimal(str(row["all_in_cost"])) for row in rows if row["status"] == "OPEN"),
            Decimal("0"),
        )
        return starting_equity + realized - locked

    def insert_paper_order(self, run_id: int, evaluation: Evaluation) -> int | None:
        fill = evaluation.fill
        if evaluation.decision != "ORDER" or fill is None or not evaluation.token_id:
            raise ValueError("Only ORDER evaluations with fills can become paper orders")
        if fill.effective_vwap is None or fill.all_in_cost_per_share is None:
            raise ValueError("Paper order requires complete fill pricing")
        with self.transaction() as connection:
            try:
                cursor = connection.execute(
                    """
                    INSERT INTO paper_orders(
                        run_id, strategy, market_id, event_id, token_id,
                        outcome_label, created_at, evidence_key, source_status,
                        requested_notional, shares, raw_notional, fee, all_in_cost,
                        effective_vwap, all_in_cost_per_share, expected_payout,
                        expected_edge_per_share, fill_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        evaluation.strategy,
                        evaluation.market_id,
                        evaluation.event_id,
                        evaluation.token_id,
                        evaluation.outcome_label or "",
                        iso_utc(),
                        evaluation.evidence_key,
                        evaluation.source_status,
                        str(fill.requested_notional),
                        str(fill.shares),
                        str(fill.raw_notional),
                        str(fill.fee),
                        str(fill.all_in_cost),
                        str(fill.effective_vwap),
                        str(fill.all_in_cost_per_share),
                        _string(evaluation.expected_payout),
                        _string(evaluation.net_edge_per_share),
                        canonical_json(fill.model_dump(mode="json")),
                    ),
                )
            except sqlite3.IntegrityError:
                return None
            return int(cursor.lastrowid)

    def list_open_orders(self) -> list[dict[str, Any]]:
        with self.session() as connection:
            rows = connection.execute(
                "SELECT * FROM paper_orders WHERE status='OPEN' ORDER BY created_at"
            ).fetchall()
        return [dict(row) for row in rows]

    def settle_order(
        self,
        order_id: int,
        *,
        payout_per_share: Decimal,
        settlement_raw: dict[str, Any],
    ) -> None:
        with self.transaction() as connection:
            row = connection.execute(
                "SELECT shares, all_in_cost, status FROM paper_orders WHERE id=?",
                (order_id,),
            ).fetchone()
            if row is None or row["status"] != "OPEN":
                return
            shares = Decimal(str(row["shares"]))
            all_in_cost = Decimal(str(row["all_in_cost"]))
            gross = shares * payout_per_share
            pnl = gross - all_in_cost
            connection.execute(
                """
                UPDATE paper_orders
                SET status='SETTLED', payout_per_share=?, gross_payout=?, net_pnl=?,
                    settled_at=?, settlement_raw_json=?
                WHERE id=? AND status='OPEN'
                """,
                (
                    str(payout_per_share),
                    str(gross),
                    str(pnl),
                    iso_utc(),
                    canonical_json(settlement_raw),
                    order_id,
                ),
            )

    def recent_stream_token_ids(
        self,
        *,
        max_tokens: int,
        seen_within_hours: int = 24,
        horizon_hours: int = 168,
        post_end_grace_hours: int = 24,
    ) -> list[str]:
        cutoff = iso_utc(utc_now() - timedelta(hours=seen_within_hours))
        earliest_end = iso_utc(utc_now() - timedelta(hours=post_end_grace_hours))
        latest_end = iso_utc(utc_now() + timedelta(hours=horizon_hours))
        with self.session() as connection:
            rows = connection.execute(
                """
                SELECT outcomes_json
                FROM markets
                WHERE hard_banned=0 AND universe_eligible=1
                  AND accepting_orders=1 AND closed=0 AND last_seen_at>=?
                  AND end_date IS NOT NULL AND end_date BETWEEN ? AND ?
                ORDER BY end_date ASC
                LIMIT ?
                """,
                (cutoff, earliest_end, latest_end, max_tokens),
            ).fetchall()
        tokens: list[str] = []
        for row in rows:
            try:
                outcomes = json.loads(row["outcomes_json"])
            except json.JSONDecodeError:
                continue
            for outcome in outcomes:
                token = outcome.get("token_id") if isinstance(outcome, dict) else None
                if token:
                    tokens.append(str(token))
                    if len(tokens) >= max_tokens:
                        return tokens
        return tokens

    def scalar(self, query: str, params: tuple[Any, ...] = ()) -> Any:
        with self.session() as connection:
            row = connection.execute(query, params).fetchone()
        return row[0] if row else None

    def rows(self, query: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        with self.session() as connection:
            result = connection.execute(query, params).fetchall()
        return [dict(row) for row in result]
