from __future__ import annotations

from pathlib import Path
import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class AppSection(StrictModel):
    name: str = "ResolutionEdge"
    scan_interval_seconds: int = Field(default=30, ge=5)
    log_level: str = "INFO"
    status_path: Path
    database_path: Path
    evidence_dir: Path
    stream_dir: Path
    log_path: Path


class HttpSection(StrictModel):
    timeout_seconds: float = Field(default=15, gt=0)
    retries: int = Field(default=3, ge=0, le=10)
    backoff_seconds: float = Field(default=0.75, ge=0)
    user_agent: str


class PolymarketSection(StrictModel):
    gamma_base_url: str
    clob_base_url: str
    websocket_url: str
    geoblock_url: str


class UniverseSection(StrictModel):
    sports_hard_ban: bool = True
    hard_block_categories: list[str]
    strategy_block_categories: list[str]
    allowed_categories: list[str]

    @model_validator(mode="after")
    def enforce_permanent_sports_ban(self) -> "UniverseSection":
        if not self.sports_hard_ban:
            raise ValueError("ResolutionEdge V1 permanently requires universe.sports_hard_ban=true")
        normalized = {
            value.casefold().replace("-", "").replace("_", "").replace(" ", "")
            for value in self.hard_block_categories
        }
        missing = {"sports", "esports"} - normalized
        if missing:
            raise ValueError(
                "universe.hard_block_categories must permanently include sports and esports"
            )
        return self


class DiscoverySection(StrictModel):
    page_size: int = Field(default=500, ge=1, le=1000)
    max_pages: int = Field(default=20, ge=1, le=100)
    max_markets_per_scan: int = Field(default=1000, ge=1)
    horizon_hours: float = Field(default=168, gt=0)
    post_end_grace_hours: float = Field(default=24, ge=0)
    top_book_levels_to_store: int = Field(default=20, ge=1, le=200)
    sequential_book_fallback_limit: int = Field(default=50, ge=0, le=500)


class BaselineSection(StrictModel):
    enabled: bool = True
    reference_strategy_name: str
    executable_strategy_name: str
    min_favorite_price: float = Field(default=0.97, gt=0, lt=1)
    max_hours_to_end: float = Field(default=24, gt=0)
    post_end_grace_hours: float = Field(default=2, ge=0)
    min_lifetime_volume_usdc: float = Field(default=500, ge=0)
    stake_usdc: float = Field(default=10, gt=0)
    max_orders_per_scan_per_strategy: int = Field(default=3, ge=0)
    max_entry_price: float = Field(default=0.999, gt=0, lt=1)


class SourceConfirmedSection(StrictModel):
    enabled: bool = True
    strategy_name: str
    supported_adapters: list[str]
    conservative_payout_per_share: float = Field(default=0.995, gt=0, le=1)
    minimum_net_edge_per_share: float = Field(default=0.003, ge=0, lt=1)
    maximum_entry_price: float = Field(default=0.992, gt=0, lt=1)
    maximum_spread: float = Field(default=0.04, ge=0, lt=1)
    stake_usdc: float = Field(default=25, gt=0)
    maximum_orders_per_scan: int = Field(default=5, ge=0)
    one_order_per_event: bool = True
    evidence_fresh_hours: float = Field(default=48, gt=0)
    maximum_book_age_seconds: int = Field(default=30, ge=1, le=300)
    post_evidence_timestamp_tolerance_seconds: int = Field(default=5, ge=0, le=60)

    @model_validator(mode="after")
    def validate_edge_hurdle(self) -> "SourceConfirmedSection":
        if self.maximum_entry_price >= self.conservative_payout_per_share:
            raise ValueError(
                "source_confirmed.maximum_entry_price must be below conservative_payout_per_share"
            )
        return self


class PaperSection(StrictModel):
    starting_equity_usdc: float = Field(default=10_000, gt=0)
    minimum_fill_usdc: float = Field(default=5, gt=0)
    latency_slippage_ticks: int = Field(default=1, ge=0, le=20)
    visible_depth_haircut: float = Field(default=0.5, gt=0, le=1)
    allow_partial_fills: bool = True


class FeesSection(StrictModel):
    fallback_rates: dict[str, float]
    default_fallback_rate: float = Field(default=0.05, ge=0, le=1)


class BlsSection(StrictModel):
    summary_url: str
    table_a15_url: str
    archive_subdirectory: str
    timezone: str = "America/New_York"
    pre_release_fetch_minutes: int = Field(default=10, ge=0, le=120)
    current_release_cache_seconds: int = Field(default=10, ge=0)
    far_release_cache_seconds: int = Field(default=900, ge=30)
    require_summary_table_agreement: bool = True


class StreamSection(StrictModel):
    enabled: bool = True
    max_tokens: int = Field(default=500, ge=1, le=5000)
    refresh_subscription_seconds: int = Field(default=60, ge=10)
    heartbeat_seconds: int = Field(default=10, ge=3)
    reconnect_backoff_seconds: int = Field(default=3, ge=1)
    gzip_rotate_megabytes: int = Field(default=64, ge=1)


class Settings(StrictModel):
    project_root: Path
    config_path: Path
    app: AppSection
    http: HttpSection
    polymarket: PolymarketSection
    universe: UniverseSection
    discovery: DiscoverySection
    baseline: BaselineSection
    source_confirmed: SourceConfirmedSection
    paper: PaperSection
    fees: FeesSection
    bls: BlsSection
    stream: StreamSection

    @model_validator(mode="after")
    def validate_strategy_names(self) -> "Settings":
        names = {
            self.baseline.reference_strategy_name,
            self.baseline.executable_strategy_name,
            self.source_confirmed.strategy_name,
        }
        if len(names) != 3:
            raise ValueError("All three V1 strategy names must be unique")
        return self

    def ensure_directories(self) -> None:
        for path in (
            self.app.database_path.parent,
            self.app.status_path.parent,
            self.app.evidence_dir,
            self.app.stream_dir,
            self.app.log_path.parent,
        ):
            path.mkdir(parents=True, exist_ok=True)


def _project_root_for(config_path: Path) -> Path:
    parent = config_path.parent
    if parent.name == "config":
        return parent.parent
    return parent


def _resolve_paths(raw: dict, root: Path) -> dict:
    app = raw.setdefault("app", {})
    for key in ("status_path", "database_path", "evidence_dir", "stream_dir", "log_path"):
        path = Path(app[key]).expanduser()
        if not path.is_absolute():
            path = root / path
        app[key] = path.resolve()
    return raw


def load_settings(path: str | Path = "config/default.yaml") -> Settings:
    config_path = Path(path).expanduser().resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file does not exist: {config_path}")
    with config_path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    root = _project_root_for(config_path).resolve()
    raw = _resolve_paths(raw, root)
    raw["project_root"] = root
    raw["config_path"] = config_path
    settings = Settings.model_validate(raw)
    settings.ensure_directories()
    return settings
