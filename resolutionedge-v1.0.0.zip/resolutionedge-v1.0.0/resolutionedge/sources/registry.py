from __future__ import annotations

from resolutionedge.models import MarketData
from resolutionedge.sources.base import SourceAdapter


class SourceRegistry:
    def __init__(self, adapters: list[SourceAdapter]) -> None:
        self.adapters = {adapter.adapter_id: adapter for adapter in adapters}

    def get(self, adapter_id: str | None) -> SourceAdapter | None:
        if adapter_id is None:
            return None
        return self.adapters.get(adapter_id)

    def find(self, market: MarketData) -> SourceAdapter | None:
        return next((adapter for adapter in self.adapters.values() if adapter.supports(market)), None)
