from __future__ import annotations

from abc import ABC, abstractmethod

from resolutionedge.models import MarketData, SourceEvidence


class SourceAdapter(ABC):
    adapter_id: str

    @abstractmethod
    def supports(self, market: MarketData) -> bool:
        raise NotImplementedError

    @abstractmethod
    def evaluate(self, market: MarketData) -> SourceEvidence:
        raise NotImplementedError
