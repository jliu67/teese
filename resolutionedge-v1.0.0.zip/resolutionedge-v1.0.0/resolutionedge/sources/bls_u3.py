from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

from bs4 import BeautifulSoup
from dateutil import parser as date_parser

from resolutionedge.clients.http import HttpClient
from resolutionedge.config import BlsSection
from resolutionedge.models import MarketData, SourceEvidence
from resolutionedge.sources.base import SourceAdapter
from resolutionedge.storage import Database
from resolutionedge.utils import (
    atomic_write_text,
    iso_utc,
    month_key,
    normalize_space,
    parse_datetime,
    parse_month_name,
    period_compare,
    sha256_text,
    utc_now,
)

LOGGER = logging.getLogger(__name__)

MONTH_PATTERN = (
    r"(?:January|February|March|April|May|June|July|August|September|October|November|December|"
    r"Jan\.?|Feb\.?|Mar\.?|Apr\.?|Jun\.?|Jul\.?|Aug\.?|Sep\.?|Sept\.?|Oct\.?|Nov\.?|Dec\.?)"
)


@dataclass(frozen=True)
class Bucket:
    kind: str
    low: Decimal | None = None
    high: Decimal | None = None

    def matches(self, value: Decimal) -> bool:
        if self.kind == "exact":
            return self.low == value
        if self.kind == "lte":
            return self.high is not None and value <= self.high
        if self.kind == "gte":
            return self.low is not None and value >= self.low
        if self.kind == "range":
            return (
                self.low is not None
                and self.high is not None
                and self.low <= value <= self.high
            )
        raise ValueError(f"Unknown bucket kind: {self.kind}")

    def describe(self) -> str:
        if self.kind == "exact":
            return f"={self.low}%"
        if self.kind == "lte":
            return f"<={self.high}%"
        if self.kind == "gte":
            return f">={self.low}%"
        return f"{self.low}%..{self.high}%"


@dataclass(frozen=True)
class CurrentRelease:
    period: str
    value: Decimal
    release_at: datetime
    summary_value: Decimal | None
    table_value: Decimal
    summary_html: str
    table_html: str
    checksum: str
    metadata: dict[str, object]


class BlsU3Adapter(SourceAdapter):
    adapter_id = "bls_u3"

    def __init__(
        self,
        *,
        config: BlsSection,
        http: HttpClient,
        database: Database,
        evidence_root: Path,
    ) -> None:
        self.config = config
        self.http = http
        self.database = database
        self.evidence_root = evidence_root / config.archive_subdirectory
        self.evidence_root.mkdir(parents=True, exist_ok=True)
        self._cache: CurrentRelease | None = None
        self._cache_monotonic = 0.0

    def supports(self, market: MarketData) -> bool:
        text = " ".join(
            [market.rules, market.resolution_source, market.question, market.event_title]
        ).casefold()
        return all(
            needle in text
            for needle in (
                "unemployment rate",
                "employment situation",
            )
        ) and ("u-3" in text or "u 3" in text) and (
            "table a-15" in text or "table a 15" in text
        ) and ("bls.gov" in text or "bureau of labor statistics" in text)

    def evaluate(self, market: MarketData) -> SourceEvidence:
        if not self.supports(market):
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="UNSUPPORTED",
                reason="Market does not match strict BLS U-3/Table A-15 rules",
            )

        target_period = parse_target_period(market)
        bucket = parse_market_bucket(market)
        if target_period is None:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PARSE_ERROR",
                reason="Could not determine the target data month from the market rules",
            )
        if bucket is None:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PARSE_ERROR",
                period=target_period,
                reason="Could not parse the market's unemployment-rate bucket",
            )

        archived = self.database.get_source_release(self.adapter_id, target_period)
        if archived is not None:
            return self._evidence_from_release_row(market, bucket, archived)

        try:
            recovered_release = self._load_archived_release(target_period)
        except Exception as exc:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PARSE_ERROR",
                period=target_period,
                source_url=self.config.table_a15_url,
                reason=f"Existing first-seen BLS archive is incomplete or invalid: {exc}",
            )
        if recovered_release is not None:
            row = self._save_release_row(recovered_release)
            return self._evidence_from_release_row(market, bucket, row)

        now = utc_now()
        scheduled_release_at = parse_scheduled_release_at(market, self.config.timezone)
        if scheduled_release_at is not None and now < scheduled_release_at - timedelta(
            minutes=self.config.pre_release_fetch_minutes
        ):
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PENDING",
                period=target_period,
                release_at=scheduled_release_at,
                source_url=self.config.table_a15_url,
                reason=(
                    "Target BLS release is outside the configured pre-release fetch window; "
                    "no source request was made"
                ),
                metadata={"scheduled_release_at": iso_utc(scheduled_release_at)},
            )

        cache_seconds = (
            self.config.current_release_cache_seconds
            if scheduled_release_at is not None
            else self.config.far_release_cache_seconds
        )
        try:
            release = self._get_current_release(cache_seconds=cache_seconds)
        except Exception as exc:
            LOGGER.exception("BLS source parse failed")
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PARSE_ERROR",
                period=target_period,
                source_url=self.config.table_a15_url,
                reason=f"Could not fetch/verify the current BLS release: {exc}",
            )

        comparison = period_compare(target_period, release.period)
        if comparison > 0:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PENDING",
                period=target_period,
                release_at=scheduled_release_at or release.release_at,
                source_url=self.config.table_a15_url,
                source_checksum=release.checksum,
                reason=f"Target {target_period} has not been published; current release is {release.period}",
                metadata={
                    "current_release_period": release.period,
                    "scheduled_release_at": (
                        iso_utc(scheduled_release_at) if scheduled_release_at else None
                    ),
                },
            )
        if comparison < 0:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="HISTORICAL_UNAVAILABLE",
                period=target_period,
                source_url=self.config.table_a15_url,
                source_checksum=release.checksum,
                reason=(
                    f"Target {target_period} predates current release {release.period}, and no first-seen "
                    "snapshot exists. Current BLS tables can contain revisions, so V1 refuses to infer it."
                ),
                metadata={"current_release_period": release.period},
            )

        if utc_now() < release.release_at:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="PENDING",
                period=target_period,
                release_at=release.release_at,
                source_url=self.config.table_a15_url,
                source_checksum=release.checksum,
                reason="The BLS page identifies the target release, but its embargo time has not passed",
            )

        row = self._archive_release(release)
        return self._evidence_from_release_row(market, bucket, row)

    def _get_current_release(self, *, cache_seconds: int) -> CurrentRelease:
        now = time.monotonic()
        if self._cache is not None and now - self._cache_monotonic <= cache_seconds:
            return self._cache

        summary_response = self.http.get_text(self.config.summary_url)
        table_response = self.http.get_text(self.config.table_a15_url)
        release = parse_current_release(
            summary_response.text,
            table_response.text,
            timezone_name=self.config.timezone,
            require_agreement=self.config.require_summary_table_agreement,
        )
        metadata = dict(release.metadata)
        metadata.update(
            {
                "summary_url": self.config.summary_url,
                "table_a15_url": self.config.table_a15_url,
                "summary_etag": summary_response.headers.get("etag"),
                "summary_last_modified": summary_response.headers.get("last-modified"),
                "table_etag": table_response.headers.get("etag"),
                "table_last_modified": table_response.headers.get("last-modified"),
                "fetched_at": iso_utc(),
            }
        )
        release = CurrentRelease(
            period=release.period,
            value=release.value,
            release_at=release.release_at,
            summary_value=release.summary_value,
            table_value=release.table_value,
            summary_html=release.summary_html,
            table_html=release.table_html,
            checksum=release.checksum,
            metadata=metadata,
        )
        self._cache = release
        self._cache_monotonic = now
        return release

    def _archive_paths(self, period: str) -> tuple[Path, Path, Path, Path]:
        period_dir = self.evidence_root / period
        return (
            period_dir,
            period_dir / "employment_summary.html",
            period_dir / "table_a15.html",
            period_dir / "metadata.json",
        )

    def _load_archived_release(self, period: str) -> CurrentRelease | None:
        period_dir, summary_path, table_path, metadata_path = self._archive_paths(period)
        exists = (summary_path.exists(), table_path.exists(), metadata_path.exists())
        if not any(exists):
            return None
        if not summary_path.exists() or not table_path.exists():
            raise RuntimeError(
                f"partial archive at {period_dir}: both HTML source files are required"
            )

        summary_html = summary_path.read_text(encoding="utf-8")
        table_html = table_path.read_text(encoding="utf-8")
        parsed = parse_current_release(
            summary_html,
            table_html,
            timezone_name=self.config.timezone,
            require_agreement=self.config.require_summary_table_agreement,
        )
        if parsed.period != period:
            raise RuntimeError(
                f"archive directory {period} contains BLS release {parsed.period}"
            )
        metadata = dict(parsed.metadata)
        if metadata_path.exists():
            loaded = json.loads(metadata_path.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise RuntimeError("archive metadata is not a JSON object")
            metadata.update(loaded)
        metadata["source_checksum"] = parsed.checksum
        metadata["recovered_from_existing_archive"] = True
        if not metadata_path.exists():
            atomic_write_text(
                metadata_path,
                json.dumps(metadata, indent=2, sort_keys=True, default=str),
            )
        return CurrentRelease(
            period=parsed.period,
            value=parsed.value,
            release_at=parsed.release_at,
            summary_value=parsed.summary_value,
            table_value=parsed.table_value,
            summary_html=summary_html,
            table_html=table_html,
            checksum=parsed.checksum,
            metadata=metadata,
        )

    def _save_release_row(self, release: CurrentRelease) -> dict[str, object]:
        period_dir, _, _, _ = self._archive_paths(release.period)
        relative = str(period_dir.relative_to(self.evidence_root.parent))
        return self.database.save_source_release(
            adapter_id=self.adapter_id,
            period=release.period,
            value=release.value,
            release_at=iso_utc(release.release_at),
            source_checksum=release.checksum,
            archive_path=relative,
            metadata=release.metadata,
        )

    def _archive_release(self, release: CurrentRelease) -> dict[str, object]:
        existing = self._load_archived_release(release.period)
        if existing is not None:
            return self._save_release_row(existing)

        period_dir, summary_path, table_path, metadata_path = self._archive_paths(release.period)
        period_dir.mkdir(parents=True, exist_ok=True)
        metadata = dict(release.metadata)
        metadata["source_checksum"] = release.checksum
        effective = CurrentRelease(
            period=release.period,
            value=release.value,
            release_at=release.release_at,
            summary_value=release.summary_value,
            table_value=release.table_value,
            summary_html=release.summary_html,
            table_html=release.table_html,
            checksum=release.checksum,
            metadata=metadata,
        )

        # First-write wins. A partial archive is treated as a hard parse failure on
        # the next scan rather than being silently combined with a later revision.
        atomic_write_text(summary_path, effective.summary_html)
        atomic_write_text(table_path, effective.table_html)
        atomic_write_text(
            metadata_path,
            json.dumps(effective.metadata, indent=2, sort_keys=True, default=str),
        )
        return self._save_release_row(effective)

    def _evidence_from_release_row(
        self,
        market: MarketData,
        bucket: Bucket,
        row: dict[str, object],
    ) -> SourceEvidence:
        value = Decimal(str(row["value"]))
        winning_side = "YES" if bucket.matches(value) else "NO"
        outcome = market.outcome_for_side(winning_side)
        if outcome is None:
            return SourceEvidence(
                adapter_id=self.adapter_id,
                status="SOURCE_MISMATCH",
                period=str(row["period"]),
                value=value,
                winning_side=winning_side,
                reason=f"Market has no {winning_side} outcome token",
            )
        metadata: dict[str, object]
        try:
            metadata = json.loads(str(row.get("metadata_json") or "{}"))
        except json.JSONDecodeError:
            metadata = {}
        metadata.update(
            {
                "bucket_kind": bucket.kind,
                "bucket_description": bucket.describe(),
                "market_group_item_title": market.group_item_title,
            }
        )
        return SourceEvidence(
            adapter_id=self.adapter_id,
            status="FINAL",
            period=str(row["period"]),
            value=value,
            winning_side=winning_side,
            winning_token_id=outcome.token_id,
            release_at=parse_datetime(row.get("release_at")),
            first_seen_at=parse_datetime(row.get("first_seen_at")),
            source_url=self.config.table_a15_url,
            source_checksum=str(row.get("source_checksum") or ""),
            archive_path=str(row.get("archive_path") or ""),
            reason=(
                f"Official BLS Table A-15 U-3 value for {row['period']} is {value}%; "
                f"bucket {bucket.describe()} resolves {winning_side}"
            ),
            metadata=metadata,
        )


def parse_scheduled_release_at(market: MarketData, timezone_name: str) -> datetime | None:
    """Parse a rule-stated BLS release timestamp such as September 4, 2026 at 8:30 AM ET."""
    text = normalize_space(market.rules)
    match = re.search(
        rf"(?:release|data).*?scheduled.*?(?:for|on)\s+"
        rf"({MONTH_PATTERN}\s+\d{{1,2}},\s+20\d{{2}})\s*,?\s*"
        rf"(?:at\s+)?(\d{{1,2}}:\d{{2}})\s*([ap])\.?m\.?\s*(?:\(ET\)|ET)\b",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return None
    date_text, clock, am_pm = match.group(1), match.group(2), match.group(3).lower()
    naive = date_parser.parse(f"{date_text} {clock} {am_pm}m")
    localized = naive.replace(tzinfo=ZoneInfo(timezone_name))
    return localized.astimezone(UTC)


def parse_target_period(market: MarketData) -> str | None:
    # Rules are preferred because the event title can omit the year and the end date can fall next month/year.
    rules_patterns = (
        rf"(?:report(?:ed)?|data|rate).*?for\s+({MONTH_PATTERN})\s+(20\d{{2}})",
        rf"for\s+({MONTH_PATTERN})\s+(20\d{{2}})",
        rf"({MONTH_PATTERN})\s+(20\d{{2}})\s+(?:employment|unemployment)",
    )
    for pattern in rules_patterns:
        match = re.search(pattern, market.rules, flags=re.IGNORECASE | re.DOTALL)
        if match:
            month = parse_month_name(match.group(1).replace(".", ""))
            if month:
                return month_key(int(match.group(2)), month)

    combined = " ".join([market.event_title, market.question, market.group_item_title])
    match = re.search(rf"\b({MONTH_PATTERN})\b", combined, flags=re.IGNORECASE)
    if match:
        month = parse_month_name(match.group(1).replace(".", ""))
        explicit_year = re.search(r"\b(20\d{2})\b", combined)
        if month and explicit_year:
            return month_key(int(explicit_year.group(1)), month)
        if month and market.end_date:
            year = market.end_date.year
            # If a December data release resolves in January, end-date year is one too high.
            if month == 12 and market.end_date.month == 1:
                year -= 1
            return month_key(year, month)
    return None


def parse_market_bucket(market: MarketData) -> Bucket | None:
    candidates = [market.group_item_title, market.question, market.slug]
    for text in candidates:
        if not text:
            continue
        bucket = parse_bucket_text(text)
        if bucket is not None:
            return bucket
    return None


def parse_bucket_text(text: str) -> Bucket | None:
    normalized = text.replace("−", "-").replace("–", "-").replace("—", "-")
    number = r"(\d+(?:\.\d+)?)"

    match = re.search(rf"(?:≤|<=|at most|no more than)\s*{number}\s*%", normalized, re.I)
    if match:
        return Bucket(kind="lte", high=Decimal(match.group(1)))
    match = re.search(rf"{number}\s*%\s*(?:or lower|or less|and below)", normalized, re.I)
    if match:
        return Bucket(kind="lte", high=Decimal(match.group(1)))

    match = re.search(rf"(?:≥|>=|at least|no less than)\s*{number}\s*%", normalized, re.I)
    if match:
        return Bucket(kind="gte", low=Decimal(match.group(1)))
    match = re.search(rf"{number}\s*%\s*(?:or higher|or more|and above)", normalized, re.I)
    if match:
        return Bucket(kind="gte", low=Decimal(match.group(1)))

    match = re.search(
        rf"(?:between\s*)?{number}\s*%?\s*(?:to|through|-)\s*{number}\s*%",
        normalized,
        re.I,
    )
    if match:
        low, high = Decimal(match.group(1)), Decimal(match.group(2))
        return Bucket(kind="range", low=min(low, high), high=max(low, high))

    percentages = re.findall(rf"{number}\s*%", normalized)
    if len(percentages) == 1:
        return Bucket(kind="exact", low=Decimal(percentages[0]))
    return None


def parse_current_release(
    summary_html: str,
    table_html: str,
    *,
    timezone_name: str,
    require_agreement: bool,
) -> CurrentRelease:
    summary_text = normalize_space(BeautifulSoup(summary_html, "html.parser").get_text(" "))
    table_soup = BeautifulSoup(table_html, "html.parser")
    table_text = normalize_space(table_soup.get_text(" "))

    period_match = re.search(
        rf"THE\s+EMPLOYMENT\s+SITUATION\s*[-:]\s*({MONTH_PATTERN})\s+(20\d{{2}})",
        summary_text,
        flags=re.IGNORECASE,
    )
    if not period_match:
        raise ValueError("Could not parse report period from BLS Employment Situation summary")
    month = parse_month_name(period_match.group(1).replace(".", ""))
    if month is None:
        raise ValueError("Could not parse BLS report month")
    period = month_key(int(period_match.group(2)), month)

    table_period = _parse_table_latest_period(table_text)
    if table_period != period:
        raise ValueError(
            f"BLS release-period mismatch: summary is {period}, Table A-15 is {table_period or 'unparseable'}"
        )

    summary_value = _parse_summary_unemployment(summary_text)
    table_value = _parse_table_u3(table_soup)
    if require_agreement and summary_value is None:
        raise ValueError("Could not parse unemployment rate from BLS summary")
    if require_agreement and summary_value != table_value:
        raise ValueError(
            f"BLS source mismatch: summary says {summary_value}, Table A-15 says {table_value}"
        )

    release_at = _parse_embargo_timestamp(summary_text, timezone_name)
    if release_at is None:
        raise ValueError("Could not parse the BLS embargo/release timestamp; refusing source finality")
    checksum = sha256_text(summary_html + "\0" + table_html)
    metadata: dict[str, object] = {
        "period": period,
        "value": str(table_value),
        "summary_value": str(summary_value) if summary_value is not None else None,
        "table_value": str(table_value),
        "table_period": table_period,
        "release_at": iso_utc(release_at) if release_at else None,
        "table_last_modified_text": _parse_last_modified(table_text),
        "parser_version": "bls_u3_v1",
    }
    return CurrentRelease(
        period=period,
        value=table_value,
        release_at=release_at,
        summary_value=summary_value,
        table_value=table_value,
        summary_html=summary_html,
        table_html=table_html,
        checksum=checksum,
        metadata=metadata,
    )


def _parse_table_latest_period(text: str) -> str | None:
    # Only inspect the header portion; row labels can contain unrelated years.
    header = re.split(r"\bU\s*[-–]?\s*1\b", text, maxsplit=1, flags=re.IGNORECASE)[0]
    matches = list(
        re.finditer(
            rf"\b({MONTH_PATTERN})\s+(20\d{{2}})\b",
            header,
            flags=re.IGNORECASE,
        )
    )
    if not matches:
        return None
    match = matches[-1]
    month = parse_month_name(match.group(1).replace(".", ""))
    if month is None:
        return None
    return month_key(int(match.group(2)), month)


def _parse_summary_unemployment(text: str) -> Decimal | None:
    patterns = (
        r"unemployment rate\s*\(\s*(\d+(?:\.\d+)?)\s*percent\s*\)",
        r"unemployment rate\s*,?\s*(?:was|at|of)?\s*(\d+(?:\.\d+)?)\s*percent",
    )
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return Decimal(match.group(1))
    return None


def _parse_table_u3(soup: BeautifulSoup) -> Decimal:
    for row in soup.find_all("tr"):
        row_text = normalize_space(row.get_text(" "))
        if not re.match(r"^U\s*[-–]?\s*3\b", row_text, flags=re.IGNORECASE):
            continue
        cells = [normalize_space(cell.get_text(" ")) for cell in row.find_all(["th", "td"])]
        values: list[Decimal] = []
        for cell in cells[1:]:
            if re.fullmatch(r"-?\d+(?:\.\d+)?", cell):
                values.append(Decimal(cell))
        if not values:
            # Fallback for simplified HTML fixtures or future markup changes.
            values = [Decimal(value) for value in re.findall(r"\b\d+(?:\.\d+)?\b", row_text)[1:]]
        if not values:
            raise ValueError("Found U-3 row but no numeric values")
        value = values[-1]
        if value < 0 or value > 30:
            raise ValueError(f"Implausible U-3 unemployment rate: {value}")
        return value
    raise ValueError("Could not locate U-3 row in BLS Table A-15")


def _parse_embargo_timestamp(text: str, timezone_name: str) -> datetime | None:
    match = re.search(
        rf"embargoed\s+until.*?(\d{{1,2}}:\d{{2}})\s*([ap])\.?m\.?\s*\(ET\)\s*"
        rf"(?:[A-Za-z]+,\s*)?({MONTH_PATTERN}\s+\d{{1,2}},\s+20\d{{2}})",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return None
    clock, am_pm, date_text = match.group(1), match.group(2).lower(), match.group(3)
    naive = date_parser.parse(f"{date_text} {clock} {am_pm}m")
    local = naive.replace(tzinfo=ZoneInfo(timezone_name))
    return local.astimezone(UTC)


def _parse_last_modified(text: str) -> str | None:
    match = re.search(r"Last Modified Date:\s*([A-Za-z]+\s+\d{1,2},\s+20\d{2})", text, re.I)
    return match.group(1) if match else None
