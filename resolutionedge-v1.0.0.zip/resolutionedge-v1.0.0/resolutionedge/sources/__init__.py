"""Deterministic resolution-source adapters."""
