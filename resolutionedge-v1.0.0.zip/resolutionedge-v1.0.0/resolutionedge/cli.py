from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table

from resolutionedge import __version__
from resolutionedge.clients.http import HttpClient
from resolutionedge.config import Settings, load_settings
from resolutionedge.engine import ResolutionEdgeEngine
from resolutionedge.reporting import (
    print_candidates,
    print_progress,
    print_report,
    print_universe_audit,
)
from resolutionedge.sources.bls_u3 import parse_current_release
from resolutionedge.storage import Database
from resolutionedge.stream import run_stream_recorder

app = typer.Typer(
    name="resolutionedge",
    help="Forward-only Polymarket capture and paper-research engine. V1 has no live trading path.",
    no_args_is_help=True,
)
console = Console()
ConfigOption = Annotated[
    Path,
    typer.Option("--config", "-c", help="YAML configuration path", exists=True, dir_okay=False),
]
ModeOption = Annotated[
    str,
    typer.Option("--mode", help="capture or paper"),
]


def _settings(path: Path) -> Settings:
    return load_settings(path)


def _configure_logging(settings: Settings, *, verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else getattr(logging, settings.app.log_level.upper(), logging.INFO)
    handlers: list[logging.Handler] = [RichHandler(console=console, show_path=False)]
    file_handler = logging.FileHandler(settings.app.log_path, encoding="utf-8")
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    handlers.append(file_handler)
    logging.basicConfig(level=level, handlers=handlers, force=True)


def _validate_mode(mode: str) -> str:
    normalized = mode.casefold().strip()
    if normalized not in {"capture", "paper"}:
        raise typer.BadParameter("V1 supports only capture or paper. There is no live mode.")
    return normalized


@app.command("version")
def version_command() -> None:
    console.print(f"ResolutionEdge {__version__} (paper-only V1)")


@app.command("init")
def init_command(config: ConfigOption = Path("config/default.yaml")) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    console.print(f"Initialized database: {settings.app.database_path}")
    console.print(f"Sports hard ban: {settings.universe.sports_hard_ban}")
    console.print("Live trading: unavailable by design")


@app.command("scan")
def scan_command(
    mode: ModeOption = "paper",
    config: ConfigOption = Path("config/default.yaml"),
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    settings = _settings(config)
    _configure_logging(settings, verbose=verbose)
    engine = ResolutionEdgeEngine(settings)
    try:
        stats = engine.scan_once(mode=_validate_mode(mode))
    finally:
        engine.close()
    console.print_json(json.dumps(stats, default=str))


@app.command("run")
def run_command(
    mode: ModeOption = "paper",
    config: ConfigOption = Path("config/default.yaml"),
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    settings = _settings(config)
    _configure_logging(settings, verbose=verbose)
    engine = ResolutionEdgeEngine(settings)
    console.print(
        f"Starting ResolutionEdge {__version__} in {_validate_mode(mode)} mode. "
        "No real-order code exists in V1."
    )
    try:
        engine.run_forever(mode=_validate_mode(mode))
    finally:
        engine.close()


@app.command("stream")
def stream_command(
    config: ConfigOption = Path("config/default.yaml"),
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    settings = _settings(config)
    _configure_logging(settings, verbose=verbose)
    database = Database(settings.app.database_path)
    console.print("Starting raw non-sports CLOB stream archive. Press Ctrl-C to stop.")
    try:
        asyncio.run(run_stream_recorder(settings, database))
    except KeyboardInterrupt:
        pass


@app.command("progress")
def progress_command(config: ConfigOption = Path("config/default.yaml")) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    print_progress(settings, database, console)


@app.command("report")
def report_command(config: ConfigOption = Path("config/default.yaml")) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    print_report(settings, database, console)


@app.command("candidates")
def candidates_command(
    limit: Annotated[int, typer.Option("--limit", "-n", min=1, max=500)] = 30,
    config: ConfigOption = Path("config/default.yaml"),
) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    print_candidates(database, limit=limit, console=console)


@app.command("universe")
def universe_command(config: ConfigOption = Path("config/default.yaml")) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    print_universe_audit(database, console)


@app.command("doctor")
def doctor_command(
    config: ConfigOption = Path("config/default.yaml"),
    offline: Annotated[bool, typer.Option("--offline", help="Only validate local installation")] = False,
) -> None:
    settings = _settings(config)
    database = Database(settings.app.database_path)
    database.initialize()
    checks: list[tuple[str, bool, str]] = []
    checks.append(("Configuration", True, str(settings.config_path)))
    checks.append(("Database", settings.app.database_path.exists(), str(settings.app.database_path)))
    checks.append(
        (
            "Sports hard ban",
            settings.universe.sports_hard_ban and {"sports", "esports"}.issubset(
                {item.casefold() for item in settings.universe.hard_block_categories}
            ),
            "must remain enabled",
        )
    )
    checks.append(("Live order module", not (settings.project_root / "resolutionedge/execution/live.py").exists(), "absent by design"))

    if not offline:
        with HttpClient(
            timeout_seconds=settings.http.timeout_seconds,
            retries=settings.http.retries,
            backoff_seconds=settings.http.backoff_seconds,
            user_agent=settings.http.user_agent,
        ) as http:
            try:
                payload = http.get_json(f"{settings.polymarket.clob_base_url}/time")
                checks.append(("Polymarket CLOB", payload is not None, str(payload)))
            except Exception as exc:
                checks.append(("Polymarket CLOB", False, str(exc)))
            try:
                payload = http.get_json(
                    f"{settings.polymarket.gamma_base_url}/markets",
                    params={"active": "true", "closed": "false", "limit": 1},
                )
                checks.append(("Polymarket Gamma", isinstance(payload, list), f"records={len(payload) if isinstance(payload, list) else '?'}"))
            except Exception as exc:
                checks.append(("Polymarket Gamma", False, str(exc)))
            try:
                summary = http.get_text(settings.bls.summary_url).text
                table = http.get_text(settings.bls.table_a15_url).text
                release = parse_current_release(
                    summary,
                    table,
                    timezone_name=settings.bls.timezone,
                    require_agreement=settings.bls.require_summary_table_agreement,
                )
                checks.append(("BLS U-3 parser", True, f"{release.period}={release.value}%"))
            except Exception as exc:
                checks.append(("BLS U-3 parser", False, str(exc)))
            try:
                payload = http.get_json(settings.polymarket.geoblock_url)
                checks.append(("Geoblock lookup", isinstance(payload, dict), str(payload)))
            except Exception as exc:
                checks.append(("Geoblock lookup", False, str(exc)))

    table = Table(title="ResolutionEdge Doctor")
    table.add_column("Check")
    table.add_column("Result")
    table.add_column("Detail")
    failed = False
    for name, ok, detail in checks:
        failed |= not ok
        table.add_row(name, "PASS" if ok else "FAIL", detail[:120])
    console.print(table)
    if failed:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
