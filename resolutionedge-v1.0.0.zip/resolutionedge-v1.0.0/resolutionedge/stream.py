from __future__ import annotations

import asyncio
import gzip
import json
import logging
import os
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import websockets

from resolutionedge.config import Settings
from resolutionedge.storage import Database
from resolutionedge.utils import atomic_write_text, canonical_json, iso_utc

LOGGER = logging.getLogger(__name__)


class RotatingGzipJsonl:
    def __init__(self, directory: Path, *, rotate_megabytes: int) -> None:
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.rotate_bytes = rotate_megabytes * 1024 * 1024
        self.path: Path | None = None
        self.handle: gzip.GzipFile | None = None
        self._opened_monotonic = 0.0

    def _open(self) -> None:
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S.%fZ")
        self.path = self.directory / f"clob-market-{stamp}-{os.getpid()}.jsonl.gz"
        self.handle = gzip.open(self.path, mode="at", encoding="utf-8", compresslevel=5)
        self._opened_monotonic = time.monotonic()

    def write(self, value: dict[str, Any]) -> None:
        if self.handle is None:
            self._open()
        assert self.handle is not None
        self.handle.write(canonical_json(value) + "\n")
        self.handle.flush()
        if self.path and self.path.exists() and self.path.stat().st_size >= self.rotate_bytes:
            self.close()

    def close(self) -> None:
        if self.handle is not None:
            self.handle.close()
            self.handle = None


async def run_stream_recorder(settings: Settings, database: Database) -> None:
    """Archive raw CLOB market messages for non-sports, objective-universe tokens."""
    database.initialize()
    writer = RotatingGzipJsonl(
        settings.app.stream_dir,
        rotate_megabytes=settings.stream.gzip_rotate_megabytes,
    )
    status_path = settings.app.status_path.with_name("stream_status.json")
    reconnects = 0
    messages = 0
    try:
        while True:
            token_ids = database.recent_stream_token_ids(
                max_tokens=settings.stream.max_tokens,
                horizon_hours=int(settings.discovery.horizon_hours),
                post_end_grace_hours=int(settings.discovery.post_end_grace_hours),
            )
            if not token_ids:
                _write_stream_status(
                    status_path,
                    state="WAITING_FOR_TOKENS",
                    token_count=0,
                    messages=messages,
                    reconnects=reconnects,
                    error=None,
                )
                await asyncio.sleep(min(10, settings.stream.refresh_subscription_seconds))
                continue

            try:
                async with websockets.connect(
                    settings.polymarket.websocket_url,
                    ping_interval=None,
                    close_timeout=5,
                    max_size=None,
                ) as socket:
                    await socket.send(
                        json.dumps(
                            {
                                "assets_ids": token_ids,
                                "type": "market",
                                "custom_feature_enabled": True,
                            }
                        )
                    )
                    _write_stream_status(
                        status_path,
                        state="CONNECTED",
                        token_count=len(token_ids),
                        messages=messages,
                        reconnects=reconnects,
                        error=None,
                    )
                    connected_at = time.monotonic()
                    next_heartbeat = time.monotonic() + settings.stream.heartbeat_seconds
                    while time.monotonic() - connected_at < settings.stream.refresh_subscription_seconds:
                        timeout = max(0.1, next_heartbeat - time.monotonic())
                        try:
                            raw = await asyncio.wait_for(socket.recv(), timeout=timeout)
                        except TimeoutError:
                            await socket.send("PING")
                            next_heartbeat = time.monotonic() + settings.stream.heartbeat_seconds
                            continue
                        received_at = iso_utc()
                        if raw == "PONG":
                            continue
                        if isinstance(raw, bytes):
                            raw_text = raw.decode("utf-8", errors="replace")
                        else:
                            raw_text = str(raw)
                        try:
                            payload: Any = json.loads(raw_text)
                        except json.JSONDecodeError:
                            payload = {"raw": raw_text}
                        writer.write({"received_at": received_at, "payload": payload})
                        messages += 1
                        if time.monotonic() >= next_heartbeat:
                            await socket.send("PING")
                            next_heartbeat = time.monotonic() + settings.stream.heartbeat_seconds
                        if messages % 100 == 0:
                            _write_stream_status(
                                status_path,
                                state="CONNECTED",
                                token_count=len(token_ids),
                                messages=messages,
                                reconnects=reconnects,
                                error=None,
                            )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                reconnects += 1
                LOGGER.warning("Market stream disconnected: %s", exc)
                _write_stream_status(
                    status_path,
                    state="RECONNECTING",
                    token_count=len(token_ids),
                    messages=messages,
                    reconnects=reconnects,
                    error=f"{type(exc).__name__}: {exc}",
                )
                await asyncio.sleep(settings.stream.reconnect_backoff_seconds)
    finally:
        writer.close()
        _write_stream_status(
            status_path,
            state="STOPPED",
            token_count=0,
            messages=messages,
            reconnects=reconnects,
            error=None,
        )


def _write_stream_status(
    path: Path,
    *,
    state: str,
    token_count: int,
    messages: int,
    reconnects: int,
    error: str | None,
) -> None:
    atomic_write_text(
        path,
        canonical_json(
            {
                "state": state,
                "updated_at": iso_utc(),
                "paper_only": True,
                "sports_hard_ban": True,
                "token_count": token_count,
                "messages": messages,
                "reconnects": reconnects,
                "error": error,
            }
        )
        + "\n",
    )
