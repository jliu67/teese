from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from resolutionedge.config import Settings
from resolutionedge.storage import Database


def _money(value: Any) -> str:
    if value in (None, ""):
        return "—"
    try:
        return f"${Decimal(str(value)):,.2f}"
    except Exception:
        return str(value)


def _number(value: Any, places: int = 4) -> str:
    if value in (None, ""):
        return "—"
    try:
        return f"{Decimal(str(value)):.{places}f}"
    except Exception:
        return str(value)


def load_runtime_status(path: Path) -> dict[str, Any] | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def print_progress(settings: Settings, database: Database, console: Console | None = None) -> None:
    console = console or Console()
    status = load_runtime_status(settings.app.status_path)
    if status is None:
        console.print(Panel("No runtime status exists yet. Run `resolutionedge scan` first."))
    else:
        table = Table(title=f"{status.get('application', 'ResolutionEdge')} V{status.get('version', '?')}")
        table.add_column("Metric")
        table.add_column("Value", justify="right")
        table.add_row("State", str(status.get("state", "—")))
        table.add_row("Mode", str(status.get("mode", "—")))
        table.add_row("Paper only", str(status.get("paper_only", True)))
        table.add_row("Sports hard ban", str(status.get("sports_hard_ban", True)))
        table.add_row("PID", str(status.get("pid", "—")))
        table.add_row("Run", str(status.get("run_id", "—")))
        table.add_row("Updated", str(status.get("updated_at", "—")))
        stats = status.get("stats") if isinstance(status.get("stats"), dict) else {}
        for key in (
            "markets_seen",
            "sports_hard_banned",
            "objective_eligible",
            "within_horizon",
            "rule_supported",
            "books_received",
            "book_errors",
            "paper_orders_created",
            "paper_orders_settled",
            "duration_seconds",
        ):
            if key in stats:
                table.add_row(key.replace("_", " ").title(), str(stats[key]))
        if status.get("message"):
            table.add_row("Message", str(status["message"]))
        console.print(table)

    last_run = database.rows(
        "SELECT id, mode, started_at, finished_at, status, error FROM runs ORDER BY id DESC LIMIT 1"
    )
    if last_run:
        row = last_run[0]
        console.print(
            f"Last database run: #{row['id']} {row['mode']} {row['status']} "
            f"({row['started_at']} → {row['finished_at'] or 'running'})"
        )
        if row.get("error"):
            console.print(f"Error: {row['error']}")


def print_report(settings: Settings, database: Database, console: Console | None = None) -> None:
    console = console or Console()
    rows = database.rows(
        """
        SELECT
            strategy,
            COUNT(*) AS orders,
            SUM(CASE WHEN status='OPEN' THEN 1 ELSE 0 END) AS open_orders,
            SUM(CASE WHEN status='SETTLED' THEN 1 ELSE 0 END) AS settled_orders,
            SUM(CASE WHEN status='SETTLED' AND CAST(net_pnl AS REAL)>0 THEN 1 ELSE 0 END) AS wins,
            SUM(CASE WHEN status='SETTLED' AND CAST(net_pnl AS REAL)<0 THEN 1 ELSE 0 END) AS losses,
            COALESCE(SUM(CASE WHEN status='OPEN' THEN CAST(all_in_cost AS REAL) ELSE 0 END),0) AS locked,
            COALESCE(SUM(CASE WHEN status='SETTLED' THEN CAST(all_in_cost AS REAL) ELSE 0 END),0) AS settled_cost,
            COALESCE(SUM(CASE WHEN status='SETTLED' THEN CAST(gross_payout AS REAL) ELSE 0 END),0) AS gross_payout,
            COALESCE(SUM(CASE WHEN status='SETTLED' THEN CAST(net_pnl AS REAL) ELSE 0 END),0) AS net_pnl,
            AVG(CAST(all_in_cost_per_share AS REAL)) AS avg_all_in_price
        FROM paper_orders
        GROUP BY strategy
        ORDER BY strategy
        """
    )
    table = Table(title="ResolutionEdge Paper Strategy Report")
    table.add_column("Strategy")
    table.add_column("Orders", justify="right")
    table.add_column("Open", justify="right")
    table.add_column("Settled", justify="right")
    table.add_column("W/L", justify="right")
    table.add_column("Avg all-in", justify="right")
    table.add_column("Locked", justify="right")
    table.add_column("Net P&L", justify="right")
    table.add_column("ROI", justify="right")
    if not rows:
        table.add_row("No paper orders yet", "0", "0", "0", "—", "—", "$0.00", "$0.00", "—")
    for row in rows:
        settled_cost = Decimal(str(row["settled_cost"] or 0))
        pnl = Decimal(str(row["net_pnl"] or 0))
        roi = pnl / settled_cost * Decimal("100") if settled_cost else None
        table.add_row(
            str(row["strategy"]),
            str(row["orders"]),
            str(row["open_orders"] or 0),
            str(row["settled_orders"] or 0),
            f"{row['wins'] or 0}/{row['losses'] or 0}",
            _number(row["avg_all_in_price"]),
            _money(row["locked"]),
            _money(row["net_pnl"]),
            f"{roi:.2f}%" if roi is not None else "—",
        )
    console.print(table)

    source_rows = database.rows(
        """
        SELECT status, COUNT(*) AS n
        FROM source_evidence
        GROUP BY status
        ORDER BY n DESC
        """
    )
    source_table = Table(title="Source Evidence Observations")
    source_table.add_column("Status")
    source_table.add_column("Count", justify="right")
    if not source_rows:
        source_table.add_row("No supported-source observations yet", "0")
    else:
        for row in source_rows:
            source_table.add_row(str(row["status"]), str(row["n"]))
    console.print(source_table)

    reject_rows = database.rows(
        """
        SELECT strategy, decision, reason, COUNT(*) AS n
        FROM evaluations
        WHERE decision != 'ORDER'
        GROUP BY strategy, decision, reason
        ORDER BY n DESC
        LIMIT 12
        """
    )
    reject_table = Table(title="Most Common Non-Order Decisions")
    reject_table.add_column("Strategy")
    reject_table.add_column("Decision")
    reject_table.add_column("Reason")
    reject_table.add_column("Count", justify="right")
    if not reject_rows:
        reject_table.add_row("—", "—", "No evaluations yet", "0")
    else:
        for row in reject_rows:
            reject_table.add_row(
                str(row["strategy"]), str(row["decision"]), str(row["reason"]), str(row["n"])
            )
    console.print(reject_table)


def print_candidates(
    database: Database,
    *,
    limit: int = 30,
    console: Console | None = None,
) -> None:
    console = console or Console()
    rows = database.rows(
        """
        SELECT e.observed_at, e.strategy, e.decision, e.outcome_label,
               e.reference_price, e.best_ask, e.all_in_cost_per_share,
               e.net_edge_per_share, e.source_status, e.reason,
               m.event_title, m.question, m.group_item_title
        FROM evaluations e
        JOIN markets m ON m.market_id=e.market_id
        WHERE e.decision IN ('ORDER','OBSERVE')
        ORDER BY e.id DESC
        LIMIT ?
        """,
        (limit,),
    )
    table = Table(title=f"Latest {limit} Candidates / Observations")
    table.add_column("Time")
    table.add_column("Strategy")
    table.add_column("Decision")
    table.add_column("Market")
    table.add_column("Side")
    table.add_column("Ref")
    table.add_column("Ask")
    table.add_column("All-in")
    table.add_column("Edge")
    table.add_column("Reason")
    if not rows:
        table.add_row("—", "—", "—", "No candidates yet", "—", "—", "—", "—", "—", "—")
    for row in rows:
        label = row.get("group_item_title") or row.get("question") or row.get("event_title") or "—"
        table.add_row(
            str(row["observed_at"]),
            str(row["strategy"]),
            str(row["decision"]),
            str(label)[:48],
            str(row.get("outcome_label") or "—"),
            _number(row.get("reference_price"), 3),
            _number(row.get("best_ask"), 3),
            _number(row.get("all_in_cost_per_share"), 4),
            _number(row.get("net_edge_per_share"), 4),
            str(row.get("reason") or "")[:80],
        )
    console.print(table)


def print_universe_audit(database: Database, console: Console | None = None) -> None:
    console = console or Console()
    rows = database.rows(
        """
        SELECT universe_reason, COUNT(*) AS n
        FROM markets
        GROUP BY universe_reason
        ORDER BY n DESC
        """
    )
    table = Table(title="Latest Stored Universe Classification")
    table.add_column("Classification")
    table.add_column("Markets", justify="right")
    if not rows:
        table.add_row("No markets stored", "0")
    for row in rows:
        table.add_row(str(row["universe_reason"]), str(row["n"]))
    console.print(table)
