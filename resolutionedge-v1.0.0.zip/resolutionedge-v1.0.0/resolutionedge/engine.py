from __future__ import annotations

import logging
import os
import signal
import time
from collections import Counter, defaultdict
from datetime import timedelta
from decimal import Decimal
from typing import Any, Iterable

from resolutionedge import __version__
from resolutionedge.clients.clob import ClobClient
from resolutionedge.clients.gamma import GammaClient
from resolutionedge.clients.http import HttpClient
from resolutionedge.config import Settings
from resolutionedge.models import Evaluation, MarketData, OrderBook, RuleAssessment, SourceEvidence
from resolutionedge.rules import assess_rules, market_semantic_hash
from resolutionedge.sources.bls_u3 import BlsU3Adapter
from resolutionedge.sources.registry import SourceRegistry
from resolutionedge.storage import Database
from resolutionedge.strategy.evaluator import (
    evaluate_hf97_executable,
    evaluate_hf97_reference,
    evaluate_source_confirmed,
    favorite_by_reference,
    hours_to_end,
)
from resolutionedge.universe import classify_universe
from resolutionedge.utils import atomic_write_text, canonical_json, iso_utc, sha256_bytes, utc_now

LOGGER = logging.getLogger(__name__)


class ResolutionEdgeEngine:
    """One-process scanner and paper-research engine.

    V1 intentionally exposes no real-order path. All "orders" written by this
    class are shadow entries in SQLite.
    """

    def __init__(
        self,
        settings: Settings,
        *,
        database: Database | None = None,
        http: HttpClient | None = None,
        gamma: GammaClient | None = None,
        clob: ClobClient | None = None,
        source_registry: SourceRegistry | None = None,
    ) -> None:
        if not settings.universe.sports_hard_ban:
            raise ValueError("ResolutionEdge V1 cannot run with the sports hard ban disabled")
        self.settings = settings
        self.database = database or Database(settings.app.database_path)
        self.database.initialize()
        self._owns_http = http is None
        self.http = http or HttpClient(
            timeout_seconds=settings.http.timeout_seconds,
            retries=settings.http.retries,
            backoff_seconds=settings.http.backoff_seconds,
            user_agent=settings.http.user_agent,
        )
        self.gamma = gamma or GammaClient(self.http, settings.polymarket.gamma_base_url)
        self.clob = clob or ClobClient(self.http, settings.polymarket.clob_base_url)
        self.sources = source_registry or SourceRegistry(
            [
                BlsU3Adapter(
                    config=settings.bls,
                    http=self.http,
                    database=self.database,
                    evidence_root=settings.app.evidence_dir,
                )
            ]
        )
        self.stop_requested = False

    def close(self) -> None:
        if self._owns_http:
            self.http.close()

    def request_stop(self, *_: object) -> None:
        self.stop_requested = True

    def run_forever(self, *, mode: str) -> None:
        if mode not in {"capture", "paper"}:
            raise ValueError("V1 supports only capture and paper modes")
        previous_int = signal.getsignal(signal.SIGINT)
        previous_term = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGINT, self.request_stop)
        signal.signal(signal.SIGTERM, self.request_stop)
        try:
            self._write_status(
                state="RUNNING",
                mode=mode,
                stats={},
                message="engine loop started",
            )
            while not self.stop_requested:
                started = time.monotonic()
                try:
                    self.scan_once(mode=mode)
                except Exception:
                    LOGGER.exception("Scan failed")
                elapsed = time.monotonic() - started
                sleep_for = max(0.0, self.settings.app.scan_interval_seconds - elapsed)
                end = time.monotonic() + sleep_for
                while not self.stop_requested and time.monotonic() < end:
                    time.sleep(min(1.0, end - time.monotonic()))
        finally:
            self._write_status(
                state="STOPPED",
                mode=mode,
                stats={},
                message="engine loop stopped",
            )
            signal.signal(signal.SIGINT, previous_int)
            signal.signal(signal.SIGTERM, previous_term)

    def scan_once(self, *, mode: str) -> dict[str, Any]:
        if mode not in {"capture", "paper"}:
            raise ValueError("V1 supports only capture and paper modes")

        run_id = self.database.start_run(mode)
        scan_started = utc_now()
        stats: dict[str, Any] = {
            "run_id": run_id,
            "mode": mode,
            "version": __version__,
            "config_sha256": sha256_bytes(self.settings.config_path.read_bytes()),
            "started_at": iso_utc(scan_started),
            "markets_seen": 0,
            "sports_hard_banned": 0,
            "category_blocked": 0,
            "objective_eligible": 0,
            "within_horizon": 0,
            "rule_supported": 0,
            "rules_changed_halts": 0,
            "book_tokens_requested": 0,
            "baseline_book_tokens_requested": 0,
            "source_book_tokens_requested": 0,
            "books_received": 0,
            "book_errors": 0,
            "source_statuses": {},
            "evaluation_decisions": {},
            "paper_orders_created": 0,
            "paper_orders_settled": 0,
        }
        self._write_status(
            state="SCANNING",
            mode=mode,
            stats=stats,
            message="scan in progress",
            run_id=run_id,
        )

        try:
            stats["paper_orders_settled"] = self._settle_open_orders()
            markets, assessments, baseline_markets, source_markets = self._discover(run_id, stats)

            # Source-confirmed execution gets priority. Establish official-source
            # finality first, then request a fresh winning-token book. Only after
            # that latency-sensitive path is captured do we collect the naive
            # baseline control snapshot.
            source_statuses: Counter[str] = Counter()
            evidence_by_market: dict[str, SourceEvidence | None] = {}
            source_token_ids: list[str] = []
            for market in source_markets:
                assessment = assessments[market.market_id]
                adapter = self.sources.get(assessment.adapter_id)
                if adapter is None:
                    evidence = SourceEvidence(
                        adapter_id=assessment.adapter_id or "unknown",
                        status="UNSUPPORTED",
                        reason="Configured source adapter is unavailable",
                    )
                else:
                    try:
                        evidence = adapter.evaluate(market)
                    except Exception as exc:
                        LOGGER.exception("Source adapter failed closed for market %s", market.market_id)
                        evidence = SourceEvidence(
                            adapter_id=assessment.adapter_id or "unknown",
                            status="PARSE_ERROR",
                            reason=f"Unhandled source-adapter error: {type(exc).__name__}: {exc}",
                        )
                source_statuses[evidence.status] += 1
                self.database.insert_source_evidence(run_id, market.market_id, evidence)
                if evidence.status == "FINAL" and evidence.winning_token_id:
                    source_token_ids.append(evidence.winning_token_id)
                evidence_by_market[market.market_id] = evidence

            source_token_ids = list(dict.fromkeys(source_token_ids))
            stats["source_book_tokens_requested"] = len(source_token_ids)
            source_books, source_book_errors = (
                self.clob.get_order_books(
                    source_token_ids,
                    sequential_fallback_limit=self.settings.discovery.sequential_book_fallback_limit,
                )
                if source_token_ids
                else ({}, {})
            )
            self._store_book_snapshots(
                run_id,
                markets,
                source_books,
                phase="source_post_evidence",
            )

            baseline_token_ids = self._baseline_tokens_to_fetch(baseline_markets)
            stats["baseline_book_tokens_requested"] = len(baseline_token_ids)
            baseline_books, baseline_book_errors = (
                self.clob.get_order_books(
                    baseline_token_ids,
                    sequential_fallback_limit=self.settings.discovery.sequential_book_fallback_limit,
                )
                if baseline_token_ids
                else ({}, {})
            )
            self._store_book_snapshots(
                run_id,
                markets,
                baseline_books,
                phase="baseline_control_snapshot",
            )

            stats["book_tokens_requested"] = len(source_token_ids) + len(baseline_token_ids)
            stats["books_received"] = len(source_books) + len(baseline_books)
            stats["book_errors"] = len(source_book_errors) + len(baseline_book_errors)
            stats["source_statuses"] = dict(source_statuses)

            evaluations: list[Evaluation] = []
            if self.settings.baseline.enabled:
                for market in baseline_markets:
                    evaluations.append(
                        evaluate_hf97_reference(
                            market,
                            baseline_books,
                            self.settings,
                            now=scan_started,
                        )
                    )
                    evaluations.append(
                        evaluate_hf97_executable(
                            market,
                            baseline_books,
                            self.settings,
                            now=scan_started,
                        )
                    )

            for market in source_markets:
                assessment = assessments[market.market_id]
                evaluations.append(
                    evaluate_source_confirmed(
                        market,
                        source_books,
                        assessment,
                        evidence_by_market.get(market.market_id),
                        self.settings,
                        now=utc_now(),
                    )
                )

            if mode == "paper":
                stats["paper_orders_created"] = self._apply_paper_order_gates(run_id, evaluations)

            decisions: Counter[str] = Counter()
            for evaluation in evaluations:
                self.database.insert_evaluation(run_id, evaluation)
                decisions[f"{evaluation.strategy}:{evaluation.decision}"] += 1
            stats["evaluation_decisions"] = dict(decisions)
            stats["finished_at"] = iso_utc()
            stats["duration_seconds"] = round((utc_now() - scan_started).total_seconds(), 3)
            self.database.finish_run(run_id, status="COMPLETED", stats=stats)
            self.database.set_meta("last_successful_scan", stats)
            self._write_status(
                state="IDLE" if not self.stop_requested else "STOPPING",
                mode=mode,
                stats=stats,
                message="scan completed",
                run_id=run_id,
            )
            LOGGER.info("Completed scan %s: %s", run_id, canonical_json(stats))
            return stats
        except Exception as exc:
            stats["finished_at"] = iso_utc()
            stats["error"] = f"{type(exc).__name__}: {exc}"
            self.database.finish_run(run_id, status="FAILED", stats=stats, error=stats["error"])
            self._write_status(
                state="ERROR",
                mode=mode,
                stats=stats,
                message=stats["error"],
                run_id=run_id,
            )
            raise

    def _discover(
        self,
        run_id: int,
        stats: dict[str, Any],
    ) -> tuple[
        dict[str, MarketData],
        dict[str, RuleAssessment],
        list[MarketData],
        list[MarketData],
    ]:
        now = utc_now()
        markets: dict[str, MarketData] = {}
        assessments: dict[str, RuleAssessment] = {}
        baseline_markets: list[MarketData] = []
        source_markets: list[MarketData] = []

        earliest_end = now - timedelta(hours=self.settings.discovery.post_end_grace_hours)
        latest_end = now + timedelta(hours=self.settings.discovery.horizon_hours)
        iterator = self.gamma.list_active_markets(
            page_size=self.settings.discovery.page_size,
            max_pages=self.settings.discovery.max_pages,
            end_date_min=iso_utc(earliest_end),
            end_date_max=iso_utc(latest_end),
        )
        discovered: list[MarketData] = []
        initial_universe: dict[str, Any] = {}
        hard_banned_events = self.database.hard_banned_event_ids()
        for index, market in enumerate(iterator):
            if index >= self.settings.discovery.max_markets_per_scan:
                break
            discovered.append(market)
            decision = classify_universe(market, self.settings.universe)
            initial_universe[market.market_id] = decision
            if decision.hard_banned:
                hard_banned_events.add(market.event_id)
        stats["markets_seen"] = len(discovered)

        for market in discovered:
            universe = initial_universe[market.market_id]
            if market.event_id in hard_banned_events and not universe.hard_banned:
                universe = universe.model_copy(
                    update={
                        "hard_banned": True,
                        "eligible": False,
                        "reason": "SPORTS_HARD_BAN: sibling or previously banned event",
                    }
                )

            # Fingerprint and audit the contract before any rule/source/signal logic.
            # Sports and blocked categories stop here.
            rules_hash = market_semantic_hash(market)
            rules_changed = self.database.record_rule_version(market, rules_hash=rules_hash)
            markets[market.market_id] = market

            if universe.hard_banned:
                self.database.upsert_market(
                    run_id, market, universe, rules_hash=rules_hash
                )
                stats["sports_hard_banned"] += 1
                continue
            if not universe.eligible:
                self.database.upsert_market(
                    run_id, market, universe, rules_hash=rules_hash
                )
                stats["category_blocked"] += 1
                continue

            assessment = assess_rules(market)
            if assessment.rules_hash != rules_hash:
                raise RuntimeError("Internal semantic fingerprint mismatch")
            if rules_changed:
                stats["rules_changed_halts"] += 1
                universe = universe.model_copy(
                    update={
                        "eligible": False,
                        "reason": (
                            "RULES_CHANGED_HALT: decision-critical market metadata "
                            "changed after first observation"
                        ),
                    }
                )
                assessment = assessment.model_copy(
                    update={
                        "deterministic": False,
                        "supported": False,
                        "adapter_id": None,
                        "reasons": [
                            *assessment.reasons,
                            "decision-critical market metadata changed since first observation",
                        ],
                    }
                )

            self.database.upsert_market(
                run_id,
                market,
                universe,
                rules_hash=rules_hash,
            )
            if not universe.eligible:
                continue
            stats["objective_eligible"] += 1

            hours = hours_to_end(market, now=now)
            if hours is None:
                continue
            if hours > Decimal(str(self.settings.discovery.horizon_hours)):
                continue
            if hours < -Decimal(str(self.settings.discovery.post_end_grace_hours)):
                continue
            stats["within_horizon"] += 1
            assessments[market.market_id] = assessment
            self.database.insert_rule_assessment(run_id, market.market_id, assessment)

            if self._is_baseline_prefilter_candidate(market, hours):
                baseline_markets.append(market)
            if (
                assessment.supported
                and assessment.adapter_id in self.settings.source_confirmed.supported_adapters
            ):
                stats["rule_supported"] += 1
                source_markets.append(market)

        return markets, assessments, baseline_markets, source_markets

    def _is_baseline_prefilter_candidate(self, market: MarketData, hours: Decimal) -> bool:
        cfg = self.settings.baseline
        if not cfg.enabled:
            return False
        if hours > Decimal(str(cfg.max_hours_to_end)):
            return False
        if hours < -Decimal(str(cfg.post_end_grace_hours)):
            return False
        if market.lifetime_volume < Decimal(str(cfg.min_lifetime_volume_usdc)):
            return False
        favorite = favorite_by_reference(market)
        if favorite is None or favorite.reference_price is None:
            return False
        return favorite.reference_price >= Decimal(str(cfg.min_favorite_price))

    @staticmethod
    def _baseline_tokens_to_fetch(markets: Iterable[MarketData]) -> list[str]:
        """Fetch only the Gamma-selected favorite needed by the control strategies."""
        result: list[str] = []
        for market in markets:
            favorite = favorite_by_reference(market)
            if favorite is not None and favorite.token_id:
                result.append(favorite.token_id)
        return list(dict.fromkeys(result))

    def _store_book_snapshots(
        self,
        run_id: int,
        markets: dict[str, MarketData],
        books: dict[str, OrderBook],
        *,
        phase: str,
    ) -> None:
        market_by_token = {
            outcome.token_id: market
            for market in markets.values()
            for outcome in market.outcomes
            if outcome.token_id
        }
        for token_id, raw_book in books.items():
            market = market_by_token.get(token_id)
            if market is None:
                continue
            self.database.insert_book_snapshot(
                run_id,
                market,
                raw_book,
                phase=phase,
                top_levels=self.settings.discovery.top_book_levels_to_store,
            )

    def _apply_paper_order_gates(self, run_id: int, evaluations: list[Evaluation]) -> int:
        grouped: dict[str, list[Evaluation]] = defaultdict(list)
        for evaluation in evaluations:
            if evaluation.decision == "ORDER":
                grouped[evaluation.strategy].append(evaluation)

        created = 0
        for strategy, candidates in grouped.items():
            if strategy == self.settings.source_confirmed.strategy_name:
                candidates.sort(
                    key=lambda item: item.net_edge_per_share or Decimal("-999"), reverse=True
                )
                cap = self.settings.source_confirmed.maximum_orders_per_scan
            else:
                candidates.sort(
                    key=lambda item: (
                        -(item.reference_price or Decimal("0")),
                        item.hours_to_end if item.hours_to_end is not None else Decimal("999999"),
                    )
                )
                cap = self.settings.baseline.max_orders_per_scan_per_strategy

            selected = 0
            events_selected_this_scan: set[str] = set()
            for evaluation in candidates:
                if selected >= cap:
                    evaluation.decision = "OBSERVE"
                    evaluation.reason = f"Paper order cap reached for {strategy} in this scan"
                    continue
                if not evaluation.token_id or evaluation.fill is None:
                    evaluation.decision = "REJECT"
                    evaluation.reason = "Internal gate rejected incomplete ORDER evaluation"
                    continue
                if self.database.paper_order_exists(
                    strategy=strategy,
                    market_id=evaluation.market_id,
                    token_id=evaluation.token_id,
                    evidence_key=evaluation.evidence_key,
                ):
                    evaluation.decision = "OBSERVE"
                    evaluation.reason = "This strategy already paper-traded the same evidence/market"
                    continue
                if (
                    strategy != self.settings.source_confirmed.strategy_name
                    and self.database.has_strategy_market_order(
                        strategy=strategy,
                        market_id=evaluation.market_id,
                    )
                ):
                    evaluation.decision = "OBSERVE"
                    evaluation.reason = "This control strategy already paper-traded this market"
                    continue
                if (
                    strategy == self.settings.source_confirmed.strategy_name
                    and self.settings.source_confirmed.one_order_per_event
                ):
                    if evaluation.event_id in events_selected_this_scan or self.database.has_open_or_settled_event_order(
                        strategy=strategy,
                        event_id=evaluation.event_id,
                    ):
                        evaluation.decision = "OBSERVE"
                        evaluation.reason = "One-order-per-event risk cap blocked a correlated ladder trade"
                        continue

                available = self.database.strategy_available_equity(
                    strategy,
                    Decimal(str(self.settings.paper.starting_equity_usdc)),
                )
                if evaluation.fill.all_in_cost > available:
                    evaluation.decision = "REJECT"
                    evaluation.reason = (
                        f"Shadow ledger has insufficient available equity: {available} USDC"
                    )
                    continue

                order_id = self.database.insert_paper_order(run_id, evaluation)
                if order_id is None:
                    evaluation.decision = "OBSERVE"
                    evaluation.reason = "Duplicate paper order suppressed by database constraint"
                    continue
                evaluation.metadata["paper_order_id"] = order_id
                evaluation.metadata["paper_only"] = True
                selected += 1
                created += 1
                events_selected_this_scan.add(evaluation.event_id)
        return created

    def _settle_open_orders(self) -> int:
        orders = self.database.list_open_orders()
        if not orders:
            return 0
        market_cache: dict[str, MarketData] = {}
        settled = 0
        for order in orders:
            market_id = str(order["market_id"])
            try:
                market = market_cache.get(market_id)
                if market is None:
                    market = self.gamma.get_market(market_id)
                    market_cache[market_id] = market
                payout = infer_gamma_payout(market, str(order["token_id"]))
                if payout is None:
                    continue
                self.database.settle_order(
                    int(order["id"]),
                    payout_per_share=payout,
                    settlement_raw=market.raw,
                )
                settled += 1
            except Exception as exc:
                LOGGER.warning("Could not settle paper order %s: %s", order.get("id"), exc)
        return settled

    def _write_status(
        self,
        *,
        state: str,
        mode: str,
        stats: dict[str, Any],
        message: str,
        run_id: int | None = None,
    ) -> None:
        payload = {
            "application": self.settings.app.name,
            "version": __version__,
            "pid": os.getpid(),
            "state": state,
            "mode": mode,
            "paper_only": True,
            "sports_hard_ban": self.settings.universe.sports_hard_ban,
            "run_id": run_id,
            "updated_at": iso_utc(),
            "message": message,
            "stats": stats,
        }
        atomic_write_text(self.settings.app.status_path, canonical_json(payload) + "\n")


def infer_gamma_payout(market: MarketData, token_id: str) -> Decimal | None:
    """Return a safe settlement payout only when Gamma exposes an unambiguous result."""
    if not market.closed:
        return None
    outcome = market.outcome_by_token(token_id)
    if outcome is None:
        return None

    price = outcome.reference_price
    if price is not None:
        if price >= Decimal("0.999999"):
            return Decimal("1")
        if price <= Decimal("0.000001"):
            return Decimal("0")
        if abs(price - Decimal("0.5")) <= Decimal("0.000001"):
            all_prices = [item.reference_price for item in market.outcomes]
            if all(value is not None and abs(value - Decimal("0.5")) <= Decimal("0.000001") for value in all_prices):
                return Decimal("0.5")

    raw = market.raw
    winning_token = raw.get("winningTokenId") or raw.get("winning_token_id")
    if winning_token:
        return Decimal("1") if str(winning_token) == token_id else Decimal("0")
    winning_outcome = raw.get("winningOutcome") or raw.get("winner")
    if isinstance(winning_outcome, str):
        return Decimal("1") if winning_outcome.casefold() == outcome.label.casefold() else Decimal("0")
    return None
