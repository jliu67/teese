from __future__ import annotations

import logging
from typing import Any

from resolutionedge.clients.http import HttpClient, HttpRequestError
from resolutionedge.models import BookLevel, OrderBook
from resolutionedge.utils import batched, decimal_or_none, parse_datetime

LOGGER = logging.getLogger(__name__)


class ClobClient:
    def __init__(self, http: HttpClient, base_url: str) -> None:
        self.http = http
        self.base_url = base_url.rstrip("/")

    def get_order_book(self, token_id: str) -> OrderBook:
        payload = self.http.get_json(
            f"{self.base_url}/book",
            params={"token_id": token_id},
        )
        if not isinstance(payload, dict):
            raise RuntimeError("CLOB /book response was not an object")
        return parse_order_book(payload, token_id=token_id)

    def get_order_books(
        self,
        token_ids: list[str],
        *,
        sequential_fallback_limit: int = 50,
    ) -> tuple[dict[str, OrderBook], dict[str, str]]:
        books: dict[str, OrderBook] = {}
        errors: dict[str, str] = {}
        for chunk in batched(dict.fromkeys(token_ids), 500):
            try:
                payload = self.http.post_json(
                    f"{self.base_url}/books",
                    [{"token_id": token_id} for token_id in chunk],
                )
                if not isinstance(payload, list):
                    raise RuntimeError("CLOB /books response was not a list")
                for item in payload:
                    if not isinstance(item, dict):
                        continue
                    token_id = str(item.get("asset_id") or item.get("token_id") or "")
                    if not token_id:
                        continue
                    try:
                        books[token_id] = parse_order_book(item, token_id=token_id)
                    except Exception as exc:  # A malformed single book must not kill the scan.
                        errors[token_id] = str(exc)
            except (HttpRequestError, RuntimeError) as exc:
                LOGGER.warning("Batch book request failed: %s", exc)
                if len(chunk) > sequential_fallback_limit:
                    for token_id in chunk:
                        errors[token_id] = f"batch_failed_without_fallback: {exc}"
                    continue
                for token_id in chunk:
                    try:
                        books[token_id] = self.get_order_book(token_id)
                    except Exception as item_exc:
                        errors[token_id] = str(item_exc)
        for token_id in token_ids:
            if token_id not in books and token_id not in errors:
                errors[token_id] = "book_missing_from_response"
        return books, errors

    def get_fee_rate_bps(self, token_id: str) -> int | None:
        try:
            payload = self.http.get_json(
                f"{self.base_url}/fee-rate",
                params={"token_id": token_id},
            )
        except HttpRequestError:
            return None
        if not isinstance(payload, dict):
            return None
        value = payload.get("base_fee")
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def get_server_time(self) -> Any:
        return self.http.get_json(f"{self.base_url}/time")


def _levels(value: Any) -> list[BookLevel]:
    result: list[BookLevel] = []
    if not isinstance(value, list):
        return result
    for raw in value:
        if not isinstance(raw, dict):
            continue
        price = decimal_or_none(raw.get("price"))
        size = decimal_or_none(raw.get("size"))
        if price is None or size is None or price <= 0 or size <= 0:
            continue
        result.append(BookLevel(price=price, size=size))
    return result


def parse_order_book(raw: dict[str, Any], *, token_id: str | None = None) -> OrderBook:
    resolved_token = str(token_id or raw.get("asset_id") or raw.get("token_id") or "")
    if not resolved_token:
        raise ValueError("Order book has no token id")
    bids = sorted(_levels(raw.get("bids")), key=lambda level: level.price, reverse=True)
    asks = sorted(_levels(raw.get("asks")), key=lambda level: level.price)
    tick_size = decimal_or_none(raw.get("tick_size")) or decimal_or_none(raw.get("tickSize"))
    return OrderBook(
        token_id=resolved_token,
        condition_id=str(raw.get("market") or raw.get("condition_id") or "") or None,
        timestamp=parse_datetime(raw.get("timestamp")),
        bids=bids,
        asks=asks,
        min_order_size=decimal_or_none(raw.get("min_order_size") or raw.get("minOrderSize")),
        tick_size=tick_size or decimal_or_none("0.01"),
        neg_risk=bool(raw.get("neg_risk", raw.get("negRisk", False))),
        last_trade_price=decimal_or_none(raw.get("last_trade_price") or raw.get("lastTradePrice")),
        book_hash=str(raw.get("hash") or ""),
        raw=raw,
    )
