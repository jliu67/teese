from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Iterable

from resolutionedge.clients.http import HttpClient
from resolutionedge.models import MarketData, MarketOutcome
from resolutionedge.utils import (
    decimal_or_none,
    json_array,
    parse_datetime,
)

LOGGER = logging.getLogger(__name__)


class GammaClient:
    def __init__(self, http: HttpClient, base_url: str) -> None:
        self.http = http
        self.base_url = base_url.rstrip("/")

    def list_active_markets(
        self,
        *,
        page_size: int,
        max_pages: int,
        end_date_min: str | None = None,
        end_date_max: str | None = None,
    ) -> Iterable[MarketData]:
        seen: set[str] = set()
        for page in range(max_pages):
            offset = page * page_size
            params: dict[str, Any] = {
                "active": "true",
                "closed": "false",
                "limit": page_size,
                "offset": offset,
                "order": "endDate",
                "ascending": "true",
            }
            if end_date_min:
                params["end_date_min"] = end_date_min
            if end_date_max:
                params["end_date_max"] = end_date_max
            payload = self.http.get_json(
                f"{self.base_url}/markets",
                params=params,
            )
            if not isinstance(payload, list):
                raise RuntimeError("Gamma /markets response was not a JSON list")
            if not payload:
                return
            for raw in payload:
                if not isinstance(raw, dict):
                    continue
                try:
                    market = parse_gamma_market(raw)
                except Exception as exc:
                    LOGGER.warning("Skipping malformed Gamma market: %s", exc)
                    continue
                if market.market_id in seen:
                    continue
                seen.add(market.market_id)
                yield market
            if len(payload) < page_size:
                return

    def get_market(self, market_id: str) -> MarketData:
        payload = self.http.get_json(f"{self.base_url}/markets/{market_id}")
        if not isinstance(payload, dict):
            raise RuntimeError(f"Gamma market {market_id} response was not an object")
        return parse_gamma_market(payload)


def _first_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, list):
        return next((item for item in value if isinstance(item, dict)), {})
    return {}


def _tag_strings(raw: dict[str, Any], event: dict[str, Any]) -> list[str]:
    tags: list[str] = []
    for owner in (raw, event):
        value = owner.get("tags")
        if not isinstance(value, list):
            continue
        for tag in value:
            if isinstance(tag, dict):
                for field in ("label", "slug", "name"):
                    if tag.get(field):
                        tags.append(str(tag[field]))
            elif tag:
                tags.append(str(tag))
    # Preserve order while deduplicating.
    return list(dict.fromkeys(tags))


def _rules_text(raw: dict[str, Any], event: dict[str, Any]) -> str:
    candidates = (
        raw.get("description"),
        raw.get("rules"),
        raw.get("resolutionCriteria"),
        event.get("description"),
        event.get("rules"),
        event.get("resolutionCriteria"),
    )
    return next((str(value) for value in candidates if value), "")


def _resolution_source(raw: dict[str, Any], event: dict[str, Any]) -> str:
    candidates = (
        raw.get("resolutionSource"),
        raw.get("resolution_source"),
        event.get("resolutionSource"),
        event.get("resolution_source"),
    )
    return next((str(value) for value in candidates if value), "")


def _extract_fee_schedule(raw: dict[str, Any]) -> tuple[bool | None, Decimal | None, Decimal | None, bool | None]:
    enabled = raw.get("feesEnabled")
    schedule = raw.get("feeSchedule")
    if not isinstance(schedule, dict):
        schedule = {}
    rate = decimal_or_none(schedule.get("rate"))
    exponent = decimal_or_none(schedule.get("exponent"))
    taker_only = schedule.get("takerOnly")
    return (
        bool(enabled) if enabled is not None else None,
        rate,
        exponent,
        bool(taker_only) if taker_only is not None else None,
    )


def parse_gamma_market(raw: dict[str, Any]) -> MarketData:
    market_id = str(raw.get("id") or raw.get("marketId") or "")
    if not market_id:
        raise ValueError("Gamma market has no id")

    event = _first_dict(raw.get("events"))
    event_id = str(
        event.get("id")
        or raw.get("eventId")
        or raw.get("event_id")
        or raw.get("conditionId")
        or market_id
    )
    labels = json_array(raw.get("outcomes"))
    token_ids = json_array(raw.get("clobTokenIds"))
    prices = json_array(raw.get("outcomePrices"))
    outcomes: list[MarketOutcome] = []
    for index, token in enumerate(token_ids):
        if not token:
            continue
        # Never synthesize Yes/No from array position. Source-confirmed logic may
        # map official evidence only to an outcome explicitly labelled by Gamma.
        label = str(labels[index]).strip() if index < len(labels) and labels[index] else ""
        price = decimal_or_none(prices[index]) if index < len(prices) else None
        outcomes.append(
            MarketOutcome(index=index, label=label, token_id=str(token), reference_price=price)
        )

    fees_enabled, fee_rate, fee_exponent, fee_taker_only = _extract_fee_schedule(raw)
    category = str(raw.get("category") or event.get("category") or "")
    volume = decimal_or_none(
        raw.get("volumeNum")
        or raw.get("volume")
        or raw.get("volumeClob")
        or event.get("volumeNum")
        or event.get("volume")
    ) or Decimal("0")
    liquidity = decimal_or_none(
        raw.get("liquidityNum")
        or raw.get("liquidity")
        or raw.get("liquidityClob")
        or event.get("liquidityNum")
    ) or Decimal("0")

    return MarketData(
        market_id=market_id,
        condition_id=str(raw.get("conditionId") or "") or None,
        event_id=event_id,
        event_title=str(event.get("title") or raw.get("eventTitle") or ""),
        slug=str(raw.get("slug") or ""),
        question=str(raw.get("question") or ""),
        group_item_title=str(raw.get("groupItemTitle") or raw.get("group_item_title") or ""),
        rules=_rules_text(raw, event),
        resolution_source=_resolution_source(raw, event),
        category=category,
        tags=_tag_strings(raw, event),
        outcomes=outcomes,
        start_date=parse_datetime(raw.get("startDateIso") or raw.get("startDate")),
        end_date=parse_datetime(raw.get("endDateIso") or raw.get("endDate")),
        closed_time=parse_datetime(raw.get("closedTime")),
        active=bool(raw.get("active", False)),
        closed=bool(raw.get("closed", False)),
        archived=bool(raw.get("archived", False)),
        accepting_orders=bool(raw.get("acceptingOrders", False)),
        enable_order_book=bool(raw.get("enableOrderBook", True)),
        restricted=bool(raw.get("restricted", False)),
        neg_risk=bool(raw.get("negRisk", False)),
        game_start_time=parse_datetime(
            raw.get("gameStartTime") or event.get("gameStartTime")
        ),
        game_id=str(raw.get("gameId") or raw.get("game_id") or event.get("gameId") or event.get("game_id") or ""),
        sports_market_type=str(
            raw.get("sportsMarketType") or event.get("sportsMarketType") or ""
        ),
        lifetime_volume=volume,
        liquidity=liquidity,
        min_tick_size=decimal_or_none(raw.get("orderPriceMinTickSize")),
        min_order_size=decimal_or_none(raw.get("orderMinSize")),
        fees_enabled=fees_enabled,
        fee_rate=fee_rate,
        fee_exponent=fee_exponent,
        fee_taker_only=fee_taker_only,
        raw=raw,
    )
