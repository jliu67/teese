from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx


class HttpRequestError(RuntimeError):
    pass


@dataclass(frozen=True)
class HttpResponseText:
    text: str
    headers: dict[str, str]
    status_code: int


class HttpClient:
    def __init__(
        self,
        *,
        timeout_seconds: float,
        retries: int,
        backoff_seconds: float,
        user_agent: str,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.retries = retries
        self.backoff_seconds = backoff_seconds
        self.client = httpx.Client(
            timeout=httpx.Timeout(timeout_seconds),
            headers={
                "User-Agent": user_agent,
                "Accept": "application/json, text/html;q=0.9, */*;q=0.8",
            },
            follow_redirects=True,
            transport=transport,
        )

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        last_error: Exception | None = None
        attempts = self.retries + 1
        for attempt in range(attempts):
            try:
                response = self.client.request(method, url, **kwargs)
                if response.status_code == 429 or response.status_code >= 500:
                    raise HttpRequestError(
                        f"{method} {url} returned retryable HTTP {response.status_code}"
                    )
                response.raise_for_status()
                return response
            except (httpx.HTTPError, HttpRequestError) as exc:
                last_error = exc
                if attempt >= attempts - 1:
                    break
                retry_after = 0.0
                if isinstance(exc, httpx.HTTPStatusError):
                    header = exc.response.headers.get("Retry-After")
                    try:
                        retry_after = float(header) if header else 0.0
                    except ValueError:
                        retry_after = 0.0
                sleep_for = max(retry_after, self.backoff_seconds * (2**attempt))
                if sleep_for:
                    time.sleep(sleep_for)
        raise HttpRequestError(f"{method} {url} failed after {attempts} attempt(s): {last_error}")

    def get_json(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        response = self._request("GET", url, params=params)
        try:
            return response.json()
        except ValueError as exc:
            raise HttpRequestError(f"GET {url} returned invalid JSON") from exc

    def post_json(self, url: str, payload: Any) -> Any:
        response = self._request("POST", url, json=payload)
        try:
            return response.json()
        except ValueError as exc:
            raise HttpRequestError(f"POST {url} returned invalid JSON") from exc

    def get_text(self, url: str, *, params: dict[str, Any] | None = None) -> HttpResponseText:
        response = self._request("GET", url, params=params)
        return HttpResponseText(
            text=response.text,
            headers={key.lower(): value for key, value in response.headers.items()},
            status_code=response.status_code,
        )
