from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Iterable

from resolutionedge.config import Settings
from resolutionedge.models import (
    Evaluation,
    FillPlan,
    MarketData,
    MarketOutcome,
    OrderBook,
    RuleAssessment,
    SourceEvidence,
)
from resolutionedge.strategy.fees import fee_rate_for_market
from resolutionedge.strategy.orderbook import simulate_taker_buy, synthetic_reference_fill
from resolutionedge.utils import canonical_json, sha256_text, utc_now

ZERO = Decimal("0")


def hours_to_end(market: MarketData, *, now: datetime | None = None) -> Decimal | None:
    if market.end_date is None:
        return None
    current = now or utc_now()
    seconds = Decimal(str((market.end_date - current).total_seconds()))
    return seconds / Decimal("3600")


def favorite_by_reference(market: MarketData) -> MarketOutcome | None:
    candidates = [outcome for outcome in market.outcomes if outcome.reference_price is not None]
    if not candidates:
        return None
    return max(candidates, key=lambda outcome: outcome.reference_price or ZERO)


def _base_evaluation(
    *,
    strategy: str,
    market: MarketData,
    outcome: MarketOutcome | None,
    book: OrderBook | None,
    decision: str,
    reason: str,
    hours: Decimal | None,
    evidence_key: str,
    source_status: str | None = None,
    expected_payout: Decimal | None = None,
    fill: FillPlan | None = None,
    reference_price: Decimal | None = None,
    metadata: dict | None = None,
) -> Evaluation:
    net_edge = None
    if fill and fill.all_in_cost_per_share is not None and expected_payout is not None:
        net_edge = expected_payout - fill.all_in_cost_per_share
    return Evaluation(
        strategy=strategy,
        market_id=market.market_id,
        event_id=market.event_id,
        token_id=outcome.token_id if outcome else None,
        outcome_label=outcome.label if outcome else None,
        decision=decision,  # type: ignore[arg-type]
        reason=reason,
        reference_price=reference_price,
        best_bid=book.best_bid if book else None,
        best_ask=book.best_ask if book else None,
        midpoint=book.midpoint if book else None,
        spread=book.spread if book else None,
        hours_to_end=hours,
        expected_payout=expected_payout,
        net_edge_per_share=net_edge,
        fill=fill,
        evidence_key=evidence_key,
        source_status=source_status,
        metadata=metadata or {},
    )


def evaluate_hf97_reference(
    market: MarketData,
    books: dict[str, OrderBook],
    settings: Settings,
    *,
    now: datetime | None = None,
) -> Evaluation:
    cfg = settings.baseline
    strategy = cfg.reference_strategy_name
    hours = hours_to_end(market, now=now)
    outcome = favorite_by_reference(market)
    evidence_key = f"baseline:{sha256_text(market.rules or market.market_id)[:16]}"

    reject = _baseline_reject_reason(market, outcome, hours, settings)
    if reject:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=books.get(outcome.token_id) if outcome else None,
            decision="REJECT",
            reason=reject,
            hours=hours,
            evidence_key=evidence_key,
            reference_price=outcome.reference_price if outcome else None,
            metadata={"control": "non_executable_gamma_reference"},
        )

    assert outcome is not None and outcome.reference_price is not None
    fee_rate, fee_source = fee_rate_for_market(market, settings.fees)
    fill = synthetic_reference_fill(
        requested_notional=Decimal(str(cfg.stake_usdc)),
        reference_price=outcome.reference_price,
        fee_rate=fee_rate,
        maximum_price=Decimal(str(cfg.max_entry_price)),
    )
    if fill.shares <= 0:
        decision, reason = "REJECT", f"reference fill unavailable: {fill.reason}"
    else:
        decision = "ORDER"
        reason = (
            "Reference-price control only: assumes Gamma snapshot is executable; "
            "this is intentionally optimistic and does not claim positive EV"
        )
    return _base_evaluation(
        strategy=strategy,
        market=market,
        outcome=outcome,
        book=books.get(outcome.token_id),
        decision=decision,
        reason=reason,
        hours=hours,
        evidence_key=evidence_key,
        expected_payout=outcome.reference_price,
        fill=fill if fill.shares > 0 else None,
        reference_price=outcome.reference_price,
        metadata={
            "control": "non_executable_gamma_reference",
            "fee_rate": str(fee_rate),
            "fee_source": fee_source,
        },
    )


def evaluate_hf97_executable(
    market: MarketData,
    books: dict[str, OrderBook],
    settings: Settings,
    *,
    now: datetime | None = None,
) -> Evaluation:
    cfg = settings.baseline
    strategy = cfg.executable_strategy_name
    hours = hours_to_end(market, now=now)
    outcome = favorite_by_reference(market)
    evidence_key = f"baseline:{sha256_text(market.rules or market.market_id)[:16]}"
    book = books.get(outcome.token_id) if outcome else None

    reject = _baseline_reject_reason(market, outcome, hours, settings)
    if reject:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason=reject,
            hours=hours,
            evidence_key=evidence_key,
            reference_price=outcome.reference_price if outcome else None,
            metadata={"control": "same_signal_realistic_clob_execution"},
        )
    if book is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=None,
            decision="REJECT",
            reason="No live CLOB book for the Gamma-selected favorite",
            hours=hours,
            evidence_key=evidence_key,
            reference_price=outcome.reference_price if outcome else None,
        )

    assert outcome is not None and outcome.reference_price is not None
    fee_rate, fee_source = fee_rate_for_market(market, settings.fees)
    fill = simulate_taker_buy(
        book,
        requested_notional=Decimal(str(cfg.stake_usdc)),
        fee_rate=fee_rate,
        maximum_price=Decimal(str(cfg.max_entry_price)),
        latency_slippage_ticks=settings.paper.latency_slippage_ticks,
        visible_depth_haircut=Decimal(str(settings.paper.visible_depth_haircut)),
        allow_partial_fills=settings.paper.allow_partial_fills,
    )
    min_fill = Decimal(str(settings.paper.minimum_fill_usdc))
    minimum_order_reason = _minimum_order_reason(market, book, fill)
    if fill.all_in_cost < min_fill or minimum_order_reason:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason=minimum_order_reason or f"Realistic fill below minimum: {fill.reason}",
            hours=hours,
            evidence_key=evidence_key,
            reference_price=outcome.reference_price,
            fill=fill if fill.shares > 0 else None,
            expected_payout=outcome.reference_price,
            metadata={"fee_rate": str(fee_rate), "fee_source": fee_source},
        )
    return _base_evaluation(
        strategy=strategy,
        market=market,
        outcome=outcome,
        book=book,
        decision="ORDER",
        reason=(
            "Naive 97% control signal with executable CLOB depth, pessimistic latency, "
            "depth haircut, and taker fees; no independent edge is assumed"
        ),
        hours=hours,
        evidence_key=evidence_key,
        expected_payout=outcome.reference_price,
        fill=fill,
        reference_price=outcome.reference_price,
        metadata={
            "control": "same_signal_realistic_clob_execution",
            "fee_rate": str(fee_rate),
            "fee_source": fee_source,
        },
    )


def _minimum_order_reason(
    market: MarketData,
    book: OrderBook,
    fill: FillPlan,
) -> str | None:
    minimum = book.min_order_size or market.min_order_size
    if minimum is not None and fill.shares < minimum:
        return f"Filled shares {fill.shares} are below market minimum {minimum}"
    return None


def _baseline_reject_reason(
    market: MarketData,
    outcome: MarketOutcome | None,
    hours: Decimal | None,
    settings: Settings,
) -> str | None:
    cfg = settings.baseline
    if not cfg.enabled:
        return "Baseline strategies disabled"
    if not market.accepting_orders or market.closed or not market.enable_order_book:
        return "Market is not currently orderable"
    if len(market.outcomes) < 2:
        return "Market does not expose at least two CLOB outcomes"
    if outcome is None or outcome.reference_price is None:
        return "Gamma outcomePrices unavailable"
    if outcome.reference_price < Decimal(str(cfg.min_favorite_price)):
        return "Favorite reference price below configured threshold"
    if outcome.reference_price > Decimal(str(cfg.max_entry_price)):
        return "Favorite reference price above hard entry cap"
    if market.lifetime_volume < Decimal(str(cfg.min_lifetime_volume_usdc)):
        return "Lifetime volume below baseline threshold"
    if hours is None:
        return "Market endDate unavailable"
    if hours > Decimal(str(cfg.max_hours_to_end)):
        return "Outside baseline pre-end window"
    if hours < -Decimal(str(cfg.post_end_grace_hours)):
        return "Outside baseline post-end grace window"
    return None


def evaluate_source_confirmed(
    market: MarketData,
    books: dict[str, OrderBook],
    assessment: RuleAssessment,
    evidence: SourceEvidence | None,
    settings: Settings,
    *,
    now: datetime | None = None,
) -> Evaluation:
    cfg = settings.source_confirmed
    strategy = cfg.strategy_name
    current = now or utc_now()
    hours = hours_to_end(market, now=current)
    evidence_key = "none"
    outcome: MarketOutcome | None = None
    book: OrderBook | None = None

    if not cfg.enabled:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="REJECT",
            reason="Source-confirmed strategy disabled",
            hours=hours,
            evidence_key=evidence_key,
        )
    if not assessment.supported or not assessment.deterministic or not assessment.adapter_id:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="REJECT",
            reason="Resolution rules are not supported and deterministic in V1",
            hours=hours,
            evidence_key=evidence_key,
            metadata={"rule_reasons": assessment.reasons},
        )
    if assessment.adapter_id not in cfg.supported_adapters:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="REJECT",
            reason=f"Adapter {assessment.adapter_id} is not enabled for this strategy",
            hours=hours,
            evidence_key=evidence_key,
        )
    if evidence is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="OBSERVE",
            reason="Supported rules, but no source evidence was produced",
            hours=hours,
            evidence_key=evidence_key,
        )

    evidence_key = sha256_text(
        canonical_json(
            {
                "adapter": evidence.adapter_id,
                "period": evidence.period,
                "checksum": evidence.source_checksum,
                "token": evidence.winning_token_id,
                "rules": assessment.rules_hash,
            }
        )
    )
    if evidence.status != "FINAL":
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="OBSERVE" if evidence.status == "PENDING" else "REJECT",
            reason=evidence.reason or f"Source status is {evidence.status}",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            metadata={"adapter_id": evidence.adapter_id, "period": evidence.period},
        )
    if not evidence.winning_token_id:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="REJECT",
            reason="Final evidence did not map to a winning CLOB token",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )

    outcome = market.outcome_by_token(evidence.winning_token_id)
    book = books.get(evidence.winning_token_id)
    if outcome is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=None,
            book=None,
            decision="REJECT",
            reason="Winning token is absent from current market metadata",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if not market.accepting_orders or market.closed or not market.enable_order_book:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source is final, but the market is not currently orderable",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if book is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=None,
            decision="REJECT",
            reason="Source is final, but no live book exists for the winning token",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if not market.condition_id or not book.condition_id:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book lacks a verifiable condition ID",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if book.condition_id != market.condition_id:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book condition ID does not match market metadata",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            metadata={
                "market_condition_id": market.condition_id,
                "book_condition_id": book.condition_id,
            },
        )

    freshness_anchor = evidence.first_seen_at or evidence.release_at
    if freshness_anchor is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Final source evidence has no verifiable first-seen/release timestamp",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    evidence_age_seconds = Decimal(str((current - freshness_anchor).total_seconds()))
    # The source may be fetched milliseconds after the scan timestamp was captured.
    # Fail closed only for material clock skew; clamp ordinary intra-scan skew to zero.
    if evidence_age_seconds < Decimal("-60"):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Evidence timestamp is materially in the future",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    evidence_age_hours = max(Decimal("0"), evidence_age_seconds) / Decimal("3600")
    if evidence_age_hours > Decimal(str(cfg.evidence_fresh_hours)):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source evidence is older than the configured freshness limit",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            metadata={"evidence_age_hours": str(evidence_age_hours)},
        )

    if book.timestamp is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book has no exchange generation timestamp",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    book_age_seconds = Decimal(str((current - book.timestamp).total_seconds()))
    if book_age_seconds < Decimal("-60"):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book timestamp is materially in the future",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if max(Decimal("0"), book_age_seconds) > Decimal(str(cfg.maximum_book_age_seconds)):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book is older than the configured freshness limit",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            metadata={"book_age_seconds": str(book_age_seconds)},
        )
    timestamp_tolerance = Decimal(str(cfg.post_evidence_timestamp_tolerance_seconds))
    seconds_after_evidence = Decimal(str((book.timestamp - freshness_anchor).total_seconds()))
    if seconds_after_evidence < -timestamp_tolerance:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Source-confirmed book snapshot predates the official evidence",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            metadata={
                "seconds_after_evidence": str(seconds_after_evidence),
                "allowed_tolerance_seconds": str(timestamp_tolerance),
            },
        )
    if book.spread is None or book.best_ask is None:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Winning token has no two-sided executable book",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if book.spread > Decimal(str(cfg.maximum_spread)):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Spread exceeds source-confirmed maximum",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )
    if book.best_ask > Decimal(str(cfg.maximum_entry_price)):
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason="Best ask exceeds source-confirmed hard entry cap",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
        )

    fee_rate, fee_source = fee_rate_for_market(market, settings.fees)
    expected_payout = Decimal(str(cfg.conservative_payout_per_share))
    fill = simulate_taker_buy(
        book,
        requested_notional=Decimal(str(cfg.stake_usdc)),
        fee_rate=fee_rate,
        maximum_price=Decimal(str(cfg.maximum_entry_price)),
        latency_slippage_ticks=settings.paper.latency_slippage_ticks,
        visible_depth_haircut=Decimal(str(settings.paper.visible_depth_haircut)),
        allow_partial_fills=settings.paper.allow_partial_fills,
    )
    min_fill = Decimal(str(settings.paper.minimum_fill_usdc))
    minimum_order_reason = _minimum_order_reason(market, book, fill)
    if fill.all_in_cost < min_fill or fill.all_in_cost_per_share is None or minimum_order_reason:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason=minimum_order_reason or f"Insufficient executable depth after haircuts: {fill.reason}",
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            expected_payout=expected_payout,
            fill=fill if fill.shares > 0 else None,
            metadata={"fee_rate": str(fee_rate), "fee_source": fee_source},
        )

    edge = expected_payout - fill.all_in_cost_per_share
    minimum_edge = Decimal(str(cfg.minimum_net_edge_per_share))
    if edge < minimum_edge:
        return _base_evaluation(
            strategy=strategy,
            market=market,
            outcome=outcome,
            book=book,
            decision="REJECT",
            reason=(
                f"Conservative net edge {edge} is below required {minimum_edge} "
                "after depth, latency, and fees"
            ),
            hours=hours,
            evidence_key=evidence_key,
            source_status=evidence.status,
            expected_payout=expected_payout,
            fill=fill,
            metadata={
                "fee_rate": str(fee_rate),
                "fee_source": fee_source,
                "evidence_age_hours": str(evidence_age_hours),
                "source_reason": evidence.reason,
                "book_age_seconds": str(max(Decimal("0"), book_age_seconds)),
                "seconds_after_evidence": str(seconds_after_evidence),
            },
        )

    return _base_evaluation(
        strategy=strategy,
        market=market,
        outcome=outcome,
        book=book,
        decision="ORDER",
        reason=(
            "Official deterministic source is final and the winning token remains "
            "under the conservative all-in value hurdle"
        ),
        hours=hours,
        evidence_key=evidence_key,
        source_status=evidence.status,
        expected_payout=expected_payout,
        fill=fill,
        metadata={
            "fee_rate": str(fee_rate),
            "fee_source": fee_source,
            "evidence_age_hours": str(evidence_age_hours),
            "source_reason": evidence.reason,
            "source_checksum": evidence.source_checksum,
            "archive_path": evidence.archive_path,
            "book_age_seconds": str(max(Decimal("0"), book_age_seconds)),
            "seconds_after_evidence": str(seconds_after_evidence),
        },
    )


def rank_order_evaluations(evaluations: Iterable[Evaluation]) -> list[Evaluation]:
    return sorted(
        (evaluation for evaluation in evaluations if evaluation.decision == "ORDER"),
        key=lambda item: (
            item.net_edge_per_share if item.net_edge_per_share is not None else Decimal("-999"),
            -(item.hours_to_end or ZERO),
        ),
        reverse=True,
    )
