from __future__ import annotations

from decimal import Decimal

from resolutionedge.config import FeesSection
from resolutionedge.models import MarketData
from resolutionedge.utils import clamp_decimal, normalize_category

ZERO = Decimal("0")
ONE = Decimal("1")


def normalize_fee_rate(value: Decimal | int | float | str | None) -> Decimal | None:
    """Normalize a fee rate to a decimal fraction.

    Gamma currently exposes decimal rates on many markets, while the CLOB fee-rate
    endpoint may expose basis points. The conservative conversion rules below make
    either representation explicit and bounded.
    """
    if value is None:
        return None
    rate = Decimal(str(value))
    if rate < 0:
        return None
    if rate > 100:
        rate /= Decimal("10000")
    elif rate > 1:
        rate /= Decimal("100")
    return min(rate, ONE)


def fee_rate_for_market(
    market: MarketData,
    config: FeesSection,
    *,
    clob_fee_rate_bps: int | None = None,
) -> tuple[Decimal, str]:
    """Return the taker fee rate and the source used for it."""
    if market.fees_enabled is False:
        return ZERO, "gamma_fees_disabled"

    rate = normalize_fee_rate(market.fee_rate)
    if rate is not None:
        return rate, "gamma_fee_schedule"

    if clob_fee_rate_bps is not None:
        clob_rate = normalize_fee_rate(Decimal(clob_fee_rate_bps) / Decimal("10000"))
        if clob_rate is not None:
            return clob_rate, "clob_fee_rate"

    candidates = [market.category, *market.tags]
    fallbacks = {
        normalize_category(key): Decimal(str(value))
        for key, value in config.fallback_rates.items()
    }
    for candidate in candidates:
        normalized = normalize_category(candidate)
        if normalized in fallbacks:
            return fallbacks[normalized], f"category_fallback:{normalized}"

    return Decimal(str(config.default_fallback_rate)), "default_fallback"


def taker_fee(*, shares: Decimal, price: Decimal, fee_rate: Decimal) -> Decimal:
    """Calculate the current Polymarket taker fee in USDC.

    Official formula: shares × feeRate × p × (1-p). Fees are rounded only by the
    exchange; the research engine deliberately retains full decimal precision.
    """
    if shares <= 0 or fee_rate <= 0:
        return ZERO
    p = clamp_decimal(price)
    return shares * fee_rate * p * (ONE - p)


def fee_per_share(*, price: Decimal, fee_rate: Decimal) -> Decimal:
    return taker_fee(shares=ONE, price=price, fee_rate=fee_rate)
