from __future__ import annotations

from decimal import Decimal

from resolutionedge.models import FillLeg, FillPlan, OrderBook
from resolutionedge.strategy.fees import fee_per_share

ZERO = Decimal("0")


def synthetic_reference_fill(
    *,
    requested_notional: Decimal,
    reference_price: Decimal,
    fee_rate: Decimal,
    maximum_price: Decimal,
) -> FillPlan:
    """Build the deliberately non-executable reference-price control fill."""
    if requested_notional <= 0:
        return FillPlan(requested_notional=requested_notional, reason="invalid_notional")
    if reference_price <= 0 or reference_price > maximum_price:
        return FillPlan(
            requested_notional=requested_notional,
            reason="reference_price_above_limit",
        )
    per_share_fee = fee_per_share(price=reference_price, fee_rate=fee_rate)
    all_in_per_share = reference_price + per_share_fee
    if all_in_per_share <= 0:
        return FillPlan(requested_notional=requested_notional, reason="invalid_all_in_price")
    shares = requested_notional / all_in_per_share
    raw_notional = shares * reference_price
    fee = shares * per_share_fee
    return FillPlan(
        requested_notional=requested_notional,
        shares=shares,
        raw_notional=raw_notional,
        fee=fee,
        all_in_cost=raw_notional + fee,
        raw_vwap=reference_price,
        effective_vwap=reference_price,
        all_in_cost_per_share=all_in_per_share,
        partial=False,
        legs=[
            FillLeg(
                displayed_price=reference_price,
                effective_price=reference_price,
                shares=shares,
                notional=raw_notional,
                fee=fee,
            )
        ],
        reason="synthetic_gamma_reference_control",
    )


def simulate_taker_buy(
    book: OrderBook,
    *,
    requested_notional: Decimal,
    fee_rate: Decimal,
    maximum_price: Decimal,
    latency_slippage_ticks: int,
    visible_depth_haircut: Decimal,
    allow_partial_fills: bool,
) -> FillPlan:
    """Walk the ask ladder with pessimistic depth and price assumptions.

    `requested_notional` is the maximum all-in USDC spend, including fees. A
    latency haircut raises each observed ask by configured ticks. Available size
    is multiplied by the visible-depth haircut. The model never fills above the
    hard limit price.
    """
    plan = FillPlan(requested_notional=requested_notional)
    if requested_notional <= 0:
        plan.reason = "invalid_notional"
        return plan
    if not book.asks:
        plan.reason = "empty_ask_book"
        return plan
    if visible_depth_haircut <= 0 or visible_depth_haircut > 1:
        plan.reason = "invalid_depth_haircut"
        return plan

    remaining = requested_notional
    displayed_cost = ZERO
    execution_cost = ZERO
    total_fee = ZERO
    shares = ZERO
    legs: list[FillLeg] = []

    for level in sorted(book.asks, key=lambda item: item.price):
        effective_price = level.price + book.tick_size * Decimal(latency_slippage_ticks)
        if effective_price > maximum_price:
            break
        available_shares = level.size * visible_depth_haircut
        if available_shares <= 0:
            continue
        per_share_fee = fee_per_share(price=effective_price, fee_rate=fee_rate)
        all_in_per_share = effective_price + per_share_fee
        if all_in_per_share <= 0:
            continue
        fill_shares = min(available_shares, remaining / all_in_per_share)
        if fill_shares <= 0:
            continue

        leg_notional = fill_shares * effective_price
        leg_fee = fill_shares * per_share_fee
        leg_cost = leg_notional + leg_fee
        displayed_cost += fill_shares * level.price
        execution_cost += leg_notional
        total_fee += leg_fee
        shares += fill_shares
        remaining -= leg_cost
        legs.append(
            FillLeg(
                displayed_price=level.price,
                effective_price=effective_price,
                shares=fill_shares,
                notional=leg_notional,
                fee=leg_fee,
            )
        )
        if remaining <= Decimal("0.00000001"):
            remaining = ZERO
            break

    if shares <= 0:
        plan.reason = "no_depth_at_or_below_limit"
        return plan

    all_in_cost = execution_cost + total_fee
    partial = all_in_cost + Decimal("0.000001") < requested_notional
    if partial and not allow_partial_fills:
        return FillPlan(
            requested_notional=requested_notional,
            partial=True,
            reason="partial_fill_disallowed",
        )

    plan.shares = shares
    plan.raw_notional = execution_cost
    plan.fee = total_fee
    plan.all_in_cost = all_in_cost
    plan.raw_vwap = displayed_cost / shares
    plan.effective_vwap = execution_cost / shares
    plan.all_in_cost_per_share = all_in_cost / shares
    plan.partial = partial
    plan.legs = legs
    plan.reason = "partial_fill" if partial else "filled_requested_notional"
    return plan
