"""Strategy and execution-reality helpers for ResolutionEdge."""
