from __future__ import annotations

import re

from resolutionedge.config import UniverseSection
from resolutionedge.models import MarketData, UniverseDecision
from resolutionedge.utils import normalize_category, normalize_label


SPORTS_TERMS = {
    "sports",
    "sport",
    "esports",
    "e sports",
    "nba",
    "wnba",
    "nfl",
    "nhl",
    "mlb",
    "mls",
    "ncaa",
    "ncaab",
    "ncaaf",
    "ufc",
    "mma",
    "boxing",
    "formula 1",
    "f1",
    "nascar",
    "premier league",
    "champions league",
    "europa league",
    "la liga",
    "serie a",
    "bundesliga",
    "ligue 1",
    "world cup",
    "copa america",
    "soccer",
    "football",
    "basketball",
    "baseball",
    "hockey",
    "tennis",
    "golf",
    "cricket",
    "rugby",
    "volleyball",
    "badminton",
    "table tennis",
    "darts",
    "league of legends",
    "valorant",
    "counter strike",
    "counter strike 2",
    "cs2",
    "dota",
    "overwatch",
}

SPORTS_REGEX = re.compile(
    r"\b(?:nba|wnba|nfl|nhl|mlb|mls|ncaab?|ncaaf|ufc|mma|f1|nascar|atp|wta|pga|"
    r"soccer|football|basketball|baseball|hockey|tennis|golf|cricket|rugby|volleyball|"
    r"badminton|esports?|valorant|dota|overwatch|cs2)\b",
    re.IGNORECASE,
)


def _normalized_set(values: list[str]) -> set[str]:
    return {normalize_category(value) for value in values if value}


def _contains_phrase(normalized_text: str, phrase: str) -> bool:
    """Match normalized words/phrases without substring false positives.

    For example, the hard-banned term ``sport`` must not match ``transportation``.
    """
    normalized_phrase = normalize_label(phrase)
    if not normalized_phrase:
        return False
    return f" {normalized_phrase} " in f" {normalized_text} "


def classify_universe(market: MarketData, config: UniverseSection) -> UniverseDecision:
    category = normalize_category(market.category)
    tags = _normalized_set(market.tags)
    hard_categories = _normalized_set(config.hard_block_categories)
    strategy_blocked = _normalized_set(config.strategy_block_categories)
    allowed = _normalized_set(config.allowed_categories)

    if config.sports_hard_ban:
        if market.game_start_time is not None:
            return UniverseDecision(
                hard_banned=True,
                eligible=False,
                reason="SPORTS_HARD_BAN: game_start_time present",
                category=category,
            )
        if market.game_id:
            return UniverseDecision(
                hard_banned=True,
                eligible=False,
                reason="SPORTS_HARD_BAN: game_id present",
                category=category,
            )
        if market.sports_market_type:
            return UniverseDecision(
                hard_banned=True,
                eligible=False,
                reason="SPORTS_HARD_BAN: sports market metadata present",
                category=category,
            )
        if category in hard_categories or tags.intersection(hard_categories):
            return UniverseDecision(
                hard_banned=True,
                eligible=False,
                reason="SPORTS_HARD_BAN: category/tag",
                category=category,
            )
        normalized_text = normalize_label(
            " ".join(
                [
                    market.event_title,
                    market.question,
                    market.group_item_title,
                    market.slug,
                    " ".join(market.tags),
                ]
            )
        )
        if any(_contains_phrase(normalized_text, term) for term in SPORTS_TERMS) or SPORTS_REGEX.search(
            normalized_text
        ):
            return UniverseDecision(
                hard_banned=True,
                eligible=False,
                reason="SPORTS_HARD_BAN: sports vocabulary",
                category=category,
            )

    if category in strategy_blocked or tags.intersection(strategy_blocked):
        return UniverseDecision(
            hard_banned=False,
            eligible=False,
            reason=f"STRATEGY_CATEGORY_BLOCK: {category or 'tag'}",
            category=category,
        )

    allowed_match = bool(allowed) and (category in allowed or bool(tags.intersection(allowed)))
    if not allowed_match:
        label = category or "missing/unknown"
        return UniverseDecision(
            hard_banned=False,
            eligible=False,
            reason=f"UNKNOWN_CATEGORY_OBSERVATION_ONLY: {label}",
            category=category,
        )

    return UniverseDecision(
        hard_banned=False,
        eligible=True,
        reason="ELIGIBLE_OBJECTIVE_UNIVERSE",
        category=category,
    )
