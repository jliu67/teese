from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class Model(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="ignore")


class MarketOutcome(Model):
    index: int
    label: str
    token_id: str
    reference_price: Decimal | None = None


class MarketData(Model):
    market_id: str
    condition_id: str | None = None
    event_id: str
    event_title: str = ""
    slug: str = ""
    question: str = ""
    group_item_title: str = ""
    rules: str = ""
    resolution_source: str = ""
    category: str = ""
    tags: list[str] = Field(default_factory=list)
    outcomes: list[MarketOutcome] = Field(default_factory=list)
    start_date: datetime | None = None
    end_date: datetime | None = None
    closed_time: datetime | None = None
    active: bool = False
    closed: bool = False
    archived: bool = False
    accepting_orders: bool = False
    enable_order_book: bool = True
    restricted: bool = False
    neg_risk: bool = False
    game_start_time: datetime | None = None
    game_id: str = ""
    sports_market_type: str = ""
    lifetime_volume: Decimal = Decimal("0")
    liquidity: Decimal = Decimal("0")
    min_tick_size: Decimal | None = None
    min_order_size: Decimal | None = None
    fees_enabled: bool | None = None
    fee_rate: Decimal | None = None
    fee_exponent: Decimal | None = None
    fee_taker_only: bool | None = None
    raw: dict[str, Any] = Field(default_factory=dict)

    def outcome_by_token(self, token_id: str) -> MarketOutcome | None:
        return next((outcome for outcome in self.outcomes if outcome.token_id == token_id), None)

    def outcome_for_side(self, side: str) -> MarketOutcome | None:
        """Return only an explicitly labelled side; never infer by array position."""
        normalized = side.strip().casefold()
        return next(
            (outcome for outcome in self.outcomes if outcome.label.strip().casefold() == normalized),
            None,
        )

    def semantic_snapshot(self) -> dict[str, Any]:
        """Return only metadata that can change what the contract means or maps to."""
        return {
            "market_id": self.market_id,
            "condition_id": self.condition_id,
            "event_id": self.event_id,
            "event_title": self.event_title,
            "slug": self.slug,
            "question": self.question,
            "group_item_title": self.group_item_title,
            "rules": self.rules,
            "resolution_source": self.resolution_source,
            "outcomes": [
                {
                    "index": outcome.index,
                    "label": outcome.label,
                    "token_id": outcome.token_id,
                }
                for outcome in self.outcomes
            ],
        }


class BookLevel(Model):
    price: Decimal
    size: Decimal


class OrderBook(Model):
    token_id: str
    condition_id: str | None = None
    timestamp: datetime | None = None
    bids: list[BookLevel] = Field(default_factory=list)
    asks: list[BookLevel] = Field(default_factory=list)
    min_order_size: Decimal | None = None
    tick_size: Decimal = Decimal("0.01")
    neg_risk: bool = False
    last_trade_price: Decimal | None = None
    book_hash: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def best_bid(self) -> Decimal | None:
        return max((level.price for level in self.bids), default=None)

    @property
    def best_ask(self) -> Decimal | None:
        return min((level.price for level in self.asks), default=None)

    @property
    def midpoint(self) -> Decimal | None:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / Decimal("2")

    @property
    def spread(self) -> Decimal | None:
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask - self.best_bid


class UniverseDecision(Model):
    hard_banned: bool
    eligible: bool
    reason: str
    category: str


class RuleAssessment(Model):
    deterministic: bool
    supported: bool
    adapter_id: str | None = None
    ambiguity_score: int = 0
    reasons: list[str] = Field(default_factory=list)
    rules_hash: str = ""


class SourceEvidence(Model):
    adapter_id: str
    status: Literal[
        "FINAL",
        "PENDING",
        "UNSUPPORTED",
        "HISTORICAL_UNAVAILABLE",
        "PARSE_ERROR",
        "SOURCE_MISMATCH",
        "STALE",
    ]
    period: str | None = None
    value: Decimal | None = None
    winning_side: Literal["YES", "NO"] | None = None
    winning_token_id: str | None = None
    release_at: datetime | None = None
    first_seen_at: datetime | None = None
    source_url: str = ""
    source_checksum: str = ""
    archive_path: str = ""
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class FillLeg(Model):
    displayed_price: Decimal
    effective_price: Decimal
    shares: Decimal
    notional: Decimal
    fee: Decimal


class FillPlan(Model):
    requested_notional: Decimal
    shares: Decimal = Decimal("0")
    raw_notional: Decimal = Decimal("0")
    fee: Decimal = Decimal("0")
    all_in_cost: Decimal = Decimal("0")
    raw_vwap: Decimal | None = None
    effective_vwap: Decimal | None = None
    all_in_cost_per_share: Decimal | None = None
    partial: bool = False
    legs: list[FillLeg] = Field(default_factory=list)
    reason: str = ""


class Evaluation(Model):
    strategy: str
    market_id: str
    event_id: str
    token_id: str | None = None
    outcome_label: str | None = None
    decision: Literal["ORDER", "OBSERVE", "REJECT"]
    reason: str
    reference_price: Decimal | None = None
    best_bid: Decimal | None = None
    best_ask: Decimal | None = None
    midpoint: Decimal | None = None
    spread: Decimal | None = None
    hours_to_end: Decimal | None = None
    expected_payout: Decimal | None = None
    net_edge_per_share: Decimal | None = None
    fill: FillPlan | None = None
    evidence_key: str = "none"
    source_status: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
