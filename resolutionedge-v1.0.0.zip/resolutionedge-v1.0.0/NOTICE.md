# Important notice

ResolutionEdge V1 is research and paper-trading software. It contains no real-order submission code.
Prediction-market trading can lose the entire amount staked. A high observed win rate does not imply
positive expected value. Verify platform eligibility, market rules, source data, taxes, and applicable
law before any future live use.
