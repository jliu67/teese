# Changelog

## 1.0.0 — 2026-08-31

Initial paper-only release.

### Added

- bounded Gamma market discovery;
- permanent sports/esports hard ban with event-level propagation;
- objective-category allowlist and blocked-category filters;
- decision-critical semantic fingerprint and permanent change halt;
- CLOB batch order-book collection;
- post-evidence source-confirmed book sequencing and stale-book rejection;
- raw non-sports CLOB WebSocket recorder;
- strict BLS U-3/Table A-15 source adapter;
- immutable first-seen evidence archive;
- optimistic and executable 97% control strategies with one entry per market;
- source-confirmed BLS strategy;
- pessimistic paper depth/latency/fee model;
- event-level source strategy cap;
- independent strategy shadow ledgers;
- SQLite audit database;
- progress, candidate, universe, and P&L reports;
- online/offline doctor;
- tmux operation scripts;
- 46-test validation suite.

### Deliberately absent

- sports research;
- live orders;
- wallet/private-key handling;
- automated parameter optimization;
- unsupported source adapters.
