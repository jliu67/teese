# ResolutionEdge V1

ResolutionEdge is a forward-only Polymarket research and paper-trading engine for one narrow hypothesis:

> An objective, machine-verifiable resolution source may publish the decisive result before the CLOB fully converges to the final payout.

V1 does **not** submit real orders. It contains no wallet handling, private-key handling, order signing, allowance management, or live-order endpoint. Its job is to collect honest evidence before deciding whether the hypothesis survives execution costs and tail risk.

## Non-negotiable V1 constraints

- **Sports and esports are hard-banned.** They are rejected before CLOB token selection, book requests, source evaluation, or strategy evaluation.
- **No live trading.** The only operating modes are `capture` and `paper`.
- **No market orders.** Paper execution is modeled as a price-capped taker order walking the visible ask ladder.
- **No tuned exit strategy.** V1 holds shadow positions to unambiguous settlement so the entry hypothesis is not rescued by after-the-fact sell rules.
- **No claim that 97–99¢ favorites are alpha.** That approach is retained as a control experiment.
- **Exact semantics matter.** Every decision-critical field—including bucket labels and outcome-token mapping—is fingerprinted. A change permanently halts that market.
- **Unsupported or ambiguous rules fail closed.** V1's sole source adapter is strict BLS U-3 unemployment.
- **Historical source values are not reconstructed from revised current pages.** V1 archives the first source snapshot it observes and refuses unsupported historical inference.

## What V1 runs side by side

### 1. `hf97_reference`

An intentionally optimistic control based on the public near-resolution idea:

- Gamma favorite price at least 0.97;
- `endDate` within 24 hours, plus a small post-end observation window;
- at least $500 lifetime volume;
- highest reference probability first.

It records a synthetic fill at the Gamma reference price. This control is deliberately non-executable and is labeled as such everywhere. It demonstrates how attractive the strategy can appear when a reference probability is confused with an entry price.

### 2. `hf97_executable`

Uses the same candidate signal but replaces the fictional fill with:

- the live CLOB ask ladder;
- a hard maximum price;
- one configurable latency-slippage tick;
- a 50% visible-depth haircut;
- current taker-fee modeling;
- partial-fill handling;
- minimum order and minimum notional checks.

This isolates how much of the apparent near-resolution return disappears through execution reality alone.

### 3. `source_confirmed_bls_u3`

The actual V1 research strategy. It can generate a paper order only when all of the following are true:

1. The market rules explicitly name the U.S. Bureau of Labor Statistics Employment Situation report.
2. They explicitly use U-3 from Table A-15.
3. The target data month and the contract's numerical bucket parse deterministically.
4. The official BLS summary and Table A-15 are both fetched.
5. Both documents report the same U-3 value.
6. The BLS embargo time has passed.
7. The exact first-seen HTML and metadata are archived immutably.
8. The value maps to an explicitly labelled YES or NO CLOB token; array position is never used.
9. The market remains orderable.
10. Only after source finality, a fresh two-sided live book is fetched. Its condition ID must match the market, its exchange timestamp must not materially predate the evidence, and it must be no more than 30 seconds old by default.
11. The spread passes the limit and the price-capped, fee-inclusive, latency-adjusted paper fill has adequate depth.
12. Conservative payout value minus all-in cost exceeds the preconfigured edge hurdle.
13. No other source-confirmed contract from the same event ladder has already been paper-traded.

`endDate` is only a discovery feature. It is never treated as proof that the result is final.

## Installation

Ubuntu/Debian prerequisites:

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-venv tmux
```

From the extracted project directory:

```bash
chmod +x scripts/*.sh
./scripts/bootstrap.sh
./scripts/doctor.sh
```

`bootstrap.sh` creates `.venv`, installs the package and test tools, initializes SQLite, and leaves live trading unavailable.

## Run one scan first

```bash
./scripts/run_once.sh
./scripts/progress.sh
./scripts/candidates.sh 30
./scripts/report.sh
./scripts/universe.sh
```

A one-off capture-only scan is:

```bash
./scripts/run_once.sh capture
```

In `capture` mode, candidate evaluations are archived but no shadow paper orders are opened.

## Run continuously in tmux

```bash
./scripts/start.sh paper
```

This creates three tmux windows:

- `engine`: market discovery, evidence, evaluation, paper entries, and settlement;
- `stream`: raw non-sports CLOB WebSocket archive;
- `monitor`: refreshed progress and candidate tables.

Useful commands:

```bash
./scripts/attach.sh
./scripts/progress.sh
./scripts/candidates.sh 50
./scripts/report.sh
./scripts/stop.sh
```

Start capture-only continuous operation with:

```bash
./scripts/start.sh capture
```

## Direct CLI

```bash
.venv/bin/resolutionedge --help
.venv/bin/resolutionedge doctor --config config/default.yaml
.venv/bin/resolutionedge scan --mode paper --config config/default.yaml
.venv/bin/resolutionedge run --mode paper --config config/default.yaml
.venv/bin/resolutionedge stream --config config/default.yaml
.venv/bin/resolutionedge progress --config config/default.yaml
.venv/bin/resolutionedge report --config config/default.yaml
.venv/bin/resolutionedge candidates --limit 30 --config config/default.yaml
.venv/bin/resolutionedge universe --config config/default.yaml
```

Passing `--mode live` fails immediately. No live execution class exists.

## Configuration

The frozen starting rules live in `config/default.yaml`.

Important paper assumptions:

```yaml
paper:
  starting_equity_usdc: 10000
  minimum_fill_usdc: 5
  latency_slippage_ticks: 1
  visible_depth_haircut: 0.50
  allow_partial_fills: true
```

Source-confirmed hurdle:

```yaml
source_confirmed:
  conservative_payout_per_share: 0.995
  minimum_net_edge_per_share: 0.003
  maximum_entry_price: 0.992
  maximum_spread: 0.04
  stake_usdc: 25
  one_order_per_event: true
  evidence_fresh_hours: 48
  maximum_book_age_seconds: 30
  post_evidence_timestamp_tolerance_seconds: 5
```

These are research assumptions, not optimized parameters. Do not repeatedly tune them against the observed paper results. Changes should be versioned and evaluated only on later forward observations.

## Sports ban implementation

The ban is redundant by design. A market is hard-blocked if any of these appear:

- sports/esports category or tag;
- explicit `gameStartTime` or `gameId`;
- explicit sports-market metadata;
- major league, sport, or esport vocabulary in the event title, question, group title, slug, or tags.

Hard-banned markets are stored only as Gamma classification/audit metadata. They stop before rule parsing, source retrieval, CLOB book collection, strategy evaluation, or WebSocket subscription. A ban propagates to every sibling market in the event and remains sticky across later scans. `resolutionedge universe` shows the stored classification counts.

## Source evidence behavior

For each accepted BLS release, V1 stores:

```text
data/evidence/bls_employment_situation/YYYY-MM/
├── employment_summary.html
├── table_a15.html
└── metadata.json
```

The files use first-write-wins semantics. They are not overwritten by later revisions. SQLite stores the period, value, release timestamp, first-seen timestamp, checksum, archive path, and parser metadata.

The parser fails closed when:

- it cannot identify the Employment Situation period;
- it cannot find the U-3 row;
- the summary and Table A-15 disagree;
- the target month is older than the current page and no archived first-seen snapshot exists;
- the contract bucket cannot be parsed;
- the market does not expose the expected YES/NO token;
- the evidence timestamp is materially inconsistent.

## Data produced

```text
data/
├── resolutionedge.db
├── runtime_status.json
├── stream_status.json
├── evidence/
└── streams/
    └── clob-market-*.jsonl.gz
```

Each run stores the application version and SHA-256 checksum of the active YAML configuration. Decision-critical market semantics are versioned separately from changing prices and liquidity.

SQLite tables include:

- `runs`
- `markets`
- `market_rule_versions` (full semantic snapshots, including bucket and token mapping)
- `book_snapshots`
- `rule_assessments`
- `source_releases`
- `source_evidence`
- `evaluations`
- `paper_orders`
- `runtime_meta`

Book snapshots are labelled by capture phase:

- `source_post_evidence`: winning-token book requested only after official source finality; source-confirmed evaluation additionally verifies the condition ID and exchange generation timestamp;
- `baseline_control_snapshot`: favorite-token book for the naive controls, collected after the source-priority path.

Every evaluation records its decision and reason, not only trades. This makes it possible to see whether opportunities disappear because of unsupported rules, pending data, stale evidence, spreads, fees, price caps, inadequate depth, event correlation, or duplicate suppression. Each naive control may enter a given market only once, even if the displayed favorite later flips.

## Paper-fill model

For each observed ask level:

1. Effective price is raised by the configured number of ticks.
2. Available shares are multiplied by the visible-depth haircut.
3. Levels above the hard maximum price are rejected.
4. Current taker fees are added per share.
5. The ladder is walked until the all-in USDC budget is exhausted or acceptable depth ends.

The paper stake is an all-in budget, not a pre-fee notional. The database separately records shares, execution notional, fees, total cost, observed VWAP, effective VWAP, and all-in cost per share.

Paper fills are still simulations. They cannot prove queue position, network latency, API reliability, or live fill quality. Raw WebSocket capture is included so later versions can test harsher latency assumptions against locally archived market changes.

## Settlement

At the beginning of every scan, open shadow orders are checked against Gamma. V1 settles only when the market is closed and the matching outcome exposes an unambiguous payout of 1, 0, or a market-wide 0.5. Ambiguous closed states remain open rather than being guessed.

## Reporting philosophy

The primary result is net P&L and return on settled cost, not win rate. At extreme prices, one loser can erase many winners. Reports therefore retain:

- all-in entry price;
- fees and modeled slippage;
- locked capital;
- settled cost and payout;
- net P&L and ROI;
- source status;
- rejection reasons;
- strategy/control separation.

## Verification

```bash
./scripts/verify.sh
```

The current release contains 42 passing tests. The test suite covers:

- sports hard-ban behavior before book requests;
- Gamma outcome/token/price alignment;
- BLS period, embargo, U-3, agreement, bucket, and immutable archive behavior;
- fee math;
- depth walking, price caps, latency, and haircuts;
- reference versus executable controls;
- source-confirmed edge gating;
- SQLite paper entry and settlement;
- end-to-end engine behavior with fake APIs.

## V1 boundaries

V1 intentionally does not include:

- sports or esports research;
- weather source adapters;
- CPI/payroll adapters;
- crypto markets;
- subjective politics, culture, mentions, or geopolitics strategies;
- LLM interpretation of resolution rules;
- cross-venue odds;
- wallet copying;
- maker-rebate farming;
- martingale sizing;
- leverage;
- real order placement.

A future version should be promoted only after a meaningful number of independent source events—not merely many correlated contracts—show positive net results under the executable paper model and a later untouched forward period.

## Included engineering documentation

- `docs/V1_BLUEPRINT.md` — implemented architecture, sequencing, gates, and promotion criteria;
- `docs/DATA_DICTIONARY.md` — runtime files, table concepts, and decision fields;
- `docs/VALIDATION.md` — dated validation record and network-test limitation;
- `CHANGELOG.md` — release contents.

## Notice

Prediction-market positions can lose the entire stake. A high win rate is not evidence of positive expected value. Platform eligibility, rules, resolution mechanics, taxes, and law must be checked independently before any future live system is considered.
