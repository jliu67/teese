from __future__ import annotations

from resolutionedge.rules import assess_rules
from resolutionedge.storage import Database

from conftest import make_market


def test_rule_or_source_change_is_persistently_detected(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    original = make_market()
    first = assess_rules(original)
    assert database.record_rule_version(original, rules_hash=first.rules_hash) is False
    assert database.record_rule_version(original, rules_hash=first.rules_hash) is False

    changed = original.model_copy(update={"resolution_source": "https://example.invalid/new-source"})
    second = assess_rules(changed)
    assert second.rules_hash != first.rules_hash
    assert database.record_rule_version(changed, rules_hash=second.rules_hash) is True
    assert database.market_has_rule_changes(original.market_id) is True


def test_semantic_fingerprint_covers_bucket_and_token_mapping():
    original = make_market()
    original_hash = assess_rules(original).rules_hash

    changed_bucket = original.model_copy(update={"group_item_title": "4.3%"})
    assert assess_rules(changed_bucket).rules_hash != original_hash

    changed_outcomes = original.model_copy(
        update={
            "outcomes": [
                original.outcomes[0].model_copy(update={"token_id": "replacement-token"}),
                original.outcomes[1],
            ]
        }
    )
    assert assess_rules(changed_outcomes).rules_hash != original_hash
