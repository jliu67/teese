from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest

from resolutionedge.clients.http import HttpResponseText
from resolutionedge.models import MarketOutcome
from resolutionedge.sources.bls_u3 import (
    BlsU3Adapter,
    parse_bucket_text,
    parse_current_release,
    parse_scheduled_release_at,
    parse_target_period,
)
from resolutionedge.storage import Database

from conftest import make_market


FIXTURES = Path(__file__).parent / "fixtures"
SUMMARY = (FIXTURES / "bls_summary.html").read_text()
TABLE = (FIXTURES / "bls_table_a15.html").read_text()


class FakeHttp:
    def __init__(self):
        self.calls = []

    def get_text(self, url: str):
        self.calls.append(url)
        text = SUMMARY if "nr0" in url else TABLE
        return HttpResponseText(text=text, headers={}, status_code=200)


def test_parse_current_release_requires_summary_table_agreement():
    release = parse_current_release(
        SUMMARY,
        TABLE,
        timezone_name="America/New_York",
        require_agreement=True,
    )
    assert release.period == "2026-07"
    assert release.value == Decimal("4.1")
    assert release.summary_value == Decimal("4.1")
    assert release.release_at == datetime(2026, 8, 7, 12, 30, tzinfo=UTC)


def test_source_disagreement_is_fail_closed():
    bad_summary = SUMMARY.replace("4.1 percent", "4.2 percent")
    with pytest.raises(ValueError, match="source mismatch"):
        parse_current_release(
            bad_summary,
            TABLE,
            timezone_name="America/New_York",
            require_agreement=True,
        )


@pytest.mark.parametrize(
    ("text", "kind", "low", "high"),
    [
        ("4.2%", "exact", Decimal("4.2"), None),
        ("4.0% or lower", "lte", None, Decimal("4.0")),
        ("4.4% or higher", "gte", Decimal("4.4"), None),
        ("4.1% - 4.3%", "range", Decimal("4.1"), Decimal("4.3")),
    ],
)
def test_bucket_parser(text, kind, low, high):
    bucket = parse_bucket_text(text)
    assert bucket is not None
    assert bucket.kind == kind
    assert bucket.low == low
    assert bucket.high == high


def test_target_period_prefers_rules():
    market = make_market(
        question="Will unemployment be 4.2%?",
        title="Unemployment rate",
        rules=(
            "This resolves from the Employment Situation report for July 2026, using the "
            "Bureau of Labor Statistics U-3 value in Table A-15 at bls.gov."
        ),
    )
    assert parse_target_period(market) == "2026-07"


def test_adapter_archives_first_seen_source_and_maps_yes(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    adapter = BlsU3Adapter(
        config=temp_settings.bls,
        http=FakeHttp(),  # type: ignore[arg-type]
        database=database,
        evidence_root=temp_settings.app.evidence_dir,
    )
    market = make_market(
        group_title="4.1%",
        title="July 2026 unemployment rate",
        question="Will the July 2026 unemployment rate be 4.1%?",
        rules=(
            "This market resolves based on the U.S. Bureau of Labor Statistics Employment Situation "
            "report for July 2026. The official unemployment rate is U-3 in Table A-15. "
            "Resolution source: https://www.bls.gov/news.release/empsit.t15.htm"
        ),
    )
    evidence = adapter.evaluate(market)
    assert evidence.status == "FINAL"
    assert evidence.value == Decimal("4.1")
    assert evidence.winning_side == "YES"
    assert evidence.winning_token_id == "m1-yes"
    assert evidence.first_seen_at is not None
    assert database.get_source_release("bls_u3", "2026-07") is not None
    assert (temp_settings.app.evidence_dir / evidence.archive_path).exists()


def test_table_period_must_match_summary_period():
    stale_table = TABLE.replace("July 2026", "June 2026")
    with pytest.raises(ValueError, match="release-period mismatch"):
        parse_current_release(
            SUMMARY,
            stale_table,
            timezone_name="America/New_York",
            require_agreement=True,
        )


def test_missing_embargo_timestamp_is_fail_closed():
    summary_without_embargo = SUMMARY.replace(
        "Transmission of material in this news release is embargoed until 8:30 a.m. (ET) Friday, August 7, 2026",
        "FOR RELEASE",
    )
    with pytest.raises(ValueError, match="embargo/release timestamp"):
        parse_current_release(
            summary_without_embargo,
            TABLE,
            timezone_name="America/New_York",
            require_agreement=True,
        )


def test_adapter_requires_explicit_yes_no_labels(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    adapter = BlsU3Adapter(
        config=temp_settings.bls,
        http=FakeHttp(),  # type: ignore[arg-type]
        database=database,
        evidence_root=temp_settings.app.evidence_dir,
    )
    market = make_market(
        group_title="4.1%",
        title="July 2026 unemployment rate",
        question="Will the July 2026 unemployment rate be 4.1%?",
        rules=(
            "This market resolves based on the U.S. Bureau of Labor Statistics Employment Situation "
            "report for July 2026. The official unemployment rate is U-3 in Table A-15. "
            "Resolution source: https://www.bls.gov/news.release/empsit.t15.htm"
        ),
    ).model_copy(
        update={
            "outcomes": [
                MarketOutcome(index=0, label="Above", token_id="above"),
                MarketOutcome(index=1, label="Below", token_id="below"),
            ]
        }
    )
    evidence = adapter.evaluate(market)
    assert evidence.status == "SOURCE_MISMATCH"
    assert evidence.winning_token_id is None


def test_parse_scheduled_bls_release_from_rules():
    market = make_market(
        rules=(
            "This uses the BLS Employment Situation report for August 2026, U-3 in Table A-15. "
            "The relevant data release is scheduled for September 4, 2026, at 8:30 AM ET. "
            "Source: https://www.bls.gov/news.release/empsit.t15.htm"
        )
    )
    assert parse_scheduled_release_at(market, "America/New_York") == datetime(
        2026, 9, 4, 12, 30, tzinfo=UTC
    )


def test_adapter_does_not_fetch_source_far_before_scheduled_release(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    http = FakeHttp()
    adapter = BlsU3Adapter(
        config=temp_settings.bls,
        http=http,  # type: ignore[arg-type]
        database=database,
        evidence_root=temp_settings.app.evidence_dir,
    )
    market = make_market(
        question="Will the January 2099 unemployment rate be 4.1%?",
        title="January 2099 unemployment rate",
        group_title="4.1%",
        rules=(
            "This market resolves from the Bureau of Labor Statistics Employment Situation report "
            "for January 2099, using the official unemployment rate U-3 in Table A-15. "
            "The relevant data release is scheduled for February 6, 2099, at 8:30 AM ET. "
            "Source: https://www.bls.gov/news.release/empsit.t15.htm"
        ),
    )
    evidence = adapter.evaluate(market)
    assert evidence.status == "PENDING"
    assert evidence.release_at == datetime(2099, 2, 6, 13, 30, tzinfo=UTC)
    assert http.calls == []


def test_orphaned_first_seen_archive_is_recovered_without_refetch(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    period_dir = (
        temp_settings.app.evidence_dir
        / temp_settings.bls.archive_subdirectory
        / "2026-07"
    )
    period_dir.mkdir(parents=True)
    (period_dir / "employment_summary.html").write_text(SUMMARY)
    (period_dir / "table_a15.html").write_text(TABLE)

    http = FakeHttp()
    adapter = BlsU3Adapter(
        config=temp_settings.bls,
        http=http,  # type: ignore[arg-type]
        database=database,
        evidence_root=temp_settings.app.evidence_dir,
    )
    market = make_market(
        group_title="4.1%",
        title="July 2026 unemployment rate",
        question="Will the July 2026 unemployment rate be 4.1%?",
        rules=(
            "This market resolves based on the U.S. Bureau of Labor Statistics Employment Situation "
            "report for July 2026. The official unemployment rate is U-3 in Table A-15. "
            "Resolution source: https://www.bls.gov/news.release/empsit.t15.htm"
        ),
    )
    evidence = adapter.evaluate(market)
    assert evidence.status == "FINAL"
    assert evidence.value == Decimal("4.1")
    assert http.calls == []
    assert (period_dir / "metadata.json").exists()
    assert database.get_source_release("bls_u3", "2026-07") is not None
