from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from resolutionedge.config import load_settings


def test_configuration_cannot_disable_sports_hard_ban(tmp_path: Path):
    source = Path(__file__).parents[1] / "config/default.yaml"
    raw = yaml.safe_load(source.read_text())
    raw["universe"]["sports_hard_ban"] = False
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(raw))
    with pytest.raises(ValidationError, match="sports_hard_ban=true"):
        load_settings(path)


def test_configuration_must_keep_sports_and_esports_blocks(tmp_path: Path):
    source = Path(__file__).parents[1] / "config/default.yaml"
    raw = yaml.safe_load(source.read_text())
    raw["universe"]["hard_block_categories"] = ["sports"]
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(raw))
    with pytest.raises(ValidationError, match="sports and esports"):
        load_settings(path)


def test_strategy_names_must_be_unique(tmp_path: Path):
    source = Path(__file__).parents[1] / "config/default.yaml"
    raw = yaml.safe_load(source.read_text())
    raw["baseline"]["executable_strategy_name"] = raw["baseline"]["reference_strategy_name"]
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(raw))
    with pytest.raises(ValidationError, match="strategy names must be unique"):
        load_settings(path)
