from __future__ import annotations

from decimal import Decimal

from resolutionedge.clients.gamma import GammaClient, parse_gamma_market


def test_gamma_parallel_arrays_are_mapped_by_index():
    market = parse_gamma_market(
        {
            "id": "123",
            "conditionId": "0xabc",
            "question": "Test?",
            "outcomes": '["Yes","No"]',
            "clobTokenIds": '["yes-token","no-token"]',
            "outcomePrices": '["0.97","0.03"]',
            "active": True,
            "closed": False,
            "acceptingOrders": True,
            "volumeNum": 1000,
            "events": [{"id": "e1", "title": "Event", "category": "Economics"}],
            "feeSchedule": {"rate": 0.05, "takerOnly": True},
        }
    )
    assert market.event_id == "e1"
    assert market.outcomes[0].token_id == "yes-token"
    assert market.outcomes[0].reference_price == Decimal("0.97")
    assert market.fee_rate == Decimal("0.05")


class CapturingHttp:
    def __init__(self):
        self.calls = []

    def get_json(self, url, params=None):
        self.calls.append((url, params))
        return []


def test_gamma_discovery_passes_server_side_end_date_bounds():
    http = CapturingHttp()
    client = GammaClient(http, "https://gamma.example")  # type: ignore[arg-type]
    assert list(
        client.list_active_markets(
            page_size=500,
            max_pages=2,
            end_date_min="2026-08-30T00:00:00Z",
            end_date_max="2026-09-07T00:00:00Z",
        )
    ) == []
    _, params = http.calls[0]
    assert params["end_date_min"] == "2026-08-30T00:00:00Z"
    assert params["end_date_max"] == "2026-09-07T00:00:00Z"


def test_gamma_reads_sports_metadata_from_attached_event():
    market = parse_gamma_market(
        {
            "id": "sport-1",
            "question": "Winner?",
            "outcomes": '["Yes","No"]',
            "clobTokenIds": '["yes","no"]',
            "events": [
                {
                    "id": "event-sport",
                    "gameStartTime": "2026-09-01T00:00:00Z",
                    "sportsMarketType": "moneyline",
                }
            ],
        }
    )
    assert market.game_start_time is not None
    assert market.sports_market_type == "moneyline"

def test_gamma_parser_does_not_infer_yes_no_labels_by_position() -> None:
    market = parse_gamma_market(
        {
            "id": "m-unlabelled",
            "conditionId": "condition",
            "active": True,
            "closed": False,
            "acceptingOrders": True,
            "clobTokenIds": '["token-a", "token-b"]',
            "outcomePrices": '["0.7", "0.3"]',
            "endDate": "2026-09-01T00:00:00Z",
        }
    )

    assert [outcome.label for outcome in market.outcomes] == ["", ""]
    assert market.outcome_for_side("YES") is None
    assert market.outcome_for_side("NO") is None

