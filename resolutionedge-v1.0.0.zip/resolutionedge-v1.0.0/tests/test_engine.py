from __future__ import annotations

from decimal import Decimal

from resolutionedge.engine import ResolutionEdgeEngine
from resolutionedge.models import BookLevel, OrderBook, SourceEvidence
from resolutionedge.sources.base import SourceAdapter
from resolutionedge.sources.registry import SourceRegistry
from resolutionedge.storage import Database
from resolutionedge.utils import utc_now

from conftest import make_market


class FakeHttp:
    def close(self):
        pass


class FakeGamma:
    def __init__(self, markets):
        self.markets = markets

    def list_active_markets(self, **kwargs):
        yield from self.markets

    def get_market(self, market_id):
        return next(item for item in self.markets if item.market_id == market_id)


class FakeClob:
    def __init__(self, books, sequence=None):
        self.books = books
        self.requested = []
        self.calls = []
        self.sequence = sequence

    def get_order_books(self, token_ids, **kwargs):
        token_ids = list(token_ids)
        self.calls.append(token_ids)
        self.requested.extend(token_ids)
        if self.sequence is not None:
            self.sequence.append(("books", token_ids))
        return ({token: self.books[token] for token in token_ids if token in self.books}, {})


class FinalAdapter(SourceAdapter):
    adapter_id = "bls_u3"

    def __init__(self, sequence=None):
        self.sequence = sequence

    def supports(self, market):
        return True

    def evaluate(self, market):
        if self.sequence is not None:
            self.sequence.append(("evidence", market.market_id))
        return SourceEvidence(
            adapter_id="bls_u3",
            status="FINAL",
            period="2026-08",
            value=Decimal("4.2"),
            winning_side="YES",
            winning_token_id=market.outcomes[0].token_id,
            first_seen_at=utc_now(),
            source_checksum="source-checksum",
            archive_path="fixture",
            reason="fixture source final",
        )


def test_engine_hard_bans_sports_before_book_request(temp_settings):
    objective = make_market(market_id="econ", event_id="econ-event")
    sport = make_market(
        market_id="sport",
        event_id="sport-event",
        category="sports",
        title="NBA game winner",
        question="Will the Lakers win?",
    )
    books = {}
    for market in (objective, sport):
        books[market.outcomes[0].token_id] = OrderBook(
            token_id=market.outcomes[0].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.965"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.970"), size=Decimal("1000"))],
        )
        books[market.outcomes[1].token_id] = OrderBook(
            token_id=market.outcomes[1].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.025"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.030"), size=Decimal("1000"))],
        )
    fake_clob = FakeClob(books)
    database = Database(temp_settings.app.database_path)
    engine = ResolutionEdgeEngine(
        temp_settings,
        database=database,
        http=FakeHttp(),  # type: ignore[arg-type]
        gamma=FakeGamma([sport, objective]),  # type: ignore[arg-type]
        clob=fake_clob,  # type: ignore[arg-type]
        source_registry=SourceRegistry([FinalAdapter()]),
    )
    stats = engine.scan_once(mode="paper")
    assert stats["sports_hard_banned"] == 1
    assert "sport-yes" not in fake_clob.requested
    assert "sport-no" not in fake_clob.requested
    stored_sport = database.rows("SELECT hard_banned, universe_reason FROM markets WHERE market_id='sport'")[0]
    assert stored_sport["hard_banned"] == 1
    assert stored_sport["universe_reason"].startswith("SPORTS_HARD_BAN")
    assert database.scalar("SELECT COUNT(*) FROM paper_orders") == 3
    assert database.scalar(
        "SELECT COUNT(*) FROM paper_orders WHERE strategy='source_confirmed_bls_u3'"
    ) == 1
    phases = {
        row["capture_phase"]
        for row in database.rows("SELECT capture_phase FROM book_snapshots")
    }
    assert phases == {"baseline_control_snapshot", "source_post_evidence"}


def test_source_finality_is_checked_before_winning_book_refresh(temp_settings):
    sequence = []
    market = make_market(market_id="econ", event_id="econ-event")
    books = {
        market.outcomes[0].token_id: OrderBook(
            token_id=market.outcomes[0].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.965"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.970"), size=Decimal("1000"))],
        ),
        market.outcomes[1].token_id: OrderBook(
            token_id=market.outcomes[1].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.025"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.030"), size=Decimal("1000"))],
        ),
    }
    baseline = temp_settings.baseline.model_copy(update={"enabled": False})
    settings = temp_settings.model_copy(update={"baseline": baseline})
    engine = ResolutionEdgeEngine(
        settings,
        database=Database(settings.app.database_path),
        http=FakeHttp(),  # type: ignore[arg-type]
        gamma=FakeGamma([market]),  # type: ignore[arg-type]
        clob=FakeClob(books, sequence=sequence),  # type: ignore[arg-type]
        source_registry=SourceRegistry([FinalAdapter(sequence=sequence)]),
    )
    stats = engine.scan_once(mode="paper")
    assert sequence[0] == ("evidence", "econ")
    assert sequence[1] == ("books", ["econ-yes"])
    assert stats["baseline_book_tokens_requested"] == 0
    assert stats["source_book_tokens_requested"] == 1


def test_sports_ban_propagates_to_every_market_in_same_event(temp_settings):
    sport = make_market(
        market_id="sport-labelled",
        event_id="shared-sport-event",
        category="sports",
        title="NBA game winner",
        question="Will Team A win?",
    )
    disguised_sibling = make_market(
        market_id="sport-sibling",
        event_id="shared-sport-event",
        category="economics",
        title="Team A special market",
        question="Will option A occur?",
    )
    fake_clob = FakeClob({})
    database = Database(temp_settings.app.database_path)
    engine = ResolutionEdgeEngine(
        temp_settings,
        database=database,
        http=FakeHttp(),  # type: ignore[arg-type]
        gamma=FakeGamma([disguised_sibling, sport]),  # type: ignore[arg-type]
        clob=fake_clob,  # type: ignore[arg-type]
        source_registry=SourceRegistry([FinalAdapter()]),
    )
    stats = engine.scan_once(mode="capture")
    assert stats["sports_hard_banned"] == 2
    assert fake_clob.requested == []
    rows = database.rows(
        "SELECT market_id, hard_banned, universe_reason FROM markets ORDER BY market_id"
    )
    assert all(row["hard_banned"] == 1 for row in rows)


def test_source_path_precedes_baseline_control_snapshot(temp_settings):
    sequence = []
    market = make_market(market_id="priority", event_id="priority-event")
    books = {
        market.outcomes[0].token_id: OrderBook(
            token_id=market.outcomes[0].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.965"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.970"), size=Decimal("1000"))],
        )
    }
    engine = ResolutionEdgeEngine(
        temp_settings,
        database=Database(temp_settings.app.database_path),
        http=FakeHttp(),  # type: ignore[arg-type]
        gamma=FakeGamma([market]),  # type: ignore[arg-type]
        clob=FakeClob(books, sequence=sequence),  # type: ignore[arg-type]
        source_registry=SourceRegistry([FinalAdapter(sequence=sequence)]),
    )

    engine.scan_once(mode="capture")

    assert sequence == [
        ("evidence", "priority"),
        ("books", ["priority-yes"]),
        ("books", ["priority-yes"]),
    ]


def test_baseline_controls_do_not_reenter_same_market_after_favorite_flips(temp_settings):
    first = make_market(market_id="flip", event_id="flip-event", yes_price="0.97", no_price="0.03")
    second = make_market(market_id="flip", event_id="flip-event", yes_price="0.03", no_price="0.97")
    books = {}
    for market in (first, second):
        for outcome in market.outcomes:
            if outcome.label == "Yes":
                bid, ask = Decimal("0.965"), Decimal("0.970")
            else:
                bid, ask = Decimal("0.025"), Decimal("0.030")
            if outcome.reference_price == Decimal("0.97"):
                bid, ask = Decimal("0.965"), Decimal("0.970")
            books[outcome.token_id] = OrderBook(
                token_id=outcome.token_id,
                condition_id=market.condition_id,
                timestamp=utc_now(),
                tick_size=Decimal("0.001"),
                bids=[BookLevel(price=bid, size=Decimal("1000"))],
                asks=[BookLevel(price=ask, size=Decimal("1000"))],
            )

    database = Database(temp_settings.app.database_path)
    gamma = FakeGamma([first])
    engine = ResolutionEdgeEngine(
        temp_settings,
        database=database,
        http=FakeHttp(),  # type: ignore[arg-type]
        gamma=gamma,  # type: ignore[arg-type]
        clob=FakeClob(books),  # type: ignore[arg-type]
        source_registry=SourceRegistry([FinalAdapter()]),
    )
    engine.scan_once(mode="paper")
    assert database.scalar("SELECT COUNT(*) FROM paper_orders") == 3

    gamma.markets = [second]
    engine.scan_once(mode="paper")

    assert database.scalar("SELECT COUNT(*) FROM paper_orders") == 3
    baseline_observes = database.scalar(
        """
        SELECT COUNT(*) FROM evaluations
        WHERE market_id='flip' AND decision='OBSERVE'
          AND reason='This control strategy already paper-traded this market'
        """
    )
    assert baseline_observes == 2

