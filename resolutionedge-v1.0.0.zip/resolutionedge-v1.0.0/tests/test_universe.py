from __future__ import annotations

from resolutionedge.models import MarketData
from resolutionedge.universe import classify_universe

from conftest import make_market


def test_sports_category_is_hard_banned(temp_settings):
    market = make_market(category="sports", title="NBA winner", question="Will Team A win?")
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is True
    assert decision.eligible is False
    assert decision.reason.startswith("SPORTS_HARD_BAN")


def test_sports_vocabulary_is_hard_banned_even_without_category(temp_settings):
    market = make_market(category="", title="Lakers vs Celtics NBA", question="Will Lakers win?")
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is True


def test_objective_economics_is_eligible(temp_settings):
    decision = classify_universe(make_market(), temp_settings.universe)
    assert decision.hard_banned is False
    assert decision.eligible is True


def test_unknown_category_is_observation_only(temp_settings):
    market = MarketData(market_id="x", event_id="x", category="mystery")
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is False
    assert decision.eligible is False
    assert "OBSERVATION_ONLY" in decision.reason


def test_sport_term_does_not_false_match_transportation(temp_settings):
    market = make_market(
        category="economics",
        title="Transportation costs in CPI",
        question="Will transportation services inflation exceed 4.2%?",
    )
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is False
    assert decision.eligible is True


def test_missing_category_and_tags_is_observation_only(temp_settings):
    market = MarketData(market_id="blank", event_id="blank", question="Objective result?")
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is False
    assert decision.eligible is False
    assert "missing/unknown" in decision.reason


def test_game_id_metadata_is_hard_banned(temp_settings):
    market = make_market().model_copy(update={"game_id": "game-123"})
    decision = classify_universe(market, temp_settings.universe)
    assert decision.hard_banned is True
    assert decision.reason == "SPORTS_HARD_BAN: game_id present"
