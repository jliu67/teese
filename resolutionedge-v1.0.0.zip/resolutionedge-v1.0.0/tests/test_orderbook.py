from __future__ import annotations

from decimal import Decimal

from resolutionedge.models import BookLevel, OrderBook
from resolutionedge.strategy.fees import taker_fee
from resolutionedge.strategy.orderbook import simulate_taker_buy, synthetic_reference_fill


def test_current_taker_fee_formula():
    fee = taker_fee(shares=Decimal("100"), price=Decimal("0.99"), fee_rate=Decimal("0.05"))
    assert fee == Decimal("0.049500")


def test_taker_buy_walks_depth_with_latency_and_haircut():
    book = OrderBook(
        token_id="yes",
        tick_size=Decimal("0.001"),
        bids=[BookLevel(price=Decimal("0.960"), size=Decimal("100"))],
        asks=[
            BookLevel(price=Decimal("0.970"), size=Decimal("4")),
            BookLevel(price=Decimal("0.980"), size=Decimal("20")),
        ],
    )
    plan = simulate_taker_buy(
        book,
        requested_notional=Decimal("10"),
        fee_rate=Decimal("0.05"),
        maximum_price=Decimal("0.985"),
        latency_slippage_ticks=1,
        visible_depth_haircut=Decimal("0.5"),
        allow_partial_fills=True,
    )
    assert plan.shares > 0
    assert len(plan.legs) == 2
    assert plan.legs[0].displayed_price == Decimal("0.970")
    assert plan.legs[0].effective_price == Decimal("0.971")
    assert plan.effective_vwap is not None and plan.effective_vwap > Decimal("0.971")
    assert plan.all_in_cost <= Decimal("10.000001")


def test_hard_price_cap_prevents_fill_after_latency():
    book = OrderBook(
        token_id="yes",
        tick_size=Decimal("0.001"),
        asks=[BookLevel(price=Decimal("0.992"), size=Decimal("100"))],
    )
    plan = simulate_taker_buy(
        book,
        requested_notional=Decimal("10"),
        fee_rate=Decimal("0.05"),
        maximum_price=Decimal("0.992"),
        latency_slippage_ticks=1,
        visible_depth_haircut=Decimal("1"),
        allow_partial_fills=True,
    )
    assert plan.shares == 0
    assert plan.reason == "no_depth_at_or_below_limit"


def test_reference_control_is_marked_synthetic():
    plan = synthetic_reference_fill(
        requested_notional=Decimal("10"),
        reference_price=Decimal("0.97"),
        fee_rate=Decimal("0.05"),
        maximum_price=Decimal("0.999"),
    )
    assert plan.shares > 0
    assert plan.reason == "synthetic_gamma_reference_control"
