from __future__ import annotations

from datetime import timedelta
from decimal import Decimal
from pathlib import Path

import pytest

from resolutionedge.config import Settings, load_settings
from resolutionedge.models import MarketData, MarketOutcome
from resolutionedge.utils import utc_now


@pytest.fixture
def temp_settings(tmp_path: Path) -> Settings:
    settings = load_settings(Path(__file__).parents[1] / "config/default.yaml")
    app = settings.app.model_copy(
        update={
            "status_path": tmp_path / "runtime_status.json",
            "database_path": tmp_path / "resolutionedge.db",
            "evidence_dir": tmp_path / "evidence",
            "stream_dir": tmp_path / "streams",
            "log_path": tmp_path / "resolutionedge.log",
        }
    )
    settings = settings.model_copy(update={"project_root": tmp_path, "app": app})
    settings.ensure_directories()
    return settings


def make_market(
    *,
    market_id: str = "m1",
    event_id: str = "e1",
    category: str = "economics",
    question: str = "Will the August 2026 unemployment rate be 4.2%?",
    title: str = "August 2026 unemployment rate",
    group_title: str = "4.2%",
    rules: str | None = None,
    end_hours: float = 3,
    yes_price: str = "0.97",
    no_price: str = "0.03",
    volume: str = "10000",
) -> MarketData:
    rules = rules or (
        "This market resolves based on the U.S. Bureau of Labor Statistics Employment Situation "
        "report for August 2026. The official unemployment rate is U-3 in Table A-15. "
        "Resolution source: https://www.bls.gov/news.release/empsit.t15.htm"
    )
    return MarketData(
        market_id=market_id,
        condition_id=f"c-{market_id}",
        event_id=event_id,
        event_title=title,
        slug=market_id,
        question=question,
        group_item_title=group_title,
        rules=rules,
        resolution_source="https://www.bls.gov/news.release/empsit.t15.htm",
        category=category,
        tags=[category],
        outcomes=[
            MarketOutcome(index=0, label="Yes", token_id=f"{market_id}-yes", reference_price=Decimal(yes_price)),
            MarketOutcome(index=1, label="No", token_id=f"{market_id}-no", reference_price=Decimal(no_price)),
        ],
        end_date=utc_now() + timedelta(hours=end_hours),
        active=True,
        closed=False,
        accepting_orders=True,
        enable_order_book=True,
        lifetime_volume=Decimal(volume),
        liquidity=Decimal("5000"),
        min_tick_size=Decimal("0.001"),
        min_order_size=Decimal("1"),
        fees_enabled=True,
        fee_rate=Decimal("0.05"),
        raw={"id": market_id},
    )
