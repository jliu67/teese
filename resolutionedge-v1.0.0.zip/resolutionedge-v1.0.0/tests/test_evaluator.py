from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from resolutionedge.models import BookLevel, OrderBook, SourceEvidence
from resolutionedge.rules import assess_rules
from resolutionedge.strategy.evaluator import (
    evaluate_hf97_executable,
    evaluate_hf97_reference,
    evaluate_source_confirmed,
)
from resolutionedge.utils import utc_now

from conftest import make_market


def _books(market):
    return {
        market.outcomes[0].token_id: OrderBook(
            token_id=market.outcomes[0].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.965"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.970"), size=Decimal("1000"))],
        ),
        market.outcomes[1].token_id: OrderBook(
            token_id=market.outcomes[1].token_id,
            condition_id=market.condition_id,
            timestamp=utc_now(),
            tick_size=Decimal("0.001"),
            bids=[BookLevel(price=Decimal("0.025"), size=Decimal("1000"))],
            asks=[BookLevel(price=Decimal("0.030"), size=Decimal("1000"))],
        ),
    }


def test_baselines_keep_naive_signal_but_distinguish_execution(temp_settings):
    market = make_market()
    books = _books(market)
    reference = evaluate_hf97_reference(market, books, temp_settings)
    executable = evaluate_hf97_executable(market, books, temp_settings)
    assert reference.decision == "ORDER"
    assert executable.decision == "ORDER"
    assert reference.fill is not None and reference.fill.reason == "synthetic_gamma_reference_control"
    assert executable.fill is not None
    assert executable.fill.effective_vwap > reference.fill.effective_vwap


def test_source_confirmed_requires_positive_conservative_edge(temp_settings):
    market = make_market(group_title="4.2%")
    books = _books(market)
    assessment = assess_rules(market)
    evidence = SourceEvidence(
        adapter_id="bls_u3",
        status="FINAL",
        period="2026-08",
        value=Decimal("4.2"),
        winning_side="YES",
        winning_token_id=market.outcomes[0].token_id,
        first_seen_at=utc_now(),
        source_checksum="abc",
        archive_path="bls/test",
        reason="official source final",
    )
    evaluation = evaluate_source_confirmed(
        market,
        books,
        assessment,
        evidence,
        temp_settings,
    )
    assert evaluation.decision == "ORDER"
    assert evaluation.net_edge_per_share is not None
    assert evaluation.net_edge_per_share >= Decimal(str(temp_settings.source_confirmed.minimum_net_edge_per_share))


def test_pending_source_is_observe_not_order(temp_settings):
    market = make_market()
    assessment = assess_rules(market)
    evidence = SourceEvidence(adapter_id="bls_u3", status="PENDING", reason="not published")
    evaluation = evaluate_source_confirmed(market, _books(market), assessment, evidence, temp_settings)
    assert evaluation.decision == "OBSERVE"


def _final_evidence(market, *, first_seen_at=None):
    return SourceEvidence(
        adapter_id="bls_u3",
        status="FINAL",
        period="2026-08",
        value=Decimal("4.2"),
        winning_side="YES",
        winning_token_id=market.outcomes[0].token_id,
        first_seen_at=first_seen_at or utc_now(),
        source_checksum="abc",
        archive_path="bls/test",
        reason="official source final",
    )


def test_source_confirmed_rejects_book_without_exchange_timestamp(temp_settings):
    market = make_market(group_title="4.2%")
    books = _books(market)
    token_id = market.outcomes[0].token_id
    books[token_id] = books[token_id].model_copy(update={"timestamp": None})
    evaluation = evaluate_source_confirmed(
        market,
        books,
        assess_rules(market),
        _final_evidence(market),
        temp_settings,
    )
    assert evaluation.decision == "REJECT"
    assert "generation timestamp" in evaluation.reason


def test_source_confirmed_rejects_book_that_predates_evidence(temp_settings):
    market = make_market(group_title="4.2%")
    evidence_time = utc_now()
    books = _books(market)
    token_id = market.outcomes[0].token_id
    books[token_id] = books[token_id].model_copy(
        update={"timestamp": evidence_time - timedelta(seconds=10)}
    )
    evaluation = evaluate_source_confirmed(
        market,
        books,
        assess_rules(market),
        _final_evidence(market, first_seen_at=evidence_time),
        temp_settings,
        now=evidence_time,
    )
    assert evaluation.decision == "REJECT"
    assert "predates the official evidence" in evaluation.reason


def test_source_confirmed_rejects_mismatched_book_condition(temp_settings):
    market = make_market(group_title="4.2%")
    books = _books(market)
    token_id = market.outcomes[0].token_id
    books[token_id] = books[token_id].model_copy(update={"condition_id": "wrong-condition"})
    evaluation = evaluate_source_confirmed(
        market,
        books,
        assess_rules(market),
        _final_evidence(market),
        temp_settings,
    )
    assert evaluation.decision == "REJECT"
    assert "condition ID does not match" in evaluation.reason

