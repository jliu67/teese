from __future__ import annotations

from decimal import Decimal

from resolutionedge.models import Evaluation, FillPlan, UniverseDecision
from resolutionedge.storage import Database

from conftest import make_market


def test_market_upsert_and_paper_settlement(temp_settings):
    database = Database(temp_settings.app.database_path)
    database.initialize()
    run_id = database.start_run("paper")
    market = make_market()
    database.upsert_market(
        run_id,
        market,
        UniverseDecision(hard_banned=False, eligible=True, reason="ok", category="economics"),
        rules_hash="hash",
    )
    fill = FillPlan(
        requested_notional=Decimal("10"),
        shares=Decimal("10"),
        raw_notional=Decimal("9.70"),
        fee=Decimal("0.01"),
        all_in_cost=Decimal("9.71"),
        raw_vwap=Decimal("0.97"),
        effective_vwap=Decimal("0.97"),
        all_in_cost_per_share=Decimal("0.971"),
        reason="test",
    )
    evaluation = Evaluation(
        strategy="test",
        market_id=market.market_id,
        event_id=market.event_id,
        token_id="m1-yes",
        outcome_label="Yes",
        decision="ORDER",
        reason="test",
        fill=fill,
        expected_payout=Decimal("1"),
        net_edge_per_share=Decimal("0.029"),
        evidence_key="evidence",
    )
    order_id = database.insert_paper_order(run_id, evaluation)
    assert order_id is not None
    database.settle_order(order_id, payout_per_share=Decimal("1"), settlement_raw={"closed": True})
    row = database.rows("SELECT status, net_pnl FROM paper_orders WHERE id=?", (order_id,))[0]
    assert row["status"] == "SETTLED"
    assert Decimal(row["net_pnl"]) == Decimal("0.29")
