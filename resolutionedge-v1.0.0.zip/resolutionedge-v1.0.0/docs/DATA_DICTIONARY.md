# ResolutionEdge V1 data dictionary

## Runtime files

| Path | Purpose |
|---|---|
| `data/resolutionedge.db` | SQLite audit and paper ledger |
| `data/runtime_status.json` | Atomic engine status snapshot |
| `data/stream_status.json` | Atomic WebSocket recorder status |
| `data/evidence/` | Immutable first-seen official-source evidence |
| `data/streams/*.jsonl.gz` | Rotating raw CLOB WebSocket messages |
| `logs/resolutionedge.log` | Structured application log |
| `logs/engine-console.log` | tmux engine console output |
| `logs/stream-console.log` | tmux stream console output |

## Key strategy fields

| Field | Meaning |
|---|---|
| `reference_price` | Gamma probability/reference snapshot; not necessarily executable |
| `best_ask` | Lowest ask in the observed CLOB book |
| `effective_vwap` | Ask-ladder VWAP after configured latency ticks |
| `all_in_cost_per_share` | Effective VWAP plus modeled taker fee |
| `expected_payout` | Strategy-specific conservative expected value used for edge calculation |
| `net_edge_per_share` | `expected_payout - all_in_cost_per_share` |
| `evidence_key` | Deduplication key for the exact strategy evidence state |
| `source_status` | `FINAL`, `PENDING`, or a fail-closed source result |
| `capture_phase` | Whether a book was captured after source evidence or for the baseline control |

## Source statuses

| Status | Meaning |
|---|---|
| `FINAL` | Strict adapter verified the exact target release and winning token |
| `PENDING` | Target release/finality has not occurred |
| `UNSUPPORTED` | Adapter is unavailable or market does not match it |
| `HISTORICAL_UNAVAILABLE` | First-release evidence was not archived before the current page advanced |
| `PARSE_ERROR` | Required source or rule fields could not be parsed safely |
| `SOURCE_MISMATCH` | Official evidence could not map safely to current market metadata |
| `STALE` | Reserved for evidence outside an adapter freshness policy |

## Evaluation decisions

| Decision | Meaning |
|---|---|
| `ORDER` | Strategy-level gates passed; in paper mode it may proceed to portfolio gates |
| `OBSERVE` | Interesting but not eligible for an order, often because source is pending or a cap/duplicate applies |
| `REJECT` | A correctness, execution, rule, source, or risk gate failed |

## Paper order status

| Status | Meaning |
|---|---|
| `OPEN` | Shadow capital is locked awaiting unambiguous market resolution |
| `SETTLED` | An unambiguous payout was recorded and P&L calculated |
