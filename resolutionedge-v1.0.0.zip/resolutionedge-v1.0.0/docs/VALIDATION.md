# ResolutionEdge V1 validation record

Validation date: **2026-08-31**

## Build tested

- Package version: `1.0.0`
- Supported Python: `3.11+`
- Validation interpreter in the build environment: Python 3.13
- Operating modes: `capture`, `paper`
- Live execution module: absent

## Automated validation completed

- Full pytest suite: **46 passed** with `ResourceWarning` promoted to an error
- Python bytecode compilation: passed
- Shell syntax checks for every script: passed
- CLI `version`: passed
- CLI help rendering: passed
- Installed-wheel CLI `version`, help, and offline doctor: passed
- Offline doctor: passed
- Fresh extracted-package source test: passed
- Offline wheel build and isolated target install: passed
- AST import/use audit: passed
- Sports hard-ban tests: passed
- Source-before-book sequencing tests: passed
- Explicit outcome-label tests: passed
- Rule/metadata change halt tests: passed
- SQLite entry/settlement tests: passed

## Important test coverage

The suite covers:

- category, tag, vocabulary, game timestamp, game ID, and event-sibling sports bans;
- prevention of book requests for sports tokens;
- inability to disable the sports ban in YAML;
- unknown-category fail-closed behavior;
- no false `sport` match inside `transportation`;
- Gamma parallel outcome/token/price mapping;
- refusal to synthesize YES/NO labels by array position;
- bounded Gamma discovery parameters;
- CLOB book parsing;
- fee formula;
- price-cap, depth-haircut, latency-tick, minimum-size, and partial-fill behavior;
- BLS target period, scheduled release, embargo, summary/Table A-15 agreement, U-3 extraction, and bucket mapping;
- no pre-release BLS request outside the configured polling window;
- immutable evidence archive and orphaned-archive recovery;
- source finality before the source-confirmed book request;
- source-book condition-ID matching, required exchange timestamps, bounded book age, and rejection of snapshots predating evidence;
- source path priority over the baseline control snapshot;
- full decision-critical semantic fingerprint changes;
- paper order creation, exact duplicate suppression, one-entry-per-market control behavior after favorite flips, event-level correlation cap, and settlement.

## Network limitation of the build environment

The artifact build container did not have outbound network/DNS access, so a real-time smoke test against live Polymarket and BLS endpoints was not represented as passed.

On the deployment host, run:

```bash
./scripts/doctor.sh
```

The online doctor checks:

- Polymarket CLOB server time;
- Gamma market discovery;
- current BLS summary/Table A-15 parser compatibility;
- Polymarket geoblock response;
- permanent sports-ban configuration;
- absence of a live-order module.

Do not start continuous paper collection until the online doctor passes.

## Remaining uncertainty

Passing tests establishes internal consistency, not profitability or live API permanence. External schemas, rule wording, fee schedules, and source HTML can change. The system is designed to fail closed where possible, but every production run still requires monitoring.
