# ResolutionEdge V1 — implemented blueprint

## 1. Mission

ResolutionEdge V1 is a forward-only research system for one testable hypothesis:

> After the exact source named by an objective Polymarket contract publishes the decisive result, stale executable offers may briefly remain below a conservative estimate of the final payout.

The system does not assume that a 97–99% favorite is mispriced. The public "buy the favorite near expiry" idea is retained only as a control against the source-confirmed approach.

## 2. Safety and scope invariants

These are code-level invariants, not operator conventions:

1. Only `capture` and `paper` modes exist.
2. No wallet, private key, allowance, order-signing, or order-posting module exists.
3. Sports and esports cannot be enabled through configuration.
4. A sports/esports market is stopped before rule parsing, source retrieval, order-book retrieval, signal evaluation, or WebSocket subscription.
5. A sports classification propagates to every market sharing the same event ID and remains sticky across later scans.
6. Unknown categories are observation-only and receive no book/source/signal work.
7. Source-confirmed outcomes require explicit Gamma outcome labels; YES/NO is never inferred from token-array position.
8. Any change to decision-critical contract metadata permanently halts that market.
9. Source-confirmed books are requested only after source finality has been established. Their condition ID must match the market, their exchange timestamp must not materially predate the evidence, and they must satisfy a bounded age limit.
10. Every apparent order is a SQLite shadow order. V1 cannot transmit it.

## 3. Supported research universe

### Eligible categories

V1 allows only explicitly tagged objective-data categories:

- economics / economy
- finance / business
- weather
- science
- tech / technology

Category eligibility does not make a market tradeable. It only permits further inspection. A market still needs a deterministic V1 source adapter.

### Hard-blocked universe

Sports and esports are prohibited using redundant signals:

- category and tag values;
- `gameStartTime`;
- `gameId`;
- `sportsMarketType`;
- event/question/slug/group-title sports vocabulary;
- sibling membership in an already hard-banned event;
- historical membership in an event that was ever hard-banned.

### Strategy-blocked universe

V1 does not research or paper-trade:

- politics and elections;
- geopolitics;
- culture, entertainment, and mentions;
- crypto and cryptocurrency;
- all unsupported or ambiguous rule families.

## 4. One-scan data flow

```text
Gamma bounded discovery
        │
        ▼
Universe classification
        │
        ├── sports/esports ──► hard-ban + audit metadata only
        │
        ├── blocked/unknown ─► audit metadata only
        │
        ▼
Decision-critical semantic fingerprint
        │
        ├── changed since first observation ─► permanent halt
        │
        ▼
Strict rule-family assessment
        │
        ├── unsupported/ambiguous ─► no source-confirmed strategy
        │
        ▼
Official source adapter
        │
        ├── pending/error/mismatch ─► record and stop
        │
        ▼
Winning token identified from explicit YES/NO label
        │
        ▼
Fresh post-evidence CLOB order book
        │
        ▼
Spread, orderability, depth, latency, fee, price-cap, edge gates
        │
        ├── fail ─► rejected evaluation with exact reason
        │
        ▼
Shadow order candidate
        │
        ▼
Duplicate, event-correlation, scan-cap, and paper-equity gates
        │
        ▼
SQLite paper order
```

After the latency-sensitive source path is captured, the engine requests the favorite-token book used by the naive control strategies.

## 5. Contract semantic fingerprint

The fingerprint deliberately excludes changing prices and liquidity. It includes fields that can change interpretation or token mapping:

- market ID and condition ID;
- event ID and event title;
- slug;
- question;
- group item title / numerical bucket label;
- full rules;
- resolution source;
- ordered outcome index, explicit label, and token ID.

The SHA-256 fingerprint is stored in both `markets` and `market_rule_versions`. Every distinct observed fingerprint is preserved with its exact semantic JSON. Once more than one fingerprint exists for a market, that market is permanently ineligible in V1.

Each completed or failed run also records the SHA-256 checksum of `config/default.yaml` in its run statistics.

## 6. Implemented strategies

### 6.1 `hf97_reference`

Purpose: optimistic reference control.

Candidate conditions:

- Gamma favorite reference price >= 0.97;
- end date within 24 hours, including a two-hour post-end observation window;
- lifetime volume >= $500;
- active, open, orderable market;
- eligible non-sports objective category.

The control constructs a synthetic fill at the Gamma reference price. It is explicitly labelled non-executable. It includes the modeled taker fee but no live depth or slippage.

### 6.2 `hf97_executable`

Purpose: isolate the execution penalty in the same naive signal.

It uses the same candidate definition, then requires the current favorite-token CLOB book and applies:

- actual ask levels;
- hard maximum entry price;
- one latency-slippage tick by default;
- 50% visible-depth haircut by default;
- current Gamma fee schedule when available, conservative category fallback otherwise;
- exchange minimum-share checks;
- minimum simulated fill size;
- partial fills when enabled.

No independent fair-value edge is claimed. Its expected value in evaluation records uses the market reference probability, not a fabricated certainty estimate.

### 6.3 `source_confirmed_bls_u3`

Purpose: primary V1 hypothesis.

It supports only BLS Employment Situation contracts that explicitly name:

- the U.S. Bureau of Labor Statistics;
- the Employment Situation report;
- the official U-3 unemployment rate;
- Table A-15;
- a deterministically parseable data month and numerical bucket.

A paper order requires all of these gates:

1. Category and sports filters pass.
2. Contract semantic fingerprint is unchanged.
3. Rule family is strict and contains no configured ambiguity phrase.
4. Target month parses.
5. Numerical bucket parses.
6. BLS summary and Table A-15 are available.
7. Their report periods agree.
8. Their U-3 values agree.
9. The BLS embargo/release timestamp parses and has passed.
10. First-seen source documents are archived immutably.
11. The official value maps to an explicitly labelled YES or NO token.
12. The market remains open and orderable.
13. A fresh winning-token book is fetched after evidence finality.
14. The book condition ID matches the market condition ID.
15. The exchange generation timestamp exists, does not materially predate the evidence, and is no more than 30 seconds old by default.
16. The book is two-sided.
17. Spread <= 0.04 by default.
18. Best ask <= 0.992 by default.
19. Pessimistic executable depth produces at least the minimum fill.
20. Conservative payout of 0.995 minus all-in cost/share is >= 0.003.
21. No source-confirmed order has already been made for the correlated event.
22. The strategy's independent shadow ledger has enough available equity.

The conservative payout haircut is a research assumption for oracle, rule, technical, and abnormal-resolution risk. It is not a claim that the contract is guaranteed to pay $1.

## 7. BLS evidence lifecycle

### Before the scheduled release

The adapter attempts to parse the rule-stated release timestamp. More than ten minutes before that time, it returns `PENDING` without requesting BLS pages. This prevents unnecessary polling.

### Near and after release

The adapter fetches:

- Employment Situation summary;
- Table A-15.

It parses the report month, embargo timestamp, summary unemployment rate, latest Table A-15 period, and latest seasonally adjusted U-3 value. Any missing or inconsistent field fails closed.

### Immutable archive

The first accepted source pair is stored at:

```text
data/evidence/bls_employment_situation/YYYY-MM/
├── employment_summary.html
├── table_a15.html
└── metadata.json
```

The combined source checksum and metadata are stored in SQLite. Existing archive files are re-parsed during crash recovery. Partial or mismatched archives are rejected rather than merged with later source versions.

### Historical data rule

If the target month predates the current BLS page and no first-seen archive exists, V1 returns `HISTORICAL_UNAVAILABLE`. It does not pretend that a later, possibly revised page represents the first release.

## 8. Paper execution model

For every ask level, V1 performs the following calculation:

```text
effective price = displayed ask + tick size × latency ticks
available shares = displayed shares × visible-depth haircut
fee/share = fee rate × effective price × (1 - effective price)
all-in price/share = effective price + fee/share
```

The ladder is walked while the effective price remains at or below the strategy's hard cap. The stake is an all-in USDC budget, including fees.

Stored values include:

- requested all-in budget;
- shares;
- displayed and effective prices by leg;
- raw execution notional;
- modeled fee;
- total cost;
- displayed VWAP;
- effective VWAP;
- all-in cost/share;
- partial-fill status and reason.

Visible depth is not treated as guaranteed. The default model discards half of it and adds one price tick. This remains a simulation and cannot reproduce network latency, cancellations, matching-engine behavior, or actual fill priority.

## 9. Correlation and capital controls

Each strategy has a separate $10,000 starting shadow ledger. Open order costs lock capital; settled P&L changes available equity. Accounting remains in Python `Decimal`, not SQLite floating-point sums.

The source-confirmed strategy permits only one order for an event ID over the life of the database. A ladder of eight unemployment buckets is therefore one risk event, not eight independent opportunities.

Duplicate protection uses strategy, market, token, and evidence key. In addition, each naive control may enter a market only once even if the displayed favorite later flips. The source-confirmed evidence key contains the adapter, period, source checksum, winning token, and contract fingerprint.

## 10. Storage design

### SQLite tables

- `runs`: mode, timestamps, status, configuration checksum, statistics, and errors.
- `markets`: latest metadata, universe decision, semantic fingerprint, and raw Gamma JSON.
- `market_rule_versions`: immutable observed semantic versions.
- `book_snapshots`: local observation time, exchange book time, capture phase, top bid/ask ladders, spread, tick, and hash.
- `rule_assessments`: deterministic/support status and rejection reasons.
- `source_releases`: one immutable accepted release per adapter/period.
- `source_evidence`: every market-level source decision, including pending and errors.
- `evaluations`: every strategy decision, including rejected and observed candidates.
- `paper_orders`: shadow fills, settlement, payout, and P&L.
- `runtime_meta`: latest successful scan and other operational state.

### Book capture phases

- `source_post_evidence`: fresh winning-token book requested only after official source finality; source-confirmed evaluation verifies its market identity and timing.
- `baseline_control_snapshot`: favorite-token book for the naive controls, collected after the source-priority path.

### Raw stream archive

The independent WebSocket process subscribes only to recently observed, orderable, non-hard-banned, universe-eligible tokens. It stores raw messages as rotating gzip JSONL and records local receipt timestamps.

## 11. Settlement model

At the start of each scan, V1 checks open paper orders against current Gamma market metadata. It settles only when:

- the market is closed; and
- the relevant token is unambiguously represented as 1, 0, or a market-wide 0.5 payout; or
- Gamma exposes an explicit winning token/outcome.

Unclear closed states remain open. V1 does not guess.

## 12. Operator interfaces

### One scan

```bash
./scripts/run_once.sh paper
```

### Always-on runner

```bash
./scripts/start.sh paper
```

The tmux session contains:

- `engine`: scans, source evidence, evaluations, paper entries, settlement;
- `stream`: non-sports raw CLOB archive;
- `monitor`: progress and candidate tables.

### Inspection

```bash
./scripts/progress.sh
./scripts/candidates.sh 50
./scripts/report.sh
./scripts/universe.sh
./scripts/attach.sh
./scripts/stop.sh
```

## 13. Research discipline

The default thresholds are frozen starting assumptions, not optimized parameters. Any change should create a new version and be judged only on later observations.

The three shadow strategies must remain separate. Combining their results would conceal whether apparent returns came from:

- a fictional reference price;
- executable favorite-following;
- or independent source confirmation.

The unit of evidence is an independent source event, not the number of correlated contracts.

## 14. V1 success and failure criteria

V1 succeeds operationally when it continuously archives valid non-sports data, rejects unsupported cases with explicit reasons, and can reproduce every shadow decision from stored source and book evidence.

The hypothesis is not promoted merely because paper P&L is positive. A later version should require:

- a meaningful count of independent official-source events;
- positive settled net P&L under executable assumptions;
- no dependence on one event or one anomalous fill;
- acceptable downside under harsher depth, latency, fee, and payout haircuts;
- an untouched later forward period;
- and eventually a tiny live pilot whose actual fills resemble the paper model.

A finding of no remaining post-source liquidity or negative executable EV is a valid and useful V1 result.

## 15. Explicit V1 exclusions

V1 does not contain:

- sports or esports collection beyond Gamma classification/audit metadata;
- sports books, streams, source adapters, signals, or paper orders;
- weather adapters;
- CPI or payroll adapters;
- crypto strategies;
- LLM rule interpretation;
- subjective politics/geopolitics/culture strategies;
- cross-venue odds;
- maker strategies or rebate farming;
- copy trading;
- martingale, leverage, or dynamic bet escalation;
- backtest optimization;
- convergence-sell or profit-target tuning; V1 holds shadow positions to unambiguous settlement;
- real-money execution.
